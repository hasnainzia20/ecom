﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

public partial class user_Profile : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
    public void gridbind()
    {

     //   string lid = Session["UserId"].ToString();
        string rstr = "select Id,TemplateName,SMSTemplate from tblSMSNotifications ";

        //  string rstr = "SELECT     txn_id, txn_date, cust_id, opr_name, details, mycomm, cr, dr, cust_bal, actions, txn_amt, o_bal, c_bal, status, remarks, res_id, rechargetype, sboxid, response_time, opr_rec_code, api_txn_type, agent_id, apisourcecode FROM  txn_rec where cust_id ='" + lid + "' and rechargetype in(201,202,203,204)  ORDER BY txn_date DESC;";
        SqlCommand com = new SqlCommand(rstr, con);
        SqlDataAdapter myAdapter = new SqlDataAdapter();
        myAdapter.SelectCommand = com;
        DataSet myDataSet = new DataSet();
        myAdapter.Fill(myDataSet);

        GridView11.DataSource = myDataSet;
        GridView11.DataBind();
    }
    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "manage")
        {

            this.temps.Text = e.CommandArgument.ToString();
           
        }
        else if (e.CommandName == "lnkDelete")
        {
            
            ob ob1 = new ob();
            string insertvalue = "delete from tblSMSNotifications where Id='" + e.CommandArgument.ToString() + "'";
            string insdatarecharge = ob1.executenonscalar(insertvalue).ToString();
            this.Popup.SetMessage("SMS Template Deleted Successfully", control_ShowMessage.MessageType.Success);

            this.gridbind();
          


        }
    }
    private void ddlBind()
    {
        IEnumerable<clsVariables.DroptDownClass> enumerable = Enumerable.Where<clsVariables.DroptDownClass>(clsVariables.UserTypes(), delegate(clsVariables.DroptDownClass x)
        {
            if ((x.Value != clsVariables.UserType.User) && (x.Value != clsVariables.UserType.Reseller) && (x.Value != clsVariables.UserType.Retailer) && (x.Value != clsVariables.UserType.Distributor) && (x.Value != clsVariables.UserType.SuperDistributor))
            {
                return x.Value == " - Select - ";
            }
            return true;
        });
        this.ddlUsertype2.DataSource = enumerable;
        this.ddlUsertype2.DataTextField = "Text";
        this.ddlUsertype2.DataValueField = "Value";
        this.ddlUsertype2.DataBind();
    }
    protected void ddlUsertype2_SelectedIndexChanged(object sender, EventArgs e)
    {
        var queryable = from x in this.db.tblUsers
                        where x.UserType == this.ddlUsertype2.SelectedValue
                        orderby x.Username
                        select new
                        {
                            Mobile = x.Mobile,
                        };

        foreach (var mob in queryable)
        {
            this.ssd.Value += (mob.Mobile) +",";

        }
    }

    protected void send_Click(object sender, EventArgs e)
    {

        clsMethods.sendSMS(this.ssd.Value, temps.Text, "");
        this.Popup.SetMessage("SMS Notification Send Successfully", control_ShowMessage.MessageType.Success);
    }
   
    protected void lnkOpen_Click(object sender, EventArgs e)
    {

        this.fupop.Show();
        this.flbl.Text = "Add New SMS Template";
       
    }
  
    protected void addrenge_Click(object sender, EventArgs e)
    {
        try
        {
            ob ob1 = new ob();
            string insertvalue = "insert into tblSMSNotifications values ('" + name.Text + "','" + template.Text + "')";
            string insdatarecharge = ob1.executenonscalar(insertvalue).ToString();
            this.fupop.Hide();
            this.gridbind();
            this.Popup.SetMessage("SMS Template Added Successfully", control_ShowMessage.MessageType.Success);
        }
        catch (Exception ex)
        {
            this.fupop.Hide();
            this.Popup.SetMessage(ex.Message, control_ShowMessage.MessageType.Warning);

        }
       
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            ob ob = new ob();
            this.gridbind();
            this.ddlBind();
         
        }
    }
  
    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }
}
