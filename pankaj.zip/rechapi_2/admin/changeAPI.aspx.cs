﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_changeAPI : ThemeClass, IRequiresSessionState
{
  
    private DataClassesDataContext db = new DataClassesDataContext();

    protected void bttnAdd_Click(object sender, EventArgs e)
    {
        foreach (tblCommission commission in from x in this.db.tblCommissions
            join y in this.db.tblCommPackages on x.PackageId equals y.Id 
            where (x.OperatorId == Convert.ToInt16(this.ddlOperator.SelectedValue)) && !y.Locked
            select x)
        {
            commission.ApiId = new short?(Convert.ToInt16(this.ddlAPI.SelectedValue));
            this.db.SubmitChanges();
        }
        this.Popup.SetMessage("API updated successfully", control_ShowMessage.MessageType.Success);
    }

    private void ddlBind()
    {
        var queryable = from x in this.db.tblOperators
            join z in this.db.tblMainComps on x.MainCompId equals (short?) z.Id
            join y in this.db.tblServices on z.ServiceId equals y.Id
            let Name1 = z.OperatorName
            orderby z.OperatorName
            select new { 
                Id = x.Id,
                Name = (x.Operator != null) ? (((Name1 + " ") + x.Operator + " [") + y.ServiceName + "]") : ((Name1 + " [") + y.ServiceName + "]")
            };
        this.ddlOperator.DataSource = queryable;
        this.ddlOperator.DataTextField = "Name";
        this.ddlOperator.DataValueField = "Id";
        this.ddlOperator.DataBind();
        this.ddlOperator.Items.Insert(0, " - Select - ");
        var queryable2 = from x in this.db.tblApis
            orderby x.APIName
            select new { 
                Id = x.Id,
                Code = x.APICode
            };
        this.ddlAPI.DataSource = queryable2;
        this.ddlAPI.DataTextField = "Code";
        this.ddlAPI.DataValueField = "Id";
        this.ddlAPI.DataBind();
        this.ddlAPI.Items.Insert(0, " - Select - ");
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
        }
    }

}
