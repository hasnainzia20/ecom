﻿using AjaxControlToolkit;
using System;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user_Profile : ThemeClass, IRequiresSessionState
{
   
    private DataClassesDataContext db = new DataClassesDataContext();
  

    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            clsMethods.addTrans(-1, Convert.ToDecimal(this.txtAmount.Text), "Balance added by Admin itself", Convert.ToInt32(this.Session["aUserId"].ToString()), Convert.ToInt32(this.Session["aUserId"].ToString()), clsMethods.getBalance(Convert.ToInt32(this.Session["aUserId"].ToString())) + Convert.ToDecimal(this.txtAmount.Text), clsVariables.TransactionType.Balance, 0L, clsMethods.getBalance(Convert.ToInt32(this.Session["aUserId"].ToString())) + Convert.ToDecimal(this.txtAmount.Text), 0M, 0, -1M);
            this.Popup.SetMessage("Balance added successfully", control_ShowMessage.MessageType.Success);
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        bool isPostBack = base.IsPostBack;
    }


}
