﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


public partial class apiswitch : ThemeClass, IRequiresSessionState

{
    DataClassesDataContext db = new DataClassesDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            try
            {
                ob ob = new ob();
                var source = from x in this.db.tblCommPackages
                             where x.UserType == clsVariables.UserType.User && x.UserId == Convert.ToInt16(this.Session["aUserId"])
                             select new
                             {
                                 Id = x.Id,
                                 Name = x.PackageName
                             };
                this.sd.DataSource = source;
                this.sd.DataTextField = "Name";
                this.sd.DataValueField = "Id";
                this.sd.DataBind();
                this.sd.Items.Insert(0, "Select");
                this.ec.DataSource = source;
                this.ec.DataTextField = "Name";
                this.ec.DataValueField = "Id";
                this.ec.DataBind();
                this.ec.Items.Insert(0, "Select");
                this.bs.DataSource = source;
                this.bs.DataTextField = "Name";
                this.bs.DataValueField = "Id";
                this.bs.DataBind();
                this.bs.Items.Insert(0, "Select");
                this.sl.DataSource = source;
                this.sl.DataTextField = "Name";
                this.sl.DataValueField = "Id";
                this.sl.DataBind();
                this.sl.Items.Insert(0, "Select");
                this.gd.DataSource = source;
                this.gd.DataTextField = "Name";
                this.gd.DataValueField = "Id";
                this.gd.DataBind();
                this.gd.Items.Insert(0, "Select");
                this.dm.DataSource = source;
                this.dm.DataTextField = "Name";
                this.dm.DataValueField = "Id";
                this.dm.DataBind();
                this.dm.Items.Insert(0, "Select");

                string s = ob.executescalar("select StarterId from tblApiPlans");
                string es = ob.executescalar("select EconomyId from tblApiPlans");
                string b = ob.executescalar("select BasicId from tblApiPlans");
                string ss = ob.executescalar("select SilverId from tblApiPlans");
                string g = ob.executescalar("select GoldId from tblApiPlans");
                string d = ob.executescalar("select DiamondId from tblApiPlans");
                string s1 = ob.executescalar("select StarterPrice from tblApiPlans");
                string es1 = ob.executescalar("select EconomyPrice from tblApiPlans");
                string b1 = ob.executescalar("select BasicPrice from tblApiPlans");
                string ss1 = ob.executescalar("select SilverPrice from tblApiPlans");
                string g1 = ob.executescalar("select GoldPrice from tblApiPlans");
                string d1 = ob.executescalar("select DiamondPrice from tblApiPlans");

                this.sd.SelectedValue = s;
                this.ec.SelectedValue = es;
                this.bs.SelectedValue = b;
                this.sl.SelectedValue = ss;
                this.gd.SelectedValue = g;
                this.dm.SelectedValue = d;
                this.sp.Text = s1;
                this.ep.Text = es1;
                this.bp.Text = b1;
                this.slp.Text = ss1;
                this.gp.Text = g1;
                this.dp.Text = d1;
            }
            catch
            {
            }
        }
    }
    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            try
            {
                ob ob1 = new ob();
                string iii = "Update tblApiPlans SET StarterId = '" + this.sd.SelectedValue + "', EconomyId = '" + this.ec.SelectedValue + "', BasicId = '" + this.bs.SelectedValue + "', SilverId = '" + this.sl.SelectedValue + "', GoldId = '" + this.gd.SelectedValue + "', DiamondId = '" + this.dm.SelectedValue + "', StarterPrice = '" + this.sp.Text + "', EconomyPrice = '" + this.ep.Text + "', BasicPrice = '" + this.bp.Text + "', SilverPrice = '" + this.slp.Text + "', GoldPrice = '" + this.gp.Text + "', DiamondPrice = '" + this.dp.Text + "'".ToString();
                string insdatarecharge = ob1.executenonscalar(iii).ToString();


                this.Popup.SetMessage("API User Plans Updated Successfully ", control_ShowMessage.MessageType.Success);
            }
            catch
            {
                this.Popup.SetMessage("All Fields Are Required ", control_ShowMessage.MessageType.Warning);
            }
           
        }
        catch
        {
        }
    }


   
    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }
   
}
	