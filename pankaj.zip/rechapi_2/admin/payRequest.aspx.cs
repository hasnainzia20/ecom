﻿using AjaxControlToolkit;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_payRequest : ThemeClass, IRequiresSessionState
{
   
    private DataClassesDataContext db = new DataClassesDataContext();
    
    private void bindData()
    {
        var queryable = from x in this.db.tblPaymentReqs
            join y in this.db.tblUsers on x.UserId equals y.Id
            join z in this.db.tblBankDetails on x.DepositBankId equals z.Id
            join z1 in this.db.tblBanks on z.BankId equals z1.Id
            where x.Approved == clsVariables.RequestType.Pending
            orderby x.PaymentDate descending
            select new { 
                Id = x.Id,
                UserId = y.Id,
                Username = (y.CustName + " [") + (y.Id) + "]",
                Amount = x.Amount,
                Mode = x.PaymentMode,
                Reference = x.TranNo,
                Remarks = x.Remarks,
                DepositDate = x.TranDate,
                Bank = z1.BankName + " - " + z.AccountNo,
                Status = (x.Approved == clsVariables.RequestType.Pending) ? "<span style='color:orange'>PENDING</span>" : "UNKNOWN"
            };
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            queryable = from x in queryable
                where x.Bank.Contains(this.txtSearch.Text) || x.Reference.Contains(this.txtSearch.Text)
                select x;
        }
        if (this.ddlUsers.SelectedIndex > 0)
        {
            queryable = from x in queryable
                where x.UserId == Convert.ToInt32(this.ddlUsers.SelectedValue)
                select x;
        }
        if (((this.txtFrom.Text != null) && (this.txtFrom.Text != "")) && ((this.txtTo.Text != null) && (this.txtTo.Text != "")))
        {
            DateTime dt;
            DateTime dt2;
            DateTime.TryParseExact(this.txtFrom.Text.Split(new char[] { '/' })[1] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[0] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt);
            DateTime.TryParseExact(this.txtTo.Text.Split(new char[] { '/' })[1] + "/" + this.txtTo.Text.Split(new char[] { '/' })[0] + "/" + this.txtTo.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt2);
            queryable = from x in queryable
                        where (x.DepositDate.Value.Date >= dt.Date) && (x.DepositDate.Value.Date <= dt2.Date)
                select x;
        }
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnExport_Click(object sender, EventArgs e)
    {
        this.ExportToExcel();
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
        var queryable = from x in this.db.tblUsers
            where x.UserType != clsVariables.UserType.Administrator
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + (x.Id) + "]"
            };
        this.ddlUsers.DataSource = queryable;
        this.ddlUsers.DataTextField = "Name";
        this.ddlUsers.DataValueField = "Id";
        this.ddlUsers.DataBind();
        this.ddlUsers.Items.Insert(0, "All");
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData();
    }

    protected void ddlUpdate_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DropDownList list = sender as DropDownList;
            foreach (GridViewRow row in this.gvMain.Rows)
            {
                Control control = row.FindControl("ddlAction") as DropDownList;
                Control control2 = row.FindControl("hfId") as HiddenField;
                if (control != null)
                {
                    DropDownList list2 = (DropDownList) control;
                    HiddenField hfId1 = (HiddenField) control2;
                    if (list.ClientID == list2.ClientID)
                    {
                        DataClassesDataContext context = new DataClassesDataContext();
                        if (list2.SelectedIndex == 1)
                        {

                            tblPaymentReq req = Queryable.Single<tblPaymentReq>(context.tblPaymentReqs, p => p.Id == Convert.ToInt32(hfId1.Value));
                            req.Approved = clsVariables.RequestType.Accepted;
                            context.SubmitChanges();
                            tblUser user = Queryable.Single<tblUser>(context.tblUsers, x => x.UserType == clsVariables.UserType.Administrator);
                            clsMethods.addTrans(user.Id, req.Amount, req.Remarks, req.UserId, req.UserId, clsMethods.getBalance(req.UserId) + req.Amount, clsVariables.TransactionType.Payment, 0L, clsMethods.getBalance(user.Id) - req.Amount, 0M, 0, -1M);
                            this.bindData();
                            this.Popup.SetMessage("Payment Request accepted successfully", control_ShowMessage.MessageType.Success);

                        }
                        else if (list2.SelectedIndex == 2)
                        {

                            Queryable.Single<tblPaymentReq>(context.tblPaymentReqs, p => p.Id == Convert.ToInt32(hfId1.Value)).Approved = clsVariables.RequestType.Rejected;
                            context.SubmitChanges();
                            this.bindData();
                            this.Popup.SetMessage("Payment Request rejected", control_ShowMessage.MessageType.Information);

                        }
                    }
                }
            }
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void ExportToExcel()
    {
        HtmlForm child = new HtmlForm();
        string str = "attachment;filename=" + DateTime.Now.ToString("dd-MM-yyyy") + "_PayReq.xls";
        base.Response.ClearContent();
        base.Response.AddHeader("content-disposition", str);
        base.Response.ContentType = "application/vnd.ms-excel";
        StringWriter writer = new StringWriter();
        HtmlTextWriter writer2 = new HtmlTextWriter(writer);
        child.Controls.Add(this.gvMain);
        this.Controls.Add(child);
        child.RenderControl(writer2);
        base.Response.Write(writer.ToString());
        base.Response.End();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "15",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.txtTo.Text = this.txtFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            this.bindData();
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
    }

    
}
