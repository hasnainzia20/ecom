﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

//public partial class admin_Admin : ThemeClass, IRequiresSessionState, MasterPage
public partial class admin_Admin : MasterPage
{

    private DataClassesDataContext db = new DataClassesDataContext();


    protected void lnkDefault_Click(object sender, EventArgs e)
    {
        tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
        user.ThemeColor = "Default";
        this.db.SubmitChanges();
        base.Session["Theme"] = user.ThemeColor;
        base.Response.Redirect(base.Request.FilePath);
    }

    protected void lnkGray_Click(object sender, EventArgs e)
    {
        tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
        user.ThemeColor = "Gray";
        this.db.SubmitChanges();
        base.Session["Theme"] = user.ThemeColor;
        base.Response.Redirect(base.Request.FilePath);
    }

    protected void lnkGreen_Click(object sender, EventArgs e)
    {
        tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
        user.ThemeColor = "Green";
        this.db.SubmitChanges();
        base.Session["Theme"] = user.ThemeColor;
        base.Response.Redirect(base.Request.FilePath);
    }

    protected void lnkPurple_Click(object sender, EventArgs e)
    {
        tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
        user.ThemeColor = "Purple";
        this.db.SubmitChanges();
        base.Session["Theme"] = user.ThemeColor;
        base.Response.Redirect(base.Request.FilePath);
    }

    protected void lnkRed_Click(object sender, EventArgs e)
    {
        tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
        user.ThemeColor = "Red";
        this.db.SubmitChanges();
        base.Session["Theme"] = user.ThemeColor;
        base.Response.Redirect(base.Request.FilePath);
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        base.Response.Cache.SetExpires(DateTime.Now);
        base.Response.Cache.SetAllowResponseInBrowserHistory(false);
        base.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        base.Response.Cache.SetNoStore();
        if (base.Session.Count == 0)
        {
            base.Response.Redirect("~/Default.aspx?logout=0");
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            DataClassesDataContext context = new DataClassesDataContext();
            tblUser user = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
            decimal num = clsMethods.getBalance(Convert.ToInt32(base.Session["aUserId"].ToString()));
            this.lblDetails2.Text = "Welcome <b>" + user.CustName + "</b>";
            this.lblDetails.Text = "V: <b>" + num.ToString() + "</b>";
            this.lblonline.Text = "Online Users: <b>" + Application["TotalOnlineUsers"] + "</b>";
            this.lblTitle.Text = base.Session["SiteTitle"].ToString();
            this.imgLogo.ImageUrl = "~/template/img/" + base.Session["Logo"].ToString();
        }
    }


}

