﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_state : ThemeClass, IRequiresSessionState
{
    
    private DataClassesDataContext db = new DataClassesDataContext();
   

    private void bindData()
    {
        var queryable = from x in this.db.tblRangeAmts
            join y in this.db.tblApis on x.APIId equals (int) y.Id
            join z in this.db.tblMainComps on x.OperatorId equals z.Id 
            orderby z.OperatorName
            select new { 
                Id = x.Id,
                OperatorName = z.OperatorName,
                APIName = y.APIName,
                Amount = x.MinAmt,
                Amount2 = x.MaxAmt,
                Status = x.Status ? "<span style='color:green'>Active</span>" : "<span style='color:red'>Deactive</span>"
            };
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            queryable = from x in queryable
                where x.OperatorName.Contains(this.txtSearch.Text) || x.APIName.Contains(this.txtSearch.Text)
                select x;
        }
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnAdd_Click(object sender, EventArgs e)
    {
        if (this.bttnAdd.Text == "Add New Amount Range")
        {
            tblRangeAmt entity = new tblRangeAmt {
                APIId = Convert.ToInt16(this.ddlAPI.SelectedValue),
                OperatorId = Convert.ToInt16(this.ddlOperator.SelectedValue),
                MinAmt = Convert.ToDecimal(this.txtMinAmt.Text),
                MaxAmt = Convert.ToDecimal(this.txtMaxAmt.Text),
                Status = this.chkStatus.Checked
            };
            this.db.tblRangeAmts.InsertOnSubmit(entity);
            this.db.SubmitChanges();
            this.bindData();
            this.popup1222.Hide();
            this.reset();
            this.Popup.SetMessage("Amount range added successfully", control_ShowMessage.MessageType.Success);
        }
        else if (this.bttnAdd.Text == "Update Amount Range")
        {
            tblRangeAmt addSeries = Queryable.SingleOrDefault<tblRangeAmt>(this.db.tblRangeAmts, x => x.Id == Convert.ToInt32(this.hfId.Value));
            if (addSeries != null)
            {
                if (Queryable.SingleOrDefault<tblRangeAmt>(this.db.tblRangeAmts, x => (x.APIId == Convert.ToInt16(this.ddlAPI.SelectedValue)) && (x.Id != addSeries.Id)) == null)
                {
                    addSeries.APIId = Convert.ToInt16(this.ddlAPI.SelectedValue);
                    addSeries.OperatorId = Convert.ToInt16(this.ddlOperator.SelectedValue);
                    addSeries.MinAmt = Convert.ToDecimal(this.txtMinAmt.Text);
                    addSeries.MaxAmt = Convert.ToDecimal(this.txtMaxAmt.Text);
                    addSeries.Status = this.chkStatus.Checked;
                    this.db.SubmitChanges();
                    this.reset();
                    this.bindData();
                    this.popup1222.Hide();
                    this.Popup.SetMessage("Amount range updated successfully", control_ShowMessage.MessageType.Success);
                }
                else
                {
                    this.Popup.SetMessage("Amount range already exist", control_ShowMessage.MessageType.Warning);
                }
            }
        }
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
        var queryable = from x in this.db.tblApis
            orderby x.APIName
            select new { 
                Id = x.Id,
                Name = x.APIName
            };
        this.ddlAPI.DataSource = queryable;
        this.ddlAPI.DataTextField = "Name";
        this.ddlAPI.DataValueField = "Id";
        this.ddlAPI.DataBind();
        this.ddlAPI.Items.Insert(0, " - Select - ");
        var queryable2 = from z in this.db.tblMainComps
            join y in this.db.tblServices on z.ServiceId equals y.Id 
            orderby y.Id
            select new { 
                Id = z.Id,
                Name = (z.OperatorName + " [") + y.ServiceName + "]"
            };
        this.ddlOperator.DataSource = queryable2;
        this.ddlOperator.DataTextField = "Name";
        this.ddlOperator.DataValueField = "Id";
        this.ddlOperator.DataBind();
        this.ddlOperator.Items.Insert(0, " - Select - ");
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            this.lblTitle.Text = "UPDATE AMOUNT RANGE";
            this.bttnAdd.Text = "Update Amount Range";
            tblRangeAmt amt = Queryable.Single<tblRangeAmt>(this.db.tblRangeAmts, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.hfId.Value = amt.Id.ToString();
            this.txtMinAmt.Text = amt.MinAmt.ToString();
            this.txtMaxAmt.Text = amt.MaxAmt.ToString();
            this.ddlAPI.SelectedValue = amt.APIId.ToString();
            this.chkStatus.Checked = amt.Status;
            this.ddlOperator.SelectedValue = amt.OperatorId.ToString();
            this.popup1222.Show();
        }
        else if (e.CommandName == "lnkDelete")
        {
            tblRangeAmt entity = Queryable.Single<tblRangeAmt>(this.db.tblRangeAmts, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.db.tblRangeAmts.DeleteOnSubmit(entity);
            this.db.SubmitChanges();
            this.bindData();
            this.Popup.SetMessage("Amount Range deleted successfully", control_ShowMessage.MessageType.Success);
        }
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "5",
                    "10",
                    "15"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button button3 = (Button) e.Row.FindControl("bttnDelete");
            button3.Attributes.Add("onclick", string.Concat(new object[] { "javascript:return confirm('Are you sure you want to delete this record: ", DataBinder.Eval(e.Row.DataItem, "OperatorName"), " - ", DataBinder.Eval(e.Row.DataItem, "APIName"), "')" }));
        }
    }

    protected void lnkOpen_Click(object sender, EventArgs e)
    {
        this.lblTitle.Text = "CREATE NEW AMOUNT RANGE";
        this.bttnAdd.Text = "Add New Amount Range";
        this.reset();
        this.popup1222.Show();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.bindData();
        }
    }

    private void reset()
    {
        this.txtMaxAmt.Text = "";
        this.txtMinAmt.Text = "";
        this.ddlOperator.SelectedIndex = 0;
        this.ddlAPI.SelectedIndex = 0;
        this.chkStatus.Checked = true;
    }

   
}
