﻿using AjaxControlToolkit;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_rechargeReport : ThemeClass, IRequiresSessionState
{
    
    private DataClassesDataContext db = new DataClassesDataContext();
    

    private void bindData(bool status)
    {
        string[] strArray;
        decimal? nullable;
        decimal num;
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            var queryable = from x in this.db.tblRecharges
                join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id 
                join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id 
                join z1 in this.db.tblServices on x.ServiceId equals (short?) z1.Id
                join z2 in this.db.tblUsers on x.UserId equals z2.Id 
                join z3 in this.db.tblApis on x.APIId equals (short?) z3.Id
                let Name1 = z.OperatorName
                where (x.Id.ToString().Contains(this.txtSearch.Text) || (x.Number == this.txtSearch.Text)) || (x.TransactionId == this.txtSearch.Text)
                orderby x.RechargeDate descending
                select new { 
                    Id = x.Id,
                    UserId = x.UserId,
                    Number = x.Number,
                    Optional1 = x.Optional1,
                    Optional2 = x.Optional2,
                    Optional3 = x.Optional3,
                    Username = (z2.Username + " [") + (z2.Id) + "]",
                    Amount = x.Amount,
                    API = z3.APICode,
                    Response = x.Response,
                    Operator = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                    RechargeDate = x.RechargeDate,
                    CommAmt = x.CommAmt,
                    Cost = x.Cost,
                    Mode = x.RechargeMode,
                    Domain = z2.Domain,
                    OpRef = x.OperatorRef,
                    TransId = x.TransactionId,
                    OpeningBal = x.OpeningBal,
                    ClosingBal = x.ClosingBal,
                    Status1 = x.Status,
                    APIId = x.APIId,
                    OperatorId = x.OperatorId,
                    Status = (x.Status == "Failure") ? "<span style='color:red'>FAILURE</span>" : ((x.Status == "Success") ? "<span style='color:green'>SUCCESS</span>" : ((x.Status == "In Process") ? "<span style='color:#FFAA55'>IN PROCESS<span>" : ((x.Status == "Reversed") ? "<span style='color:orange'>REVERSED</span>" : x.Status)))
                };
            strArray = new string[9];
            strArray[0] = "Success: <b>";
            nullable = Queryable.Sum(from x in queryable
                where x.Status1 == clsVariables.RechargeStatus.Success
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[1] = num.ToString();
            strArray[2] = "</b> | Failure: <b>";
            nullable = Queryable.Sum(from x in queryable
                where x.Status1 == clsVariables.RechargeStatus.Failure
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[3] = num.ToString();
            strArray[4] = "</b> | Pending: <b>";
            nullable = Queryable.Sum(from x in queryable
                where x.Status1 == clsVariables.RechargeStatus.Pending
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[5] = num.ToString();
            strArray[6] = "</b> | Reversed: <b>";
            nullable = Queryable.Sum(from x in queryable
                where x.Status1 == clsVariables.RechargeStatus.Reversed
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[7] = num.ToString();
            strArray[8] = "</b>";
            this.lblTotal.Text = string.Concat(strArray);
            if (status)
            {
                this.gvMain.Columns[9].Visible = false;
                this.gvMain.AllowPaging = false;
            }
            this.gvMain.DataSource = queryable;
            this.gvMain.DataBind();
        }
        else if ((base.Request["id"] != null) && (base.Request["id"] != ""))
        {
            var queryable2 = from x in this.db.tblRecharges
                join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id 
                join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id 
                join z1 in this.db.tblServices on x.ServiceId equals (short?) z1.Id 
                join z2 in this.db.tblUsers on x.UserId equals z2.Id 
                join z3 in this.db.tblApis on x.APIId equals (short?) z3.Id 
                where x.Id == Convert.ToInt32(this.Request["id"].ToString())
                let Name1 = z.OperatorName
                orderby x.RechargeDate descending
                select new { 
                    Id = x.Id,
                    UserId = x.UserId,
                    Domain = z2.Domain,
                    Number = x.Number,
                    Optional1 = x.Optional1,
                    Optional2 = x.Optional2,
                    Optional3 = x.Optional3,
                    Username = (z2.Username + " [") + (z2.Id) + "]",
                    Amount = x.Amount,
                    Response = x.Response,
                    OpRef = x.OperatorRef,
                    Mode = x.RechargeMode,
                    Operator = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                    RechargeDate = x.RechargeDate,
                    CommAmt = x.CommAmt,
                    API = z3.APICode,
                    Cost = x.Cost,
                    APIId = x.APIId,
                    OperatorId = x.OperatorId,
                    TransId = x.TransactionId,
                    OpeningBal = x.OpeningBal,
                    ClosingBal = x.ClosingBal,
                    Status1 = x.Status,
                    Status = (x.Status == "Failure") ? "<span style='color:red'>FAILURE</span>" : ((x.Status == "Success") ? "<span style='color:green'>SUCCESS</span>" : ((x.Status == "In Process") ? "<span style='color:#FFAA55'>IN PROCESS<span>" : ((x.Status == "Reversed") ? "<span style='color:orange'>REVERSED</span>" : x.Status)))
                };
            if (status)
            {
                this.gvMain.Columns[9].Visible = false;
                this.gvMain.AllowPaging = false;
            }
            this.gvMain.DataSource = queryable2;
            this.gvMain.DataBind();
        }
        else
        {
            var queryable3 = from x in this.db.tblRecharges
                join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id 
                join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id 
                join z1 in this.db.tblServices on x.ServiceId equals (short?) z1.Id
                join z2 in this.db.tblUsers on x.UserId equals z2.Id 
                join z3 in this.db.tblApis on x.APIId equals (short?) z3.Id 
                let Name1 = z.OperatorName
                orderby x.RechargeDate descending
                select new { 
                    Id = x.Id,
                    UserId = x.UserId,
                    Number = x.Number,
                    Optional1 = x.Optional1,
                    Optional2 = x.Optional2,
                    Optional3 = x.Optional3,
                    Domain = z2.Domain,
                    Response = x.Response,
                    Username = (z2.Username + " [") + (z2.Id) + "]",
                    Amount = x.Amount,
                    API = z3.APICode,
                    Operator = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                    RechargeDate = x.RechargeDate,
                    CommAmt = x.CommAmt,
                    Mode = x.RechargeMode,
                    OpRef = x.OperatorRef,
                    Cost = x.Cost,
                    TransId = x.TransactionId,
                    OpeningBal = x.OpeningBal,
                    ClosingBal = x.ClosingBal,
                    Status1 = x.Status,
                    APIId = x.APIId,
                    OperatorId = x.OperatorId,
                    Status = (x.Status == "Failure") ? "<span style='color:red'>FAILURE</span>" : ((x.Status == "Success") ? "<span style='color:green'>SUCCESS</span>" : ((x.Status == "In Process") ? "<span style='color:#FFAA55'>IN PROCESS<span>" : ((x.Status == "Reversed") ? "<span style='color:orange'>REVERSED</span>" : x.Status)))
                };
            if (this.ddlUsers.SelectedIndex > 0)
            {
                queryable3 = from x in queryable3
                    where x.UserId == Convert.ToInt32(this.ddlUsers.SelectedValue)
                    select x;
            }
            if (((this.txtFrom.Text != null) && (this.txtFrom.Text != "")) && ((this.txtTo.Text != null) && (this.txtTo.Text != "")))
            {
                DateTime dt;
                DateTime dt2;
                DateTime.TryParseExact(this.txtFrom.Text.Split(new char[] { '/' })[1] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[0] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt);
                DateTime.TryParseExact(this.txtTo.Text.Split(new char[] { '/' })[1] + "/" + this.txtTo.Text.Split(new char[] { '/' })[0] + "/" + this.txtTo.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt2);
                queryable3 = from x in queryable3
                    where (x.RechargeDate.Date >= dt.Date) && (x.RechargeDate.Date <= dt2.Date)
                    select x;
            }
            if (base.Request["type"] != null)
            {
                this.ddlStatus.SelectedIndex = Convert.ToInt32(base.Request["type"].ToString());
            }
            if (this.ddlAPI.SelectedIndex > 0)
            {
                queryable3 = from x in queryable3
                    where ((int?) x.APIId) == Convert.ToInt16(this.ddlAPI.SelectedValue)
                    select x;
            }
            if (this.ddlOperator.SelectedIndex > 0)
            {
                queryable3 = from x in queryable3
                    where ((int?) x.OperatorId) == Convert.ToInt16(this.ddlOperator.SelectedValue)
                    select x;
            }
            if (this.ddlStatus.SelectedIndex > 0)
            {
                queryable3 = from x in queryable3
                    where x.Status1 == this.ddlStatus.SelectedValue
                    select x;
            }
            if (this.ddlDomain.SelectedIndex > 0)
            {
                queryable3 = from x in queryable3
                    where x.Domain == this.ddlDomain.SelectedValue
                    select x;
            }
            strArray = new string[13];
            strArray[0] = "Success: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Success
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[1] = num.ToString();
            strArray[2] = "</b> (Comm: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Success
                select x, x => x.CommAmt);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[3] = num.ToString();
            strArray[4] = "</b>, Cost: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Success
                select x, (x => (decimal?)x.Cost));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[5] = num.ToString();
            strArray[6] = "</b>) | Failure: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Failure
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[7] = num.ToString();
            strArray[8] = "</b> | Pending: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Pending
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[9] = num.ToString();
            strArray[10] = "</b> | Reversed: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Reversed
                                     select x, (x => (decimal?)x.Amount));
            strArray[11] = (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M).ToString();
            strArray[12] = "</b>";
            this.lblTotal.Text = string.Concat(strArray);
            if (status)
            {
                this.gvMain.Columns[9].Visible = false;
                this.gvMain.AllowPaging = false;
            }
            this.gvMain.DataSource = queryable3;
            this.gvMain.DataBind();
        }
    }

    protected void bttnExport_Click(object sender, EventArgs e)
    {
        this.ExportToExcel();
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData(false);
    }

    private void ddlBind()
    {
        var queryable = from x in this.db.tblUsers
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + (x.Id) + "]"
            };
        this.ddlUsers.DataSource = queryable;
        this.ddlUsers.DataTextField = "Name";
        this.ddlUsers.DataValueField = "Id";
        this.ddlUsers.DataBind();
        this.ddlUsers.Items.Insert(0, "All");
        var queryable2 = from x in this.db.tblOperators
            join z in this.db.tblMainComps on x.MainCompId equals (short?) z.Id
            join y in this.db.tblServices on z.ServiceId equals y.Id
            let Name1 = z.OperatorName
            orderby y.Id, z.OperatorName
            select new { 
                Id = x.Id,
                Name = (x.Operator != null) ? (((Name1 + " ") + x.Operator + " [") + y.ServiceName + "]") : ((Name1 + " [") + y.ServiceName + "]")
            };
        this.ddlOperator.DataSource = queryable2;
        this.ddlOperator.DataTextField = "Name";
        this.ddlOperator.DataValueField = "Id";
        this.ddlOperator.DataBind();
        this.ddlOperator.Items.Insert(0, "All");
        var queryable3 = from x in this.db.tblApis
            orderby x.APIName
            select new { 
                Id = x.Id,
                Name = x.APICode
            };
        this.ddlAPI.DataSource = queryable3;
        this.ddlAPI.DataTextField = "Name";
        this.ddlAPI.DataValueField = "Id";
        this.ddlAPI.DataBind();
        this.ddlAPI.Items.Insert(0, "All");
        var queryable4 = from x in this.db.tblUsers
            where x.UserType == clsVariables.UserType.Reseller
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = x.Domain
            };
        this.ddlDomain.DataSource = queryable4;
        this.ddlDomain.DataTextField = "Name";
        this.ddlDomain.DataValueField = "Name";
        this.ddlDomain.DataBind();
        this.ddlDomain.Items.Insert(0, "All");
        this.ddlStatus.DataSource = clsVariables.RechargeStatuss();
        this.ddlStatus.DataTextField = "Text";
        this.ddlStatus.DataValueField = "Value";
        this.ddlStatus.DataBind();
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData(false);
    }

    protected void ddlUpdate_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DropDownList list = sender as DropDownList;
            foreach (GridViewRow row in this.gvMain.Rows)
            {
                Control control = row.FindControl("ddlStatus") as DropDownList;
                Control control2 = row.FindControl("hfId") as HiddenField;
                if (control != null)
                {
                    DropDownList list2 = (DropDownList) control;
                    HiddenField hfId1 = (HiddenField) control2;
                    if (list.ClientID == list2.ClientID)
                    {
                        DataClassesDataContext context = new DataClassesDataContext();
                        if (list2.SelectedValue == clsVariables.RechargeStatus.Success)
                        {
                            tblRecharge recharge = Queryable.Single<tblRecharge>(context.tblRecharges, p => p.Id == Convert.ToInt32(hfId1.Value));
                            if (recharge.Status == clsVariables.RechargeStatus.Pending)
                            {
                                recharge.Status = clsVariables.RechargeStatus.Success;
                                context.SubmitChanges();
                                Queryable.Single<tblUser>(context.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                                tblUser user = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == recharge.UserId);
                                Queryable.Single<tblService>(context.tblServices, x => x.Id == recharge.ServiceId);
                                if (user.RechargeAPI)
                                {
                                    clsMethods.sendRequest(user.ResponseURL, ((recharge.Status == clsVariables.RechargeStatus.Success) ? "0" : ((recharge.Status == clsVariables.RechargeStatus.Failure) ? "1" : "2")) + "|" + recharge.TransactionId + "|" + recharge.ClientId.ToString() + "|" + recharge.OperatorRef + "|" + recharge.Status);
                                }
                                if (recharge.RechargeMode == clsVariables.RechargeMode.SMS)
                                {
                                    tblOperator getOperator = Queryable.Single<tblOperator>(context.tblOperators, x => x.Id == recharge.OperatorId);
                                    tblMainComp comp = Queryable.Single<tblMainComp>(context.tblMainComps, x => x.Id == getOperator.MainCompId);
                                    string message = string.Concat(new object[] { 
                                        "Your recharge has been ", recharge.Status.ToUpper(), ". Operator: ", comp.OperatorName, " ", getOperator.Operator, " | Number: ", recharge.Number, " | Amount: ", recharge.Amount, " | Cost: ", recharge.Cost, " | Recharge Id: ", recharge.Id.ToString(), " | Operator Ref.", recharge.OperatorRef,
                                        " | Old Bal: ", recharge.OpeningBal.ToString(), " | New Bal: ", clsMethods.getBalance(user.Id), ". Thanks."
                                    });
                                    clsMethods.sendSMS(user.Mobile, message, "26851");
                                }
                                this.bindData(false);
                                this.Popup.SetMessage("Status SUCCESS updated successfully", control_ShowMessage.MessageType.Success);
                            }
                            else if (recharge.Status == clsVariables.RechargeStatus.Failure)
                            {
                                recharge.Status = clsVariables.RechargeStatus.Success;
                                context.SubmitChanges();
                                tblUser user2 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                                tblUser user3 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == recharge.UserId);
                                tblService service = Queryable.Single<tblService>(context.tblServices, x => x.Id == recharge.ServiceId);
                                clsMethods.addTrans(recharge.UserId, recharge.Cost, "Recharge done on number: " + recharge.Number + " | " + recharge.Amount.ToString(), user2.Id, recharge.UserId, clsMethods.getBalance(user3.Id) - recharge.Cost, clsVariables.TransactionType.Recharge, recharge.Id, clsMethods.getBalance(user2.Id), clsMethods.getBalance(recharge.ResellerId.Value), recharge.ResellerId.Value, clsMethods.getABalance(recharge.ResellerId.Value) - recharge.Cost);
                                if (((service.ServiceName == clsVariables.ServiceType.Mobile) || (service.ServiceName == clsVariables.ServiceType.DTH)) || (service.ServiceName == clsVariables.ServiceType.DataCard))
                                {
                                    clsMethods.addReferelComm(user3.ParentId.Value, recharge.APIId.Value, recharge.OperatorId.Value, recharge.Amount, recharge.Number, user3.Username, user2.Id, recharge.CommPer.Value, recharge.UserId, recharge.Id, recharge.ResellerId.Value);
                                }
                                if (user3.RechargeAPI)
                                {
                                    clsMethods.sendRequest(user3.ResponseURL, ((recharge.Status == clsVariables.RechargeStatus.Success) ? "0" : ((recharge.Status == clsVariables.RechargeStatus.Failure) ? "1" : "2")) + "|" + recharge.TransactionId + "|" + recharge.ClientId.ToString() + "|" + recharge.OperatorRef + "|" + recharge.Status);
                                }
                                if (recharge.RechargeMode == clsVariables.RechargeMode.SMS)
                                {
                                    tblOperator getOperator = Queryable.Single<tblOperator>(context.tblOperators, x => x.Id == recharge.OperatorId);
                                    tblMainComp comp2 = Queryable.Single<tblMainComp>(context.tblMainComps, x => x.Id == getOperator.MainCompId);
                                    string str2 = string.Concat(new object[] { 
                                        "Your recharge has been ", recharge.Status.ToUpper(), ". Operator: ", comp2.OperatorName, " ", getOperator.Operator, " | Number: ", recharge.Number, " | Amount: ", recharge.Amount, " | Cost: ", recharge.Cost, " | Recharge Id: ", recharge.Id.ToString(), " | Operator Ref.", recharge.OperatorRef,
                                        " | Old Bal: ", recharge.OpeningBal.ToString(), " | New Bal: ", clsMethods.getBalance(user3.Id), ". Thanks."
                                    });
                                    clsMethods.sendSMS(user3.Mobile, str2, "26851");
                                }
                                this.bindData(false);
                                this.Popup.SetMessage("Status SUCCESS updated successfully", control_ShowMessage.MessageType.Success);
                            }
                            else
                            {
                                this.Popup.SetMessage("You can't update with same status", control_ShowMessage.MessageType.Warning);
                            }
                        }
                        else
                        {
                            decimal cost;
                            decimal? closingBal;
                            decimal? nullable5;
                            if (list2.SelectedValue == clsVariables.RechargeStatus.Failure)
                            {
                                tblRecharge recharge2 = Queryable.Single<tblRecharge>(context.tblRecharges, p => p.Id == Convert.ToInt32(hfId1.Value));
                                if (recharge2.Status == clsVariables.RechargeStatus.Pending)
                                {
                                    recharge2.Status = clsVariables.RechargeStatus.Failure;
                                    context.SubmitChanges();
                                    tblRecharge recharge = (from x in context.tblRecharges
                                        where x.UserId == recharge2.UserId
                                        orderby x.Id descending
                                        select x).FirstOrDefault<tblRecharge>();
                                    if (recharge != null)
                                    {
                                        recharge.Remarks = string.Concat(new object[] { "Recharge Id: ", recharge.Id.ToString(), " | Amount: ", recharge.Cost.ToString(), " | Balance: ", clsMethods.getBalance(recharge.UserId), " | New Balance: ", clsMethods.getBalance(recharge.UserId) + recharge.Cost });
                                        closingBal = recharge.ClosingBal;
                                        cost = recharge.Cost;
                                        recharge.ClosingBal = closingBal.HasValue ? new decimal?(closingBal.GetValueOrDefault() + cost) : ((decimal?) (nullable5 = null));
                                        context.SubmitChanges();
                                    }
                                    tblUser user4 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                                    tblUser user5 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == recharge.UserId);
                                    tblService service2 = Queryable.Single<tblService>(context.tblServices, x => x.Id == recharge.ServiceId);
                                    clsMethods.addTrans(-1, recharge.Cost, recharge.Remarks, recharge.UserId, recharge.UserId, clsMethods.getBalance(recharge.UserId) + recharge.Cost, clsVariables.TransactionType.RechargeFailure, 0L, clsMethods.getBalance(user4.Id), clsMethods.getBalance(recharge.ResellerId.Value), recharge.ResellerId.Value, clsMethods.getABalance(recharge.ResellerId.Value) + recharge.Cost);
                                    if (((service2.ServiceName == clsVariables.ServiceType.Mobile) || (service2.ServiceName == clsVariables.ServiceType.DTH)) || (service2.ServiceName == clsVariables.ServiceType.DataCard))
                                    {
                                        clsMethods.removeReferelComm2(user5.ParentId.Value, recharge.APIId.Value, recharge.OperatorId.Value, recharge.Amount, recharge.Number, user5.Username, user4.Id, recharge.CommPer.Value, recharge.UserId, recharge.Id, recharge.ResellerId.Value);
                                    }
                                    if (user5.RechargeAPI)
                                    {
                                        clsMethods.sendRequest(user5.ResponseURL, ((recharge.Status == clsVariables.RechargeStatus.Success) ? "0" : ((recharge.Status == clsVariables.RechargeStatus.Failure) ? "1" : "2")) + "|" + recharge.TransactionId + "|" + recharge.ClientId.ToString() + "|" + recharge.OperatorRef + "|" + recharge.Status);
                                    }
                                    if (recharge.RechargeMode == clsVariables.RechargeMode.SMS)
                                    {
                                        tblOperator getOperator = Queryable.Single<tblOperator>(context.tblOperators, x => x.Id == recharge.OperatorId);
                                        tblMainComp comp3 = Queryable.Single<tblMainComp>(context.tblMainComps, x => x.Id == getOperator.MainCompId);
                                        string str3 = string.Concat(new object[] { 
                                            "Your recharge has been ", recharge.Status.ToUpper(), ". Operator: ", comp3.OperatorName, " ", getOperator.Operator, " | Number: ", recharge.Number, " | Amount: ", recharge.Amount, " | Cost: ", recharge.Cost, " | Recharge Id: ", recharge.Id.ToString(), " | Operator Ref.", recharge.OperatorRef,
                                            " | Old Bal: ", recharge.OpeningBal.ToString(), " | New Bal: ", clsMethods.getBalance(user5.Id), ". Thanks."
                                        });
                                        clsMethods.sendSMS(user5.Mobile, str3, "26851");
                                    }
                                    this.bindData(false);
                                    this.Popup.SetMessage("Status FAILURE updated successfully", control_ShowMessage.MessageType.Success);
                                }
                                else
                                {
                                    this.Popup.SetMessage("You can't update with same status", control_ShowMessage.MessageType.Warning);
                                }
                            }
                            else if (list2.SelectedValue == clsVariables.RechargeStatus.Reversed)
                            {
                                tblRecharge recharge = Queryable.Single<tblRecharge>(context.tblRecharges, p => p.Id == Convert.ToInt32(hfId1.Value));
                                if (recharge.Status == clsVariables.RechargeStatus.Success)
                                {
                                    recharge.Status = clsVariables.RechargeStatus.Reversed;
                                    context.SubmitChanges();
                                    tblRecharge recharge2 = (from x in context.tblRecharges
                                        where x.UserId == recharge.UserId
                                        orderby x.Id descending
                                        select x).FirstOrDefault<tblRecharge>();
                                    if (recharge2 != null)
                                    {
                                        recharge.Remarks = string.Concat(new object[] { "Recharge Id: ", recharge.Id.ToString(), " | Amount: ", recharge.Cost.ToString(), " | Balance: ", clsMethods.getBalance(recharge2.UserId), " | New Balance: ", clsMethods.getBalance(recharge2.UserId) + recharge.Cost });
                                        closingBal = recharge2.ClosingBal;
                                        cost = recharge.Cost;
                                        recharge2.ClosingBal = closingBal.HasValue ? new decimal?(closingBal.GetValueOrDefault() + cost) : ((decimal?) (nullable5 = null));
                                        context.SubmitChanges();
                                    }
                                    tblUser user6 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                                    tblUser user7 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == recharge.UserId);
                                    tblService service3 = Queryable.Single<tblService>(context.tblServices, x => x.Id == recharge.ServiceId);
                                    clsMethods.addTrans(-1, recharge.Cost, recharge.Remarks, recharge.UserId, recharge.UserId, clsMethods.getBalance(recharge.UserId) + recharge.Cost, clsVariables.TransactionType.RechargeRevert, 0L, clsMethods.getBalance(user6.Id), clsMethods.getBalance(recharge.ResellerId.Value), recharge.ResellerId.Value, clsMethods.getABalance(recharge.ResellerId.Value) + recharge.Cost);
                                    if (((service3.ServiceName == clsVariables.ServiceType.Mobile) || (service3.ServiceName == clsVariables.ServiceType.DTH)) || (service3.ServiceName == clsVariables.ServiceType.DataCard))
                                    {
                                        clsMethods.removeReferelComm2(user7.ParentId.Value, recharge.APIId.Value, recharge.OperatorId.Value, recharge.Amount, recharge.Number, user7.Username, user6.Id, recharge.CommPer.Value, recharge.UserId, recharge.Id, recharge.ResellerId.Value);
                                    }
                                    if (user7.RechargeAPI)
                                    {
                                        clsMethods.sendRequest(user7.ResponseURL, ((recharge.Status == clsVariables.RechargeStatus.Success) ? "0" : ((recharge.Status == clsVariables.RechargeStatus.Failure) ? "1" : "2")) + "|" + recharge.TransactionId + "|" + recharge.ClientId.ToString() + "|" + recharge.OperatorRef + "|" + recharge.Status);
                                    }
                                    if (recharge.RechargeMode == clsVariables.RechargeMode.SMS)
                                    {
                                        tblOperator getOperator = Queryable.Single<tblOperator>(context.tblOperators, x => x.Id == recharge.OperatorId);
                                        tblMainComp comp4 = Queryable.Single<tblMainComp>(context.tblMainComps, x => x.Id == getOperator.MainCompId);
                                        string str4 = string.Concat(new object[] { 
                                            "Your recharge has been ", recharge.Status.ToUpper(), ". Operator: ", comp4.OperatorName, " ", getOperator.Operator, " | Number: ", recharge.Number, " | Amount: ", recharge.Amount, " | Cost: ", recharge.Cost, " | Recharge Id: ", recharge.Id.ToString(), " | Operator Ref.", recharge.OperatorRef,
                                            " | Old Bal: ", recharge.OpeningBal.ToString(), " | New Bal: ", clsMethods.getBalance(user7.Id), ". Thanks."
                                        });
                                        clsMethods.sendSMS(user7.Mobile, str4, "26851");
                                    }
                                    this.bindData(false);
                                    this.Popup.SetMessage("Status REVERSED updated successfully", control_ShowMessage.MessageType.Success);
                                }
                                else
                                {
                                    this.Popup.SetMessage("You can't update with same status", control_ShowMessage.MessageType.Warning);
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void ExportToExcel()
    {
        HtmlForm child = new HtmlForm();
        string str = "attachment;filename=" + DateTime.Now.ToString("dd-MM-yyyy") + "_RechargeReport.xls";
        base.Response.ClearContent();
        this.bindData(true);
        base.Response.AddHeader("content-disposition", str);
        base.Response.ContentType = "application/vnd.ms-excel";
        StringWriter writer = new StringWriter();
        HtmlTextWriter writer2 = new HtmlTextWriter(writer);
        child.Controls.Add(this.gvMain);
        this.Controls.Add(child);
        child.RenderControl(writer2);
        base.Response.Write(writer.ToString());
        base.Response.End();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData(false);
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "15",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList list = (DropDownList) e.Row.FindControl("ddlStatus");
            HiddenField field = (HiddenField) e.Row.FindControl("hfStatus");
            if (field.Value == clsVariables.RechargeStatus.Pending)
            {
                list.DataSource = from x in clsVariables.RechargeStatuss2()
                    where (x.Value != clsVariables.RechargeStatus.Pending) && (x.Value != clsVariables.RechargeStatus.Reversed)
                    select x;
                list.DataTextField = "Text";
                list.DataValueField = "Value";
                list.DataBind();
            }
            else if (field.Value == clsVariables.RechargeStatus.Failure)
            {
                list.DataSource = from x in clsVariables.RechargeStatuss2()
                    where (x.Value != clsVariables.RechargeStatus.Failure) && (x.Value != clsVariables.RechargeStatus.Reversed)
                    select x;
                list.DataTextField = "Text";
                list.DataValueField = "Value";
                list.DataBind();
            }
            else if (field.Value == clsVariables.RechargeStatus.Success)
            {
                list.DataSource = from x in clsVariables.RechargeStatuss2()
                    where (x.Value != clsVariables.RechargeStatus.Success) && (x.Value != clsVariables.RechargeStatus.Failure)
                    select x;
                list.DataTextField = "Text";
                list.DataValueField = "Value";
                list.DataBind();
            }
            else if (field.Value == clsVariables.RechargeStatus.Reversed)
            {
                list.DataSource = from x in clsVariables.RechargeStatuss2()
                    where x.Value != clsVariables.RechargeStatus.Reversed
                    select x;
                list.DataTextField = "Text";
                list.DataValueField = "Value";
                list.DataBind();
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.txtTo.Text = this.txtFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            this.bindData(false);
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
    }

  
}
