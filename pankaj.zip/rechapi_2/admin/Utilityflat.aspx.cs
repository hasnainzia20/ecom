﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

public partial class user_Profile : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
    public void gridbind()
    {

        //   string lid = Session["UserId"].ToString();
        string rstr = "select Id,MinAmt,MaxAmt,Charge,Type,UserType,Service from tblUtilityRange ";

        //  string rstr = "SELECT     txn_id, txn_date, cust_id, opr_name, details, mycomm, cr, dr, cust_bal, actions, txn_amt, o_bal, c_bal, status, remarks, res_id, rechargetype, sboxid, response_time, opr_rec_code, api_txn_type, agent_id, apisourcecode FROM  txn_rec where cust_id ='" + lid + "' and rechargetype in(201,202,203,204)  ORDER BY txn_date DESC;";
        SqlCommand com = new SqlCommand(rstr, con);
        SqlDataAdapter myAdapter = new SqlDataAdapter();
        myAdapter.SelectCommand = com;
        DataSet myDataSet = new DataSet();
        myAdapter.Fill(myDataSet);

        GridView11.DataSource = myDataSet;
        GridView11.DataBind();
    }
    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "manage")
        {

            ob ob = new ob();
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            Int64 acnoo = Convert.ToInt64(commandArgs[0]);
            Int64 id = Convert.ToInt64(commandArgs[1]);
            this.bid2.Value = Convert.ToString(id);
            this.flbl2.Text = "Manage Range Charge";
            string MINAMTA = ob.executescalar("select MinAmt  from tblUtilityRange where Id='" + bid2.Value + "'").ToString();
            min1.Text = MINAMTA;
            string MINAMTA2 = ob.executescalar("select MaxAmt  from tblUtilityRange where Id='" + bid2.Value + "'").ToString();
            max1.Text = MINAMTA2;
            string MINAMTA3 = ob.executescalar("select Charge  from tblUtilityRange where Id='" + bid2.Value + "'").ToString();
            charge1.Text = MINAMTA3;
            string MINAMTA4 = ob.executescalar("select Type  from tblUtilityRange where Id='" + bid2.Value + "'").ToString();
            ctype2.Text = MINAMTA4;
            string MINAMTA5 = ob.executescalar("select UserType  from tblUtilityRange where Id='" + bid2.Value + "'").ToString();
            utype2.Text = MINAMTA5;
            string MINAMTA6 = ob.executescalar("select Service  from tblUtilityRange where Id='" + bid2.Value + "'").ToString();
            stype2.Text = MINAMTA6;
            this.fupopuu.Show();

        }
        else if (e.CommandName == "lnkDelete")
        {
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            Int64 acnooo = Convert.ToInt64(commandArgs[0]);
            Int64 idd = Convert.ToInt64(commandArgs[1]);
            String st = "";
            ob ob1 = new ob();
            string insertvalue = "delete from tblUtilityRange where Id='" + Convert.ToString(idd) + "'";
            string insdatarecharge = ob1.executenonscalar(insertvalue).ToString();
            this.Popup.SetMessage("Utility Range Charge Deleted Successfully", control_ShowMessage.MessageType.Success);

            this.gridbind();



        }
    }

    protected void lnkOpen_Click(object sender, EventArgs e)
    {

        this.fupop.Show();
        this.flbl.Text = "Add Range Charge";

    }
    protected void updaterenge_Click(object sender, EventArgs e)
    {
        try
        {

            ob ob1 = new ob();
            string insertvalue1 = "UPDATE tblUtilityRange SET MinAmt = '" + min1.Text + "', MaxAmt = '" + max1.Text + "', Charge = '" + charge1.Text + "', Type = '" + ctype2.Text + "', UserType = '" + utype2.Text + "', Service = '" + stype2.Text + "' WHERE Id = '" + bid2.Value + "';";
            string insdatarecharge1 = ob1.executenonscalar(insertvalue1).ToString();
            this.Popup.SetMessage("Utility Range Charge Updated Successfully", control_ShowMessage.MessageType.Success);
            this.fupopuu.Hide();
            this.gridbind();
        }
        catch (Exception ex)
        {
            this.fupopuu.Hide();
            this.Popup.SetMessage(ex.Message, control_ShowMessage.MessageType.Warning);

        }

    }
    protected void addrenge_Click(object sender, EventArgs e)
    {
        try
        {
            ob ob1 = new ob();
            string insertvalue = "insert into tblUtilityRange values ('" + min.Text + "','" + max.Text + "','" + charge.Text + "','" + ctype.Text + "','" + utype.Text + "','" + stype.Text + "')";
            string insdatarecharge = ob1.executenonscalar(insertvalue).ToString();
            this.fupop.Hide();
            this.gridbind();
            this.Popup.SetMessage("Utility Range Charge Added Successfully", control_ShowMessage.MessageType.Success);
        }
        catch (Exception ex)
        {
            this.fupop.Hide();
            this.Popup.SetMessage(ex.Message, control_ShowMessage.MessageType.Warning);

        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            ob ob = new ob();
            this.gridbind();


        }
    }
  
    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }
}
