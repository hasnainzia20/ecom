﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


public partial class edit : ThemeClass, IRequiresSessionState

{
    DataClassesDataContext context = new DataClassesDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
      
    }
    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        
        
        try
        {
            tblRecharge recharge = Queryable.SingleOrDefault<tblRecharge>(context.tblRecharges, x => x.Id == Convert.ToInt64(rid.Text));
            this.Refid.Text = Convert.ToString(recharge.Id);
            this.number.Text = Convert.ToString(recharge.Number);
            this.tid.Text = Convert.ToString(recharge.TransactionId);
            this.Oid.Text = Convert.ToString(recharge.OperatorRef);

            this.popup1222.Show();
        }
        catch
        {
            this.Popup.SetMessage("Sorry!, Ref. Id not found", control_ShowMessage.MessageType.Warning);
        }
    
    }

    protected void bttnAdd2_Click(object sender, EventArgs e)
    {
        tblRecharge recharge = Queryable.SingleOrDefault<tblRecharge>(context.tblRecharges, x => x.Id == Convert.ToInt64(rid.Text));
        recharge.Number = number.Text;
        recharge.TransactionId = tid.Text;
        recharge.OperatorRef = Oid.Text;
        
        this.context.SubmitChanges();
        this.popup1222.Hide();
        this.Popup.SetMessage("Recharge Modified Successfully", control_ShowMessage.MessageType.Success);
    }
   
}
	