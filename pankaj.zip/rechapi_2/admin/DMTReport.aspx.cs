﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Globalization;


public partial class admin_rechargeReport : ThemeClass, IRequiresSessionState
{
 
    private DataClassesDataContext db = new DataClassesDataContext();
 

    private void bindData(bool status)
    {
        string[] strArray;
        decimal? nullable;
        decimal num;
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            var queryable = from x in this.db.tblRecharges
                join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id
                join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id
                join z1 in this.db.tblServices on x.ServiceId equals (short?) z1.Id
                join z2 in this.db.tblUsers on x.UserId equals z2.Id 
                join z3 in this.db.tblApis on x.APIId equals (short?) z3.Id 
                let Name1 = z.OperatorName
                where (x.Id.ToString().Contains(this.txtSearch.Text) || (x.Number == this.txtSearch.Text)) || (x.TransactionId == this.txtSearch.Text) && (x.OperatorId == 108)
                orderby x.RechargeDate descending
                select new { 
                    Id = x.Id,
                    UserId = x.UserId,
                    Number = x.Number,
                    Username = (z2.Username + " [") + (z2.Id) + "]",
                    Amount = x.Amount,
                    API = z3.APICode,
                    Response = x.Response,
                    Operator = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                    RechargeDate = x.RechargeDate,
                    CommAmt = x.CommAmt,
                    Cost = x.Cost,
                    Mode = x.RechargeMode,
                    Domain = z2.Domain,
                    OpRef = x.OperatorRef,
                    TransId = x.TransactionId,
                    OpeningBal = x.OpeningBal,
                    ClosingBal = x.ClosingBal,
                    Status1 = x.Status,
                    APIId = x.APIId,
                    OperatorId = x.OperatorId,
                    Status = (x.Status == "Failure") ? "<span style='color:red'>FAILURE</span>" : ((x.Status == "Success") ? "<span style='color:green'>SUCCESS</span>" : ((x.Status == "In Process") ? "<span style='color:#FFAA55'>IN PROCESS<span>" : ((x.Status == "Reversed") ? "<span style='color:orange'>REVERSED</span>" : x.Status)))
                };

            strArray = new string[9];
            strArray[0] = "Success: <b>";
            nullable = Queryable.Sum(from x in queryable where x.Status1 == clsVariables.RechargeStatus.Success select x, x => x.Amount);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[1] = num.ToString();
            strArray[2] = "</b> | Failure: <b>";
            nullable = Queryable.Sum(from x in queryable where x.Status1 == clsVariables.RechargeStatus.Failure select x, x => x.Amount);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[3] = num.ToString();
            strArray[4] = "</b> | Pending: <b>";
            nullable = Queryable.Sum(from x in queryable where x.Status1 == clsVariables.RechargeStatus.Pending select x, x => x.Amount);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[5] = num.ToString();
            strArray[6] = "</b> | Reversed: <b>";
            nullable = Queryable.Sum(from x in queryable where x.Status1 == clsVariables.RechargeStatus.Reversed select x, x => x.Amount);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[7] = num.ToString();
            strArray[8] = "</b>";
            this.lblTotal.Text = string.Concat(strArray);
            if (status)
            {
                this.gvMain.Columns[9].Visible = false;
                this.gvMain.AllowPaging = false;
            }
            this.gvMain.DataSource = queryable;
            this.gvMain.DataBind();
        }
        else if ((base.Request["id"] != null) && (base.Request["id"] != ""))
        {
            var queryable2 = from x in this.db.tblRecharges
                join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id 
                join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id
                join z1 in this.db.tblServices on x.ServiceId equals (short?) z1.Id 
                join z2 in this.db.tblUsers on x.UserId equals z2.Id 
                join z3 in this.db.tblApis on x.APIId equals (short?) z3.Id
                             where x.Id == Convert.ToInt32(this.Request["id"].ToString()) && (x.OperatorId == 108)
                let Name1 = z.OperatorName
                orderby x.RechargeDate descending
                select new { 
                    Id = x.Id,
                    UserId = x.UserId,
                    Domain = z2.Domain,
                    Number = x.Number,
                    Username = (z2.Username + " [") + (z2.Id) + "]",
                    Amount = x.Amount,
                    Response = x.Response,
                    OpRef = x.OperatorRef,
                    Mode = x.RechargeMode,
                    Operator = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                    RechargeDate = x.RechargeDate,
                    CommAmt = x.CommAmt,
                    API = z3.APICode,
                    Cost = x.Cost,
                    APIId = x.APIId,
                    OperatorId = x.OperatorId,
                    TransId = x.TransactionId,
                    OpeningBal = x.OpeningBal,
                    ClosingBal = x.ClosingBal,
                    Status1 = x.Status,
                    Status = (x.Status == "Failure") ? "<span style='color:red'>FAILURE</span>" : ((x.Status == "Success") ? "<span style='color:green'>SUCCESS</span>" : ((x.Status == "In Process") ? "<span style='color:#FFAA55'>IN PROCESS<span>" : ((x.Status == "Reversed") ? "<span style='color:orange'>REVERSED</span>" : x.Status)))
                };
            if (status)
            {
                this.gvMain.Columns[9].Visible = false;
                this.gvMain.AllowPaging = false;
            }
            this.gvMain.DataSource = queryable2;
            this.gvMain.DataBind();
        }
        else
        {
            var queryable3 = from x in this.db.tblRecharges
                join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id 
                join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id 
                join z1 in this.db.tblServices on x.ServiceId equals (short?) z1.Id 
                join z2 in this.db.tblUsers on x.UserId equals z2.Id 
                join z3 in this.db.tblApis on x.APIId equals (short?) z3.Id 
                where  (x.OperatorId == 108)
                let Name1 = z.OperatorName
                orderby x.RechargeDate descending
                select new { 
                    Id = x.Id,
                    UserId = x.UserId,
                    Number = x.Number,
                    Domain = z2.Domain,
                    Response = x.Response,
                    Username = (z2.Username + " [") + (z2.Id) + "]",
                    Amount = x.Amount,
                    API = z3.APICode,
                    Operator = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                    RechargeDate = x.RechargeDate,
                    CommAmt = x.CommAmt,
                    Mode = x.RechargeMode,
                    OpRef = x.OperatorRef,
                    Cost = x.Cost,
                    TransId = x.TransactionId,
                    OpeningBal = x.OpeningBal,
                    ClosingBal = x.ClosingBal,
                    Status1 = x.Status,
                    APIId = x.APIId,
                    OperatorId = x.OperatorId,
                    Status = (x.Status == "Failure") ? "<span style='color:red'>FAILURE</span>" : ((x.Status == "Success") ? "<span style='color:green'>SUCCESS</span>" : ((x.Status == "In Process") ? "<span style='color:#FFAA55'>IN PROCESS<span>" : ((x.Status == "Reversed") ? "<span style='color:orange'>REVERSED</span>" : x.Status)))
                };
            if (this.ddlUsers.SelectedIndex > 0)
            {
                queryable3 = from x in queryable3
                    where x.UserId == Convert.ToInt32(this.ddlUsers.SelectedValue)
                    select x;
            }
            if (((this.txtFrom.Text != null) && (this.txtFrom.Text != "")) && ((this.txtTo.Text != null) && (this.txtTo.Text != "")))
            {
                DateTime dt;
                DateTime dt2;
                DateTime.TryParseExact(this.txtFrom.Text.Split(new char[] { '/' })[1] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[0] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt);
                DateTime.TryParseExact(this.txtTo.Text.Split(new char[] { '/' })[1] + "/" + this.txtTo.Text.Split(new char[] { '/' })[0] + "/" + this.txtTo.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt2);
                queryable3 = from x in queryable3
                             where (x.RechargeDate.Date >= dt.Date) && (x.RechargeDate.Date <= dt2.Date)
                    select x;
            }
            if (base.Request["type"] != null)
            {
                this.ddlStatus.SelectedIndex = Convert.ToInt32(base.Request["type"].ToString());
            }
          
          
            if (this.ddlStatus.SelectedIndex > 0)
            {
                queryable3 = from x in queryable3
                    where x.Status1 == this.ddlStatus.SelectedValue
                    select x;
            }
            if (this.ddlDomain.SelectedIndex > 0)
            {
                queryable3 = from x in queryable3
                    where x.Domain == this.ddlDomain.SelectedValue
                    select x;
            }
            strArray = new string[13];
            strArray[0] = "Success: <b>";
            nullable = Queryable.Sum(from x in queryable3 where x.Status1 == clsVariables.RechargeStatus.Success select x, x => (decimal?)x.Amount);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[1] = num.ToString();
            strArray[2] = "</b> (Comm: <b>";
            nullable = Queryable.Sum(from x in queryable3 where x.Status1 == clsVariables.RechargeStatus.Success select x, x => (decimal?)x.CommAmt);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[3] = num.ToString();
            strArray[4] = "</b>, Cost: <b>";
            nullable = Queryable.Sum(from x in queryable3 where x.Status1 == clsVariables.RechargeStatus.Success select x, x => (decimal?)x.Cost);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[5] = num.ToString();
            strArray[6] = "</b>) | Failure: <b>";
            nullable = Queryable.Sum(from x in queryable3 where x.Status1 == clsVariables.RechargeStatus.Failure select x, x => (decimal?)x.Amount);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[7] = num.ToString();
            strArray[8] = "</b> | Pending: <b>";
            nullable = Queryable.Sum(from x in queryable3 where x.Status1 == clsVariables.RechargeStatus.Pending select x, x => (decimal?)x.Amount);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[9] = num.ToString();
            strArray[10] = "</b> | Reversed: <b>";
            nullable = Queryable.Sum(from x in queryable3 where x.Status1 == clsVariables.RechargeStatus.Reversed select x, x => (decimal?)x.Amount);
            strArray[11] = (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M).ToString();
            strArray[12] = "</b>";
            this.lblTotal.Text = string.Concat(strArray);
            if (status)
            {
                this.gvMain.Columns[9].Visible = false;
                this.gvMain.AllowPaging = false;
            }
            this.gvMain.DataSource = queryable3;
            this.gvMain.DataBind();
        }
    }

    protected void bttnExport_Click(object sender, EventArgs e)
    {
        this.ExportToExcel();
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData(false);
    }

    private void ddlBind()
    {
        var queryable = from x in this.db.tblUsers
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + (x.Id) + "]"
            };
        this.ddlUsers.DataSource = queryable;
        this.ddlUsers.DataTextField = "Name";
        this.ddlUsers.DataValueField = "Id";
        this.ddlUsers.DataBind();
        this.ddlUsers.Items.Insert(0, "All");
       
      
        var queryable4 = from x in this.db.tblUsers
            where x.UserType == clsVariables.UserType.Reseller
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = x.Domain
            };
        this.ddlDomain.DataSource = queryable4;
        this.ddlDomain.DataTextField = "Name";
        this.ddlDomain.DataValueField = "Name";
        this.ddlDomain.DataBind();
        this.ddlDomain.Items.Insert(0, "All");
        this.ddlStatus.DataSource = clsVariables.RechargeStatuss();
        this.ddlStatus.DataTextField = "Text";
        this.ddlStatus.DataValueField = "Value";
        this.ddlStatus.DataBind();
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData(false);
    }

    protected void ddlUpdate_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DropDownList list = sender as DropDownList;
            foreach (GridViewRow row in this.gvMain.Rows)
            {
                Control control = row.FindControl("ddlStatus") as DropDownList;
                Control control2 = row.FindControl("hfId") as HiddenField;
                if (control != null)
                {
                    DropDownList list2 = (DropDownList) control;
                    HiddenField hfId1 = (HiddenField) control2;
                    if (list.ClientID == list2.ClientID)
                    {
                        DataClassesDataContext context = new DataClassesDataContext();
                        if (list2.SelectedValue == clsVariables.RechargeStatus.Success)
                        {
                            tblRecharge recharge = Queryable.Single<tblRecharge>(context.tblRecharges, p => p.Id == Convert.ToInt32(hfId1.Value));
                            if (recharge.Status == clsVariables.RechargeStatus.Pending)
                            {
                                recharge.Status = clsVariables.RechargeStatus.Success;
                                context.SubmitChanges();
                                Queryable.Single<tblUser>(context.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                                tblUser user = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == recharge.UserId);
                                Queryable.Single<tblService>(context.tblServices, x => x.Id == recharge.ServiceId);
                              
                                this.bindData(false);
                                this.Popup.SetMessage("Status SUCCESS updated successfully", control_ShowMessage.MessageType.Success);
                            }
                            else if (recharge.Status == clsVariables.RechargeStatus.Failure)
                            {
                                recharge.Status = clsVariables.RechargeStatus.Success;
                                context.SubmitChanges();
                                tblUser user2 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                                tblUser user3 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == recharge.UserId);
                                tblService service = Queryable.Single<tblService>(context.tblServices, x => x.Id == recharge.ServiceId);
                                clsMethods.addTrans(recharge.UserId, recharge.Cost, "Recharge done on number: " + recharge.Number + " | " + recharge.Amount.ToString(), user2.Id, recharge.UserId, clsMethods.getBalance(user3.Id) - recharge.Cost, clsVariables.TransactionType.Recharge, recharge.Id, clsMethods.getBalance(user2.Id), clsMethods.getBalance(recharge.ResellerId.Value), recharge.ResellerId.Value, clsMethods.getABalance(recharge.ResellerId.Value) - recharge.Cost);
                                if (((service.ServiceName == clsVariables.ServiceType.Mobile) || (service.ServiceName == clsVariables.ServiceType.DTH)) || (service.ServiceName == clsVariables.ServiceType.DataCard))
                                {
                                    clsMethods.addReferelComm(user3.ParentId.Value, recharge.APIId.Value, recharge.OperatorId.Value, recharge.Amount, recharge.Number, user3.Username, user2.Id, recharge.CommPer.Value, recharge.UserId, recharge.Id, recharge.ResellerId.Value);
                                }
                              
                                this.bindData(false);
                                this.Popup.SetMessage("Status SUCCESS updated successfully", control_ShowMessage.MessageType.Success);
                            }
                            else
                            {
                                this.Popup.SetMessage("You can't update with same status", control_ShowMessage.MessageType.Warning);
                            }
                        }
                        else
                        {
                            decimal cost;
                            decimal? closingBal;
                            decimal? nullable5;
                            if (list2.SelectedValue == clsVariables.RechargeStatus.Failure)
                            {
                                tblRecharge recharge2 = Queryable.Single<tblRecharge>(context.tblRecharges, p => p.Id == Convert.ToInt32(hfId1.Value));
                                if (recharge2.Status == clsVariables.RechargeStatus.Pending)
                                {
                                    recharge2.Status = clsVariables.RechargeStatus.Failure;
                                    context.SubmitChanges();
                                    tblRecharge recharge = (from x in context.tblRecharges
                                        where x.UserId == recharge2.UserId
                                        orderby x.Id descending
                                        select x).FirstOrDefault<tblRecharge>();
                                    if (recharge != null)
                                    {
                                        recharge.Remarks = string.Concat(new object[] { "Transfer Id: ", recharge.Id.ToString(), " | Amount: ", recharge.Cost.ToString(), " | Balance: ", clsMethods.getBalance(recharge.UserId), " | New Balance: ", clsMethods.getBalance(recharge.UserId) + recharge.Cost });
                                        closingBal = recharge.ClosingBal;
                                        cost = recharge.Cost;
                                        recharge.ClosingBal = closingBal.HasValue ? new decimal?(closingBal.GetValueOrDefault() + cost) : ((decimal?) (nullable5 = null));
                                        context.SubmitChanges();
                                    }
                                    tblUser user4 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                                    tblUser user5 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == recharge.UserId);
                                    tblService service2 = Queryable.Single<tblService>(context.tblServices, x => x.Id == recharge.ServiceId);
                                    clsMethods.addTrans(-1, recharge.Cost, recharge.Remarks, recharge.UserId, recharge.UserId, clsMethods.getBalance(recharge.UserId) + recharge.Cost, clsVariables.TransactionType.RechargeFailure, 0L, clsMethods.getBalance(user4.Id), clsMethods.getBalance(recharge.ResellerId.Value), recharge.ResellerId.Value, clsMethods.getABalance(recharge.ResellerId.Value) + recharge.Cost);
                                    if (((service2.ServiceName == clsVariables.ServiceType.Mobile) || (service2.ServiceName == clsVariables.ServiceType.DTH)) || (service2.ServiceName == clsVariables.ServiceType.DataCard))
                                    {
                                        clsMethods.removeReferelComm2(user5.ParentId.Value, recharge.APIId.Value, recharge.OperatorId.Value, recharge.Amount, recharge.Number, user5.Username, user4.Id, recharge.CommPer.Value, recharge.UserId, recharge.Id, recharge.ResellerId.Value);
                                    }
                                   
                                    this.bindData(false);
                                    this.Popup.SetMessage("Status FAILURE updated successfully", control_ShowMessage.MessageType.Success);
                                }
                                else
                                {
                                    this.Popup.SetMessage("You can't update with same status", control_ShowMessage.MessageType.Warning);
                                }
                            }
                            else if (list2.SelectedValue == clsVariables.RechargeStatus.Reversed)
                            {
                                tblRecharge recharge = Queryable.Single<tblRecharge>(context.tblRecharges, p => p.Id == Convert.ToInt32(hfId1.Value));
                                if (recharge.Status == clsVariables.RechargeStatus.Success)
                                {
                                    recharge.Status = clsVariables.RechargeStatus.Reversed;
                                    context.SubmitChanges();
                                    tblRecharge recharge2 = (from x in context.tblRecharges
                                        where x.UserId == recharge.UserId
                                        orderby x.Id descending
                                        select x).FirstOrDefault<tblRecharge>();
                                    if (recharge2 != null)
                                    {
                                        recharge.Remarks = string.Concat(new object[] { "Transfer Id: ", recharge.Id.ToString(), " | Amount: ", recharge.Cost.ToString(), " | Balance: ", clsMethods.getBalance(recharge2.UserId), " | New Balance: ", clsMethods.getBalance(recharge2.UserId) + recharge.Cost });
                                        closingBal = recharge2.ClosingBal;
                                        cost = recharge.Cost;
                                        recharge2.ClosingBal = closingBal.HasValue ? new decimal?(closingBal.GetValueOrDefault() + cost) : ((decimal?) (nullable5 = null));
                                        context.SubmitChanges();
                                    }
                                    tblUser user6 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                                    tblUser user7 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == recharge.UserId);
                                    tblService service3 = Queryable.Single<tblService>(context.tblServices, x => x.Id == recharge.ServiceId);
                                    clsMethods.addTrans(-1, recharge.Cost, recharge.Remarks, recharge.UserId, recharge.UserId, clsMethods.getBalance(recharge.UserId) + recharge.Cost, clsVariables.TransactionType.RechargeRevert, 0L, clsMethods.getBalance(user6.Id), clsMethods.getBalance(recharge.ResellerId.Value), recharge.ResellerId.Value, clsMethods.getABalance(recharge.ResellerId.Value) + recharge.Cost);
                                    if (((service3.ServiceName == clsVariables.ServiceType.Mobile) || (service3.ServiceName == clsVariables.ServiceType.DTH)) || (service3.ServiceName == clsVariables.ServiceType.DataCard))
                                    {
                                        clsMethods.removeReferelComm2(user7.ParentId.Value, recharge.APIId.Value, recharge.OperatorId.Value, recharge.Amount, recharge.Number, user7.Username, user6.Id, recharge.CommPer.Value, recharge.UserId, recharge.Id, recharge.ResellerId.Value);
                                    }
                                   
                                    this.bindData(false);
                                    this.Popup.SetMessage("Status REVERSED updated successfully", control_ShowMessage.MessageType.Success);
                                }
                                else
                                {
                                    this.Popup.SetMessage("You can't update with same status", control_ShowMessage.MessageType.Warning);
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void ExportToExcel()
    {
        HtmlForm child = new HtmlForm();
        string str = "attachment;filename=" + DateTime.Now.ToString("dd-MM-yyyy") + "_RechargeReport.xls";
        base.Response.ClearContent();
        this.bindData(true);
        base.Response.AddHeader("content-disposition", str);
        base.Response.ContentType = "application/vnd.ms-excel";
        StringWriter writer = new StringWriter();
        HtmlTextWriter writer2 = new HtmlTextWriter(writer);
        child.Controls.Add(this.gvMain);
        this.Controls.Add(child);
        child.RenderControl(writer2);
        base.Response.Write(writer.ToString());
        base.Response.End();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData(false);
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkbd")
        {
            string number = e.CommandArgument.ToString();
           
            ob ob = new ob();
           
            string type = ob.executescalar("select top 1 b_type from tblbeneficiary_details where b_acno='" + number + "'").ToString();

            string bname = ob.executescalar("select top 1 b_bankname from tblbeneficiary_details where b_acno='" + number + "'").ToString();
            string ifscc = ob.executescalar("select top 1 b_ifc_code from tblbeneficiary_details where b_acno='" + number + "'").ToString();
            string acno = ob.executescalar("select top 1 b_acno from tblbeneficiary_details where b_acno='" + number + "'").ToString();
            string baname = ob.executescalar("select top 1 b_name from tblbeneficiary_details where b_acno='" + number + "'").ToString();
          
            string mobb = ob.executescalar("select top 1 b_msisdn from tblbeneficiary_details where b_acno='" + number + "'").ToString();
            this.lblTitle2.Text = "Money Transfer Account Details";
            this.Label1.Text = baname;
            this.Label7.Text = bname;
            this.Label2.Text = acno;
            this.Label3.Text = ifscc;
            this.Label4.Text = type;
           
            this.Label6.Text = mobb;
            this.popup1333.Show();
        }
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "15",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList list = (DropDownList) e.Row.FindControl("ddlStatus");
            HiddenField field = (HiddenField) e.Row.FindControl("hfStatus");
            if (field.Value == clsVariables.RechargeStatus.Pending)
            {
                list.DataSource = from x in clsVariables.RechargeStatuss2()
                    where (x.Value != clsVariables.RechargeStatus.Pending) && (x.Value != clsVariables.RechargeStatus.Reversed)
                    select x;
                list.DataTextField = "Text";
                list.DataValueField = "Value";
                list.DataBind();
            }
            else if (field.Value == clsVariables.RechargeStatus.Failure)
            {
                list.DataSource = from x in clsVariables.RechargeStatuss2()
                    where (x.Value != clsVariables.RechargeStatus.Failure) && (x.Value != clsVariables.RechargeStatus.Reversed)
                    select x;
                list.DataTextField = "Text";
                list.DataValueField = "Value";
                list.DataBind();
            }
            else if (field.Value == clsVariables.RechargeStatus.Success)
            {
                list.DataSource = from x in clsVariables.RechargeStatuss2()
                    where (x.Value != clsVariables.RechargeStatus.Success) && (x.Value != clsVariables.RechargeStatus.Failure)
                    select x;
                list.DataTextField = "Text";
                list.DataValueField = "Value";
                list.DataBind();
            }
            else if (field.Value == clsVariables.RechargeStatus.Reversed)
            {
                list.DataSource = from x in clsVariables.RechargeStatuss2()
                    where x.Value != clsVariables.RechargeStatus.Reversed
                    select x;
                list.DataTextField = "Text";
                list.DataValueField = "Value";
                list.DataBind();
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.txtTo.Text = this.txtFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            this.bindData(false);
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
    }



    public class DataClassesDataContext1 : DataContext
    {

        private static MappingSource mappingSource = new AttributeMappingSource();

        public DataClassesDataContext1()
            : base(System.Configuration.ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ConnectionString, mappingSource)
        {
        }

        public DataClassesDataContext1(IDbConnection connection)
            : base(connection, mappingSource)
        {
        }

        public DataClassesDataContext1(string connection)
            : base(connection, mappingSource)
        {
        }

        public DataClassesDataContext1(IDbConnection connection, MappingSource mappingSource)
            : base(connection, mappingSource)
        {
        }

        public DataClassesDataContext1(string connection, MappingSource mappingSource)
            : base(connection, mappingSource)
        {
        }


        public Table<tblAdminComm> tblAdminComms
        {
            get
            {
                return this.GetTable<tblAdminComm>();
            }
        }



        public Table<tblAd> tblAds
        {
            get
            {
                return this.GetTable<tblAd>();
            }
        }



        public Table<tblAlert> tblAlerts
        {
            get
            {
                return this.GetTable<tblAlert>();
            }
        }

        //    base.GetTable<tblAlert>();

        public Table<tblAmountExact> tblAmountExacts
        {
            get
            {
                return this.GetTable<tblAmountExact>();
            }
        }

        // base.GetTable<tblAmountExact>();

        public Table<tblAPIBalance> tblAPIBalances
        {
            get
            {
                return this.GetTable<tblAPIBalance>();
            }
        }

        //   base.GetTable<tblAPIBalance>();

        public Table<tblApiBalHistory> tblApiBalHistories
        {
            get
            {
                return this.GetTable<tblApiBalHistory>();
            }
        }

        //   base.GetTable<tblApiBalHistory>();

        public Table<tblApi> tblApis
        {
            get
            {
                return this.GetTable<tblApi>();
            }
        }

        //  base.GetTable<tblApi>();

        public Table<tblBankDetail> tblBankDetails
        {
            get
            {
                return this.GetTable<tblBankDetail>();
            }
        }

        //  base.GetTable<tblBankDetail>();

        public Table<tblBank> tblBanks
        {
            get
            {
                return this.GetTable<tblBank>();
            }
        }

        //  base.GetTable<tblBank>();

        public Table<tblCharge> tblCharges
        {
            get
            {
                return this.GetTable<tblCharge>();
            }
        }
        //  base.GetTable<tblCharge>();

        public Table<tblCommission> tblCommissions
        {
            get
            {
                return this.GetTable<tblCommission>();
            }
        }
        //  base.GetTable<tblCommission>();

        public Table<tblCommPackage> tblCommPackages
        {
            get
            {
                return this.GetTable<tblCommPackage>();
            }
        }
        //   base.GetTable<tblCommPackage>();

        public Table<tblDeduction> tblDeductions
        {
            get
            {
                return this.GetTable<tblDeduction>();
            }
        }
        //  base.GetTable<tblDeduction>();

        public Table<tblGtalk> tblGtalks
        {
            get
            {
                return this.GetTable<tblGtalk>();
            }
        }
        // base.GetTable<tblGtalk>();

        public Table<tblLHistory> tblLHistories
        {
            get
            {
                return this.GetTable<tblLHistory>();
            }
        }
        // base.GetTable<tblLHistory>();

        public Table<tblLongcode> tblLongcodes
        {
            get
            {
                return this.GetTable<tblLongcode>();
            }
        }
        //   base.GetTable<tblLongcode>();

        public Table<tblMainComp> tblMainComps
        {
            get
            {
                return this.GetTable<tblMainComp>();
            }
        }
        // base.GetTable<tblMainComp>();

        public Table<tblMessageTrack> tblMessageTracks
        {
            get
            {
                return this.GetTable<tblMessageTrack>();
            }
        }
        //base.GetTable<tblMessageTrack>();

        public Table<tblMobileSery> tblMobileSeries
        {
            get
            {
                return this.GetTable<tblMobileSery>();
            }
        }
        //  base.GetTable<tblMobileSery>();

        public Table<tblOperator> tblOperators
        {
            get
            {
                return this.GetTable<tblOperator>();
            }
        }
        // base.GetTable<tblOperator>();

        public Table<tblPaymentReq> tblPaymentReqs
        {
            get
            {
                return this.GetTable<tblPaymentReq>();
            }
        }
        //    base.GetTable<tblPaymentReq>();

        public Table<tblRangeAmt> tblRangeAmts
        {
            get
            {
                return this.GetTable<tblRangeAmt>();
            }
        }
        // base.GetTable<tblRangeAmt>();

        public Table<tblRecharge> tblRecharges
        {
            get
            {
                return this.GetTable<tblRecharge>();
            }
        }
        //  base.GetTable<tblRecharge>();

        public Table<tblService> tblServices
        {
            get
            {
                return base.GetTable<tblService>();
            }
        }



        //   base.GetTable<tblService>();

        public Table<tblSMSApi> tblSMSApis
        {
            get
            {
                return this.GetTable<tblSMSApi>();
            }
        }
        //  base.GetTable<tblSMSApi>();

        public Table<tblSMSCredit> tblSMSCredits
        {
            get
            {
                return this.GetTable<tblSMSCredit>();
            }
        }
        //  base.GetTable<tblSMSCredit>();

        public Table<tblState> tblStates
        {
            get
            {
                return this.GetTable<tblState>();
            }
        }
        // base.GetTable<tblState>();

        public Table<tblTest> tblTests
        {
            get
            {
                return this.GetTable<tblTest>();
            }
        }
        //   base.GetTable<tblTest>();

        public Table<tblTicketDetail> tblTicketDetails
        {
            get
            {
                return this.GetTable<tblTicketDetail>();
            }
        }
        //  base.GetTable<tblTicketDetail>();

        public Table<tblTicket> tblTickets
        {
            get
            {
                return this.GetTable<tblTicket>();
            }
        }
        //  base.GetTable<tblTicket>();

        public Table<tblTransaction> tblTransactions
        {
            get
            {
                return this.GetTable<tblTransaction>();
            }
        }
        //   base.GetTable<tblTransaction>();

        public Table<tblUser> tblUsers
        {
            get
            {
                return this.GetTable<tblUser>();
            }
        }


    }

    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }
}

