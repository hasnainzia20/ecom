﻿using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Web;  
using System.Web.UI;  
using System.Web.UI.WebControls;  
using System.Data;  
using System.Data.SqlClient;  
public partial class _Default: System.Web.UI.Page   
{  
    protected void Page_Load(object sender, EventArgs e)  
    {  
    }
    protected void lnkAdd_Click(object sender, EventArgs e)  
    {
        SqlConnection con = new SqlConnection(@"Data Source=s132-148-156-17\sqlexpress;Initial Catalog=yashmodanwal;Persist Security Info=True;User ID=sa;Password=admin.123");  
      //  SqlCommand cmd = new SqlCommand("tblApi", con);  
    //    cmd.CommandType = CommandType.StoredProcedure;  
    //    cmd.Parameters.AddWithValue("APIName", TextBox1.Text);  
    //    cmd.Parameters.AddWithValue("APICode", TextBox2.Text);  
    //    cmd.Parameters.AddWithValue("Username", TextBox3.Text);  
    //    cmd.Parameters.AddWithValue("Password", TextBox4.Text);  
    //    cmd.Parameters.AddWithValue("Status", TextBox5.Text);  
    //    cmd.Parameters.AddWithValue("Apiurl", TextBox6.Text); 
    //    con.Open();  
    //    int k = cmd.ExecuteNonQuery();  
    //    if (k != 0) {  
    //        lblmsg.Text = "Recharge API " + TextBox1.Text + " Has Been Added Succesfully Into Admin Panel";  
    //        lblmsg.ForeColor = System.Drawing.Color.CornflowerBlue;  
    //    }  
    //    con.Close();  
    //}  
        SqlCommand cmd = new SqlCommand("insert into tblApi(APIName,APICode,Username,Password,Status,Apiurl) values('" + DropDownList2.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + DropDownList1.Text + "','" + TextBox6.Text + "')", con);

        cmd.CommandType = CommandType.Text;


        try

        {

            con.Open();

            cmd.ExecuteNonQuery();

            Literal1.Text = "Recharge API " + DropDownList2.Text + " Has Been Added Succesfully Into Admin Panel";

            con.Close();

            refress();

        }

        catch (Exception ex)

        {

            Literal1.Text = ex.Message;

        }

    }

    
    public void refress()
    {

        TextBox4.Text = "";

        TextBox2.Text = "";

        DropDownList2.Text = "";

        TextBox3.Text = "";

        DropDownList1.Text = "";

        TextBox6.Text = "";

      
    }
    protected void Button1_Click(object sender, EventArgs e)

    {

        refress();

        Literal1.Text = "";

    }

}
