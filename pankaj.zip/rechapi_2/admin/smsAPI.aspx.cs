﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_rechargeAPI : ThemeClass, IRequiresSessionState
{
  
    private DataClassesDataContext db = new DataClassesDataContext();
   

    private void bindData()
    {
        var queryable = from x in this.db.tblSMSApis
            orderby x.APIName
            select new { 
                Id = x.Id,
                Name = x.APIName,
                Url = x.Url,
                CssClass = x.Status ? "btn btn-success btn-sm" : "btn btn-danger btn-sm",
                Status1 = x.Status,
                Status = x.Status ? "Active" : "DeActive"
            };
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnAdd_Click(object sender, EventArgs e)
    {
        if (this.bttnAdd.Text == "Add New API")
        {
            if (Queryable.SingleOrDefault<tblSMSApi>(this.db.tblSMSApis, x => x.APIName == this.txtApiname.Text) == null)
            {
                tblSMSApi entity = new tblSMSApi {
                    APIName = this.txtApiname.Text,
                    Url = this.txtUrl.Text
                };
                this.db.tblSMSApis.InsertOnSubmit(entity);
                this.db.SubmitChanges();
                this.bindData();
                this.popup1222.Hide();
                this.reset();
                this.Popup.SetMessage("SMS API added successfully", control_ShowMessage.MessageType.Success);
            }
            else
            {
                this.Popup.SetMessage("SMS API already exist", control_ShowMessage.MessageType.Warning);
            }
        }
        else if (this.bttnAdd.Text == "Update API")
        {
            tblSMSApi addSeries = Queryable.SingleOrDefault<tblSMSApi>(this.db.tblSMSApis, x => x.Id == Convert.ToInt32(this.hfId.Value));
            if (addSeries != null)
            {
                if (Queryable.SingleOrDefault<tblSMSApi>(this.db.tblSMSApis, x => (x.APIName == this.txtApiname.Text) && (x.Id != addSeries.Id)) == null)
                {
                    addSeries.APIName = this.txtApiname.Text;
                    addSeries.Url = this.txtUrl.Text;
                    this.db.SubmitChanges();
                    this.reset();
                    this.bindData();
                    this.popup1222.Hide();
                    this.Popup.SetMessage("SMS API updated successfully", control_ShowMessage.MessageType.Success);
                }
                else
                {
                    this.Popup.SetMessage("SMS API already exist", control_ShowMessage.MessageType.Warning);
                }
            }
        }
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            this.lblTitle.Text = "UPDATE API";
            this.bttnAdd.Text = "Update API";
            tblSMSApi api = Queryable.Single<tblSMSApi>(this.db.tblSMSApis, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.hfId.Value = api.Id.ToString();
            this.txtApiname.Text = api.APIName;
            this.txtUrl.Text = api.Url;
            this.popup1222.Show();
        }
        else if (e.CommandName == "lnkDelete")
        {
            tblSMSApi entity = Queryable.Single<tblSMSApi>(this.db.tblSMSApis, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.db.tblSMSApis.DeleteOnSubmit(entity);
            this.db.SubmitChanges();
            this.bindData();
            this.Popup.SetMessage("SMS API deleted successfully", control_ShowMessage.MessageType.Success);
        }
        else if (e.CommandName.Equals("Status"))
        {
            GridViewRow namingContainer = (GridViewRow) ((Button) e.CommandSource).NamingContainer;
            HiddenField hfCompanyId = (HiddenField) namingContainer.FindControl("hfId");
            tblSMSApi api3 = Queryable.Single<tblSMSApi>(this.db.tblSMSApis, p => p.Id == Convert.ToInt32(hfCompanyId.Value));
            if (Convert.ToBoolean(e.CommandArgument))
            {
                api3.Status = false;
            }
            else
            {
                api3.Status = true;
            }
            this.db.SubmitChanges();
            foreach (tblSMSApi api4 in from x in this.db.tblSMSApis
                where x.Id != Convert.ToInt32(hfCompanyId.Value)
                select x)
            {
                if (Convert.ToBoolean(e.CommandArgument))
                {
                    api4.Status = true;
                }
                else
                {
                    api4.Status = false;
                }
            }
            this.db.SubmitChanges();
            this.bindData();
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button button = (Button) e.Row.FindControl("bttnDelete");
            button.Attributes.Add("onclick", "javascript:return confirm('Are you sure you want to delete this record: " + DataBinder.Eval(e.Row.DataItem, "Name") + "')");
        }
    }

    protected void lnkOpen_Click(object sender, EventArgs e)
    {
        this.lblTitle.Text = "ADD NEW API";
        this.bttnAdd.Text = "Add New API";
        this.reset();
        this.popup1222.Show();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.bindData();
        }
    }

    private void reset()
    {
        this.txtUrl.Text = "";
        this.txtApiname.Text = "";
    }

 
}
