﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


public partial class admin_rechargeAPI : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();



    private void bindData()
    {
        var queryable = from x in this.db.tblApis
                        orderby x.APIName
                        select new
                        {
                            Id = x.Id,
                            Name = x.APIName,
                            Code = x.APICode,
                            Balance = 0
                        };
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnAdd_Click(object sender, EventArgs e)
    {
        if (this.bttnAdd.Text == "Add New API")
        {
            if (Queryable.SingleOrDefault<tblApi>(this.db.tblApis, x => x.APIName == this.txtApiname.Text) == null)
            {
                tblApi entity = new tblApi();
                this.db.tblApis.InsertOnSubmit(entity);
                this.db.SubmitChanges();
                this.bindData();
                this.popup1222.Hide();
                this.reset();
                this.Popup.SetMessage("Recharge API added successfully", control_ShowMessage.MessageType.Success);
            }
            else
            {
                this.Popup.SetMessage("Recharge API already exist", control_ShowMessage.MessageType.Warning);
            }
        }
        else if (this.bttnAdd.Text == "Update API")
        {
            tblApi addSeries = Queryable.SingleOrDefault<tblApi>(this.db.tblApis, x => x.Id == Convert.ToInt32(this.hfId.Value));
            if (addSeries != null)
            {
                if (Queryable.SingleOrDefault<tblApi>(this.db.tblApis, x => (x.APIName == this.txtApiname.Text) && (x.Id != addSeries.Id)) == null)
                {
                    addSeries.Username = this.txtUsername.Text;
                    addSeries.Password = this.txtPassword.Text;
                    addSeries.Apiurl = this.txtUrl.Text;
                    this.db.SubmitChanges();
                    this.reset();
                    this.bindData();
                    this.popup1222.Hide();
                    this.Popup.SetMessage("Recharge API updated successfully", control_ShowMessage.MessageType.Success);
                }
                else
                {
                    this.Popup.SetMessage("Recharge API already exist", control_ShowMessage.MessageType.Warning);
                }
            }
        }
    }

    private void ddlBind()
    {
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            this.lblTitle.Text = "UPDATE API";
            this.bttnAdd.Text = "Update API";
            tblApi api = Queryable.Single<tblApi>(this.db.tblApis, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.hfId.Value = api.Id.ToString();
            this.txtApiname.Text = api.APIName;
            this.txtUsername.Text = api.Username;
            this.txtPassword.Text = api.Password;
            this.txtUrl.Text = api.Apiurl;
            this.popup1222.Show();
        }
        else if (e.CommandName == "lnkDelete")
        {
            tblState entity = Queryable.Single<tblState>(this.db.tblStates, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.db.tblStates.DeleteOnSubmit(entity);
            this.db.SubmitChanges();
            this.bindData();
            this.Popup.SetMessage("Recharge API deleted successfully", control_ShowMessage.MessageType.Success);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            HiddenField hfId = e.Row.FindControl("hfId") as HiddenField;
            tblApi api = Queryable.Single<tblApi>(this.db.tblApis, x => x.Id == Convert.ToInt16(hfId.Value));
            if (api.APIName == clsVariables.RechargeAPI.OnlyRecharge)
            {
                e.Row.Cells[2].Text = clsMethods.getRCBalance(api.Username, api.Password).Split(new char[] { '|' })[1];
            }
            else if (api.APIName == clsVariables.RechargeAPI.AvishaTraders2)
            {
                e.Row.Cells[2].Text = clsMethods.airnetBal(api.Apiurl, api.Username, api.Password).Replace("Your Balance is ", "");
            }
            else if (api.APIName == clsVariables.RechargeAPI.Bonrix2)
            {
                e.Row.Cells[2].Text = clsMethods.airnetBal(api.Apiurl, api.Username, api.Password).Replace("Your Balance is ", "");
            }
            else if (api.APIName == clsVariables.RechargeAPI.Suvidha)
            {
                e.Row.Cells[2].Text = clsMethods.getSuvidhaBalance(api.Apiurl, api.Username, api.Password).Replace("Your Balance is ", "");
            }
            else if (api.APIName == clsVariables.RechargeAPI.SMSAcharya)
            {
                e.Row.Cells[2].Text = clsMethods.SMSAcharyaBalance(api.Apiurl, api.Username, api.Password);
            }
            else if (api.APIName == clsVariables.RechargeAPI.ShreeRecharge)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.getShreeBalance(api.Apiurl, api.Username, api.Password).Split(new char[] { '|' })[1];
                }
                catch (Exception exception)
                {
                    e.Row.Cells[2].Text = exception.Message;
                }
            }
            else if ((api.APIName == clsVariables.RechargeAPI.SIPRC) || (api.APIName == clsVariables.RechargeAPI.Champrecharge))
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.getShreeBalance(api.Apiurl, api.Username, api.Password).Split(new char[] { '|' })[1];
                }
                catch (Exception exception2)
                {
                    e.Row.Cells[2].Text = exception2.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.mrobo)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.roboBalance(api.Apiurl, api.Username, api.Password).Split(new char[] { '{' })[2];
                }
                catch (Exception exception6)
                {
                    e.Row.Cells[2].Text = exception6.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.pay1all)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.pay1allBalance(api.Apiurl, api.Username, api.Password).Split(new char[] { '"' })[5];
                }
                catch (Exception exception6)
                {
                    e.Row.Cells[2].Text = exception6.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.PAYMONEY)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.JMDBalance(api.Apiurl, api.Username, api.Password).Split(new char[] { '"' })[3];
                }
                catch (Exception exception6)
                {
                    e.Row.Cells[2].Text = exception6.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.Skcommunition)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.SKBalance(api.Apiurl, api.Username, api.Password);
                }
                catch (Exception exception6)
                {
                    e.Row.Cells[2].Text = exception6.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.ezulix)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.EZBalance(api.Apiurl, api.Username, api.Password);
                }
                catch (Exception exception6)
                {
                    e.Row.Cells[2].Text = exception6.Message;
                }
            }

         
             
            else if (api.APIName == clsVariables.RechargeAPI.Emoneygroup)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.getShreeBalance(api.Apiurl, api.Username, api.Password).Split(new char[] { '|' })[1];
                }
                catch (Exception exception3)
                {
                    e.Row.Cells[2].Text = exception3.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.AvishaTraders)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.getShreeBalance(api.Apiurl, api.Username, api.Password).Split(new char[] { '|' })[1];
                }
                catch (Exception exception4)
                {
                    e.Row.Cells[2].Text = exception4.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.Jolo)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.getJoloBalance(api.Apiurl, api.Username, api.Password);
                }
                catch (Exception exception5)
                {
                    e.Row.Cells[2].Text = exception5.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.AnshiTelecom || api.APIName == clsVariables.RechargeAPI.IndiaCart)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.getShreeBalance(api.Apiurl, api.Username, api.Password).Split(new char[] { '|' })[1];
                }
                catch (Exception exception6)
                {
                    e.Row.Cells[2].Text = exception6.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.IndiaCart)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.getindiaBalance(api.Apiurl, api.Username, api.Password).Split(new char[] { '"' })[7];
                }
                catch (Exception exception6)
                {
                    e.Row.Cells[2].Text = exception6.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.Prechaarge)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.PrechaargeBalance(api.Apiurl, api.Username, api.Password).Split(new char[] { ':' })[6].Replace("}}", "");
                }
                catch (Exception exception6)
                {
                    e.Row.Cells[2].Text = exception6.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.RechApi)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.RechApiBalance(api.Apiurl, api.Username, api.Password).Split(new char[] { '|' })[1];
                }
                catch (Exception exception6)
                {
                    e.Row.Cells[2].Text = exception6.Message;
                }
            }
            else if (api.APIName == clsVariables.RechargeAPI.Champ)
            {
                try
                {
                    e.Row.Cells[2].Text = clsMethods.ChamprechargeBalance(api.Apiurl, api.Username, api.Password);
                }
                catch (Exception exception6)
                {
                    e.Row.Cells[2].Text = exception6.Message;
                }
            }
            
        }
    }




    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.bindData();
        }
    }

    private void reset()
    {
        this.txtUrl.Text = "";
        this.txtUsername.Text = "";
        this.txtPassword.Text = "";
        this.txtUrl.Text = "";
    }

}

