﻿using AjaxControlToolkit;
using System;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user_bSummary : ThemeClass, IRequiresSessionState
{
    
    private DataClassesDataContext db = new DataClassesDataContext();
    
    private void bindData()
    {
        var queryable = from x in this.db.tblTransactions
            join y in this.db.tblUsers on x.UserId equals y.Id 
            where ((x.TransactionType == clsVariables.TransactionType.Credit) || (x.TransactionType == clsVariables.TransactionType.Debit)) && (y.UserType == clsVariables.UserType.Reseller)
            orderby x.AddDate descending
            select new { 
                Id = x.Id,
                UserId = y.Id,
                Amount = x.Amount,
                Type = x.TransactionType,
                Username = y.Username,
                RechargeDate = x.AddDate,
                Balance = x.ABalance
            };
        if (((this.txtFrom.Text != null) && (this.txtFrom.Text != "")) && ((this.txtTo.Text != null) && (this.txtTo.Text != "")))
        {
            DateTime dt;
            DateTime dt2;
            DateTime.TryParseExact(this.txtFrom.Text.Split(new char[] { '/' })[1] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[0] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt);
            DateTime.TryParseExact(this.txtTo.Text.Split(new char[] { '/' })[1] + "/" + this.txtTo.Text.Split(new char[] { '/' })[0] + "/" + this.txtTo.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt2);
            queryable = from x in queryable
                        where (x.RechargeDate.Date >= dt.Date) && (x.RechargeDate.Date <= dt2.Date)
                select x;
        }
        if (this.ddlAll.SelectedIndex > 0)
        {
            queryable = from x in queryable
                where x.Type == this.ddlAll.SelectedValue
                select x;
        }
        if (this.ddlUsers.SelectedIndex > 0)
        {
            queryable = from x in queryable
                where x.UserId == Convert.ToInt32(this.ddlUsers.SelectedValue)
                select x;
        }
        decimal? nullable = Queryable.Sum(from x in queryable
            where x.Type == clsVariables.TransactionType.Credit
                                          select x, (x => (decimal?)x.Amount));
        decimal num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
        decimal? nullable2 = Queryable.Sum(from x in queryable
            where x.Type == clsVariables.TransactionType.Debit
            select x, (x => (decimal?)x.Amount));
        this.lblTotal.Text = "Credit: " + num.ToString() + " | Debit: " + (nullable2.HasValue ? nullable2.GetValueOrDefault() : 0.0M).ToString();
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
        this.ddlAll.DataSource = clsVariables.TransactionTypes();
        this.ddlAll.DataTextField = "Text";
        this.ddlAll.DataValueField = "Value";
        this.ddlAll.DataBind();
        var queryable = from x in this.db.tblUsers
            where x.UserType == clsVariables.UserType.Reseller
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + (x.Id) + "]"
            };
        this.ddlUsers.DataSource = queryable;
        this.ddlUsers.DataTextField = "Name";
        this.ddlUsers.DataValueField = "Id";
        this.ddlUsers.DataBind();
        this.ddlUsers.Items.Insert(0, "All");
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "15",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.txtTo.Text = this.txtFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            this.bindData();
        }
    }

}
