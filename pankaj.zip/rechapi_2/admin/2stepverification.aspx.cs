﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


public partial class apiswitch : ThemeClass, IRequiresSessionState

{
    DataClassesDataContext db = new DataClassesDataContext();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            try
            {
                
             
               
            }
            catch
            {
            }
        }
    }
    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            //ob ob1 = new ob();
            //string iii = "Update tblPanApi SET Username = '" + username.Text + "', Token = '"+token.Text+"'".ToString();
            //string insdatarecharge = ob1.executenonscalar(iii).ToString();
          
          
            this.Popup.SetMessage("PAN API SETTINGS Updated Successfully ", control_ShowMessage.MessageType.Success);
           
        }
        catch
        {
        }
    }
   
 
   
}
	