﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user_Profile : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
  

    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            tblCharge charge = this.db.tblCharges.FirstOrDefault<tblCharge>();
            if (charge != null)
            {
                charge.SD = new decimal?(Convert.ToDecimal(this.txtAmount.Text));
                charge.Dist = new decimal?(Convert.ToDecimal(this.txtDist.Text));
                charge.Retailer = new decimal?(Convert.ToDecimal(this.txtRetailer.Text));
                charge.UserFee = new decimal?(Convert.ToDecimal(this.txtUserCharge.Text));
                charge.Type = "";
                this.db.SubmitChanges();
            }
            else
            {
                tblCharge entity = new tblCharge {
                    SD = new decimal?(Convert.ToDecimal(this.txtAmount.Text)),
                    Dist = new decimal?(Convert.ToDecimal(this.txtDist.Text)),
                    Retailer = new decimal?(Convert.ToDecimal(this.txtRetailer.Text)),
                    UserFee = new decimal?(Convert.ToDecimal(this.txtUserCharge.Text)),
                    Type = ""
                };
                this.db.tblCharges.InsertOnSubmit(entity);
                this.db.SubmitChanges();
            }
            this.Popup.SetMessage("Registration fees updated successfully", control_ShowMessage.MessageType.Success);
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            tblCharge charge = this.db.tblCharges.FirstOrDefault<tblCharge>();
            if (charge != null)
            {
                this.txtAmount.Text = charge.SD.ToString();
                this.txtDist.Text = charge.Dist.ToString();
                this.txtRetailer.Text = charge.Retailer.ToString();
                this.txtUserCharge.Text = charge.UserFee.ToString();
            }
        }
    }

 
}
