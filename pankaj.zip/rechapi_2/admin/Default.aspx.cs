﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

public partial class admin_Default : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
  

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            IQueryable<tblRecharge> source = from x in this.db.tblRecharges
                where (x.RechargeDate.Date == DateTime.Now.Date) && (x.Status == clsVariables.RechargeStatus.Success)
                select x;
            IQueryable<tblRecharge> queryable2 = from x in this.db.tblRecharges
                where (x.RechargeDate.Date == DateTime.Now.Date) && (x.Status == clsVariables.RechargeStatus.Failure)
                select x;
            IQueryable<tblRecharge> queryable3 = from x in this.db.tblRecharges
                where (x.RechargeDate.Date == DateTime.Now.Date) && (x.Status == clsVariables.RechargeStatus.Pending)
                select x;
            IQueryable<tblRecharge> queryable4 = from x in this.db.tblRecharges
                where (x.RechargeDate.Date == DateTime.Now.Date) && (x.Status == clsVariables.RechargeStatus.Reversed)
                select x;
            decimal? nullable = Queryable.Sum<tblRecharge>(source, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            decimal num10 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            this.lblSuccess.Text = source.Count<tblRecharge>() + " | " + num10.ToString();
            decimal? nullable2 = Queryable.Sum<tblRecharge>(queryable2, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            this.lblFailure.Text = queryable2.Count<tblRecharge>() + " | " + (nullable2.HasValue ? nullable2.GetValueOrDefault() : 0.0M).ToString();
            decimal? nullable3 = Queryable.Sum<tblRecharge>(queryable3, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            this.lblPending.Text = queryable3.Count<tblRecharge>() + " | " + (nullable3.HasValue ? nullable3.GetValueOrDefault() : 0.0M).ToString();
            decimal? nullable4 = Queryable.Sum<tblRecharge>(queryable4, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            this.lblReversed.Text = queryable4.Count<tblRecharge>() + " | " + (nullable4.HasValue ? nullable4.GetValueOrDefault() : 0.0M).ToString();
            decimal? nullable5 = Queryable.Sum<tblRecharge>(source, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            decimal? nullable6 = Queryable.Sum<tblRecharge>(queryable2, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            decimal? nullable7 = Queryable.Sum<tblRecharge>(queryable3, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            nullable = Queryable.Sum<tblRecharge>(queryable4, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            this.lblTotal.Text = (((source.Count<tblRecharge>() + queryable3.Count<tblRecharge>()) + queryable2.Count<tblRecharge>()) + queryable4.Count<tblRecharge>()) + " | " + ((((nullable5.HasValue ? nullable5.GetValueOrDefault() : 0.0M) + (nullable6.HasValue ? nullable6.GetValueOrDefault() : 0.0M)) + (nullable7.HasValue ? nullable7.GetValueOrDefault() : 0.0M)) + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M));
            decimal num = 0M;
            decimal num2 = 0M;
            decimal num3 = 0M;
            decimal num4 = 0M;
            int num5 = 0;
            int num6 = 0;
            int num7 = 0;
            int num8 = 0;
            var queryable5 = from x in this.db.tblUsers
                where x.UserType == clsVariables.UserType.SuperDistributor
                select new { Id = x.Id };
            decimal num9 = 0M;
            foreach (var type in queryable5)
            {
                num9 += clsMethods.getBalance(type.Id);
            }
            num = num9;
            this.lblSD.Text = queryable5.Count() + " | " + num9.ToString();
            num5 = queryable5.Count();
            queryable5 = from x in this.db.tblUsers
                where x.UserType == clsVariables.UserType.Distributor
                select new { Id = x.Id };
            num9 = 0M;
            foreach (var type2 in queryable5)
            {
                num9 += clsMethods.getBalance(type2.Id);
            }
            num2 = num9;
            this.lblDist.Text = queryable5.Count() + " | " + num9.ToString();
            num6 = queryable5.Count();
            queryable5 = from x in this.db.tblUsers
                where x.UserType == clsVariables.UserType.Retailer
                select new { Id = x.Id };
            num9 = 0M;
            foreach (var type3 in queryable5)
            {
                num9 += clsMethods.getBalance(type3.Id);
            }
            num3 = num9;
            this.lblRetailer.Text = queryable5.Count() + " | " + num9.ToString();
            num7 = queryable5.Count();
            queryable5 = from x in this.db.tblUsers
                where x.UserType == clsVariables.UserType.User
                select new { Id = x.Id };
            num9 = 0M;
            foreach (var type4 in queryable5)
            {
                num9 += clsMethods.getBalance(type4.Id);
            }
            num4 = num9;
            this.lblUser.Text = queryable5.Count() + " | " + num9.ToString();
            num8 = queryable5.Count();
            this.lblTotal2.Text = (((num5 + num6) + num7) + num8) + " | " + (((num + num2) + num3) + num4);
            tblTransaction transaction = (from x in this.db.tblTransactions
                orderby x.Id descending
                where x.AddDate.Date < DateTime.Now.Date
                select x).FirstOrDefault<tblTransaction>();
            nullable = (transaction != null) ? transaction.AdminBalance : 0;
            this.lblOpBal.Text = nullable.ToString();
            transaction = (from x in this.db.tblTransactions
                orderby x.Id descending
                where x.AddDate.Date == DateTime.Now.Date
                select x).FirstOrDefault<tblTransaction>();
            nullable = (transaction != null) ? transaction.AdminBalance : 0;
            this.lblCloBal.Text = nullable.ToString();
            IQueryable<tblTransaction> queryable6 = from x in this.db.tblTransactions
                where ((x.DrUserId == -1) && (x.CrUserId == Convert.ToInt32(this.Session["aUserId"].ToString()))) && (x.AddDate.Date == DateTime.Now.Date)
                select x;
            nullable = Queryable.Sum<tblTransaction>(queryable6, (Expression<Func<tblTransaction, decimal?>>) (x => x.Amount));
            num10 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            this.lblAddedBal.Text = num10.ToString();
            queryable6 = from x in this.db.tblTransactions
                where ((x.DrUserId == Convert.ToInt32(this.Session["aUserId"].ToString())) && (x.AddDate.Date == DateTime.Now.Date)) && (x.TransactionType == clsVariables.TransactionType.Credit)
                select x;
            nullable = Queryable.Sum<tblTransaction>(queryable6, (Expression<Func<tblTransaction, decimal?>>) (x => x.Amount));
            num10 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            this.lblCredit.Text = num10.ToString();
            queryable6 = from x in this.db.tblTransactions
                where ((x.CrUserId == Convert.ToInt32(this.Session["aUserId"].ToString())) && (x.AddDate.Date == DateTime.Now.Date)) && (x.TransactionType == clsVariables.TransactionType.Debit)
                select x;
            nullable = Queryable.Sum<tblTransaction>(queryable6, (Expression<Func<tblTransaction, decimal?>>) (x => x.Amount));
            num10 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            this.lblDebit.Text = num10.ToString();
            IQueryable<tblTransaction> queryable7 = from x in this.db.tblTransactions
                where (x.AddDate.Date == DateTime.Now.Date) && (x.TransactionType == clsVariables.TransactionType.RechargeComm)
                select x;
            IQueryable<tblTransaction> queryable8 = from x in this.db.tblTransactions
                where (x.AddDate.Date == DateTime.Now.Date) && (x.TransactionType == clsVariables.TransactionType.RechargeCommFailure)
                select x;
            nullable = Queryable.Sum<tblTransaction>(queryable7, (Expression<Func<tblTransaction, decimal?>>) (x => x.Amount));
            nullable = Queryable.Sum<tblTransaction>(queryable8, (Expression<Func<tblTransaction, decimal?>>) (x => x.Amount));
            num10 = (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M) - (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M);
            this.lblCommPayout.Text = num10.ToString();
            IQueryable<tblTransaction> queryable9 = from x in this.db.tblTransactions
                where (x.AddDate.Date == DateTime.Now.Date) && (x.TransactionType == clsVariables.TransactionType.RechargeCommRevert)
                select x;
            nullable = Queryable.Sum<tblTransaction>(queryable9, (Expression<Func<tblTransaction, decimal?>>) (x => x.Amount));
            num10 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            this.lblReversed2.Text = num10.ToString();
            IQueryable<tblPaymentReq> queryable10 = from x in this.db.tblPaymentReqs
                where (x.Approved == clsVariables.RequestType.Pending) && (x.PaymentDate.Date == DateTime.Now.Date)
                select x;
            nullable = Queryable.Sum<tblPaymentReq>(queryable10, (Expression<Func<tblPaymentReq, decimal?>>) (x => x.Amount));
            num10 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            this.lblPendingPayment.Text = queryable10.Count<tblPaymentReq>() + " | " + num10.ToString();
            IQueryable<tblPaymentReq> queryable11 = from x in this.db.tblPaymentReqs
                where (x.Approved == clsVariables.RequestType.Accepted) && (x.PaymentDate.Date == DateTime.Now.Date)
                select x;
            nullable = Queryable.Sum<tblPaymentReq>(queryable11, (Expression<Func<tblPaymentReq, decimal?>>) (x => x.Amount));
            num10 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            this.lblAccepted.Text = queryable11.Count<tblPaymentReq>() + " | " + num10.ToString();
            IQueryable<tblPaymentReq> queryable12 = from x in this.db.tblPaymentReqs
                where (x.Approved == clsVariables.RequestType.Rejected) && (x.PaymentDate.Date == DateTime.Now.Date)
                select x;
            nullable = Queryable.Sum<tblPaymentReq>(queryable12, (Expression<Func<tblPaymentReq, decimal?>>) (x => x.Amount));
            this.lblRejected.Text = queryable12.Count<tblPaymentReq>() + " | " + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M).ToString();
            nullable = Queryable.Sum<tblPaymentReq>(queryable10, (Expression<Func<tblPaymentReq, decimal?>>) (x => x.Amount));
            nullable = Queryable.Sum<tblPaymentReq>(queryable11, (Expression<Func<tblPaymentReq, decimal?>>) (x => x.Amount));
            nullable = Queryable.Sum<tblPaymentReq>(queryable12, (Expression<Func<tblPaymentReq, decimal?>>) (x => x.Amount));
            this.lblPaymentTotal.Text = ((queryable10.Count<tblPaymentReq>() + queryable11.Count<tblPaymentReq>()) + queryable12.Count<tblPaymentReq>()) + " | " + (((nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M) + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M)) + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M));
            IQueryable<tblTicket> queryable13 = from x in this.db.tblTickets
                where (x.Status == clsVariables.TicketStatus.InProcess) && (x.AddDate.Date == DateTime.Now.Date)
                select x;
            IQueryable<tblTicket> queryable14 = from x in this.db.tblTickets
                where (x.Status == clsVariables.TicketStatus.Closed) && (x.AddDate.Date == DateTime.Now.Date)
                select x;
            this.lblOpenTicket.Text = queryable13.Count<tblTicket>().ToString();
            this.lblClosedTicket.Text = queryable14.Count<tblTicket>().ToString();
            this.lblTotalTicket.Text = (queryable13.Count<tblTicket>() + queryable14.Count<tblTicket>()).ToString();
            tblAlert use2r = Queryable.Single<tblAlert>(db.tblAlerts, x => x.AlertType == "Announcement");
            this.lblNews.Text = use2r.Alerts;
            this.lblNews.ForeColor = System.Drawing.Color.Blue;
        }
    }


}

