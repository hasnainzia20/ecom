﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_mobileSeries : ThemeClass, IRequiresSessionState
{
 
    private DataClassesDataContext db = new DataClassesDataContext();
   

    private void bindData()
    {
        var queryable = from x in this.db.tblMobileSeries
            join y in this.db.tblStates on x.StateId equals y.Id
            join z in this.db.tblMainComps on x.OperatorId equals z.Id 
            orderby x.SeriesNo
            select new { 
                Id = x.Id,
                Series = x.SeriesNo,
                State = y.StateName,
                Operator = z.OperatorName
            };
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            queryable = from x in queryable
                where (x.State.Contains(this.txtSearch.Text) || x.Operator.Contains(this.txtSearch.Text)) || x.Series.Contains(this.txtSearch.Text)
                select x;
        }
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnAdd_Click(object sender, EventArgs e)
    {
        if (this.bttnAdd.Text == "Add Series")
        {
            if (Queryable.SingleOrDefault<tblMobileSery>(this.db.tblMobileSeries, x => x.SeriesNo == this.txtSeries.Text) == null)
            {
                tblMobileSery entity = new tblMobileSery {
                    SeriesNo = this.txtSeries.Text,
                    StateId = Convert.ToInt16(this.ddlState.SelectedValue),
                    OperatorId = Convert.ToInt16(this.ddlOperator.SelectedValue)
                };
                this.db.tblMobileSeries.InsertOnSubmit(entity);
                this.db.SubmitChanges();
                this.bindData();
                this.popup1222.Hide();
                this.reset();
                this.Popup.SetMessage("New mobile series added successfully", control_ShowMessage.MessageType.Success);
            }
            else
            {
                this.Popup.SetMessage("Mobile series already exist", control_ShowMessage.MessageType.Warning);
            }
        }
        else if (this.bttnAdd.Text == "Update Mobile Series")
        {
            tblMobileSery addSeries = Queryable.SingleOrDefault<tblMobileSery>(this.db.tblMobileSeries, x => x.Id == Convert.ToInt32(this.hfId.Value));
            if (addSeries != null)
            {
                if (Queryable.SingleOrDefault<tblMobileSery>(this.db.tblMobileSeries, x => (x.SeriesNo == this.txtSeries.Text) && (x.Id != addSeries.Id)) == null)
                {
                    addSeries.SeriesNo = this.txtSeries.Text;
                    addSeries.StateId = Convert.ToInt16(this.ddlState.SelectedValue);
                    addSeries.OperatorId = Convert.ToInt16(this.ddlOperator.SelectedValue);
                    this.db.SubmitChanges();
                    this.reset();
                    this.bindData();
                    this.popup1222.Hide();
                    this.Popup.SetMessage("Mobile series updated successfully", control_ShowMessage.MessageType.Success);
                }
                else
                {
                    this.Popup.SetMessage("Mobile series already exist", control_ShowMessage.MessageType.Warning);
                }
            }
        }
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
        var queryable = from x in this.db.tblStates
            orderby x.StateName
            select new { 
                Id = x.Id,
                Name = x.StateName
            };
        this.ddlState.DataSource = queryable;
        this.ddlState.DataTextField = "Name";
        this.ddlState.DataValueField = "Id";
        this.ddlState.DataBind();
        this.ddlState.Items.Insert(0, " - Select - ");
        var queryable2 = from x in this.db.tblMainComps
            join y in this.db.tblServices on x.ServiceId equals y.Id 
            where y.ServiceName == clsVariables.ServiceType.Mobile
            orderby x.OperatorName
            select new { 
                Id = x.Id,
                Name = x.OperatorName
            };
        this.ddlOperator.DataSource = queryable2;
        this.ddlOperator.DataTextField = "Name";
        this.ddlOperator.DataValueField = "Id";
        this.ddlOperator.DataBind();
        this.ddlOperator.Items.Insert(0, " - Select - ");
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            this.lblTitle.Text = "UPDATE MOBILE SERIES";
            this.bttnAdd.Text = "Update Mobile Series";
            tblMobileSery sery = Queryable.Single<tblMobileSery>(this.db.tblMobileSeries, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.hfId.Value = sery.Id.ToString();
            this.txtSeries.Text = sery.SeriesNo;
            this.ddlState.SelectedValue = sery.StateId.ToString();
            this.ddlOperator.SelectedValue = sery.OperatorId.ToString();
            this.popup1222.Show();
        }
        else if (e.CommandName == "lnkDelete")
        {
            tblMobileSery entity = Queryable.Single<tblMobileSery>(this.db.tblMobileSeries, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.db.tblMobileSeries.DeleteOnSubmit(entity);
            this.db.SubmitChanges();
            this.bindData();
            this.Popup.SetMessage("Mobile Series deleted successfully", control_ShowMessage.MessageType.Success);
        }
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "20",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button button3 = (Button) e.Row.FindControl("bttnDelete");
            button3.Attributes.Add("onclick", string.Concat(new object[] { "javascript:return confirm('Are you sure you want to delete this record: ", DataBinder.Eval(e.Row.DataItem, "Series"), " - ", DataBinder.Eval(e.Row.DataItem, "Operator"), "')" }));
        }
    }

    protected void lnk_Click(object sender, EventArgs e)
    {
        string script = "<script> ";
        script = (script + "var newWindow = window.open('http://numbri.in/series.php?no=" + this.txtSeries.Text + "','','scrollbars=yes,menubar=yes,height=600,width=800,resizable=yes,toolbar=yes,location=yes,status=yes');") + "</script>";
        this.Page.RegisterClientScriptBlock("strScript", script);
    }

    protected void lnkOpen_Click(object sender, EventArgs e)
    {
        this.lblTitle.Text = "ADD NEW MOBILE SERIES";
        this.bttnAdd.Text = "Add Series";
        this.reset();
        this.popup1222.Show();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.bindData();
        }
    }

    private void reset()
    {
        this.txtSeries.Text = "";
        this.ddlState.SelectedIndex = 0;
        this.ddlOperator.SelectedIndex = 0;
    }

   
}
