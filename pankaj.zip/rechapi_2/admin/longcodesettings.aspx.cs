﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user_Profile1 : ThemeClass, IRequiresSessionState
{
   
    private DataClassesDataContext db = new DataClassesDataContext();


    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            if (Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Id != Convert.ToInt32(this.Session["aUserId"].ToString())) && (x.Keyword == this.txtKeyword.Text)) == null)
            {
                if (Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Id != Convert.ToInt32(this.Session["aUserId"].ToString())) && (x.ServerNo == this.txtServerNo.Text)) == null)
                {
                    tblUser user2 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                    user2.Keyword = this.txtKeyword.Text;
                    user2.ServerNo = this.txtServerNo.Text;
                    this.db.SubmitChanges();
                    this.Popup.SetMessage("Keyword updated successfully", control_ShowMessage.MessageType.Success);
                }
                else
                {
                    this.Popup.SetMessage("Server No already exist", control_ShowMessage.MessageType.Warning);
                }
            }
            else
            {
                this.Popup.SetMessage("Keyword already exist", control_ShowMessage.MessageType.Warning);
            }
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            tblUser user = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
            if (user.Keyword != null)
            {
                this.txtKeyword.Text = user.Keyword;
                this.txtServerNo.Text = user.ServerNo;
            }
        }
    }

 
}
