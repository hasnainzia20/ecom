﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

public partial class admin_alerts : ThemeClass, IRequiresSessionState
{
    // Fields
   
    private DataClassesDataContext db = new DataClassesDataContext();
  

    // Methods
    protected void bttnAdd_Click(object sender, EventArgs e)
    {
        tblAlert alert = Queryable.FirstOrDefault<tblAlert>(this.db.tblAlerts, x => x.AlertType == clsVariables.AlertType.Announcement);
        if (alert != null)
        {
            alert.Alerts = this.CKEditor1.Text;
            this.db.SubmitChanges();
            this.Popup.SetMessage("Announcement updated successfully.", control_ShowMessage.MessageType.Success);
            this.lblNews.Text = alert.Alerts;
            this.lblNews.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            tblAlert entity = new tblAlert
            {
                Alerts = this.CKEditor1.Text,
                AlertType = clsVariables.AlertType.Announcement,
                AddDate = DateTime.Now
            };
            this.db.tblAlerts.InsertOnSubmit(entity);
            this.db.SubmitChanges();
            this.Popup.SetMessage("Announcement added successfully.", control_ShowMessage.MessageType.Success);
            this.lblNews.Text = alert.Alerts;
            this.lblNews.ForeColor = System.Drawing.Color.Red;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            tblAlert alert = Queryable.FirstOrDefault<tblAlert>(this.db.tblAlerts, x => x.AlertType == clsVariables.AlertType.Announcement);
            if (alert != null)
            {
                this.CKEditor1.Text = alert.Alerts;
                this.lblNews.Text = alert.Alerts;
                this.lblNews.ForeColor = System.Drawing.Color.Red;
            }
        }
    }


    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }
   
}
	