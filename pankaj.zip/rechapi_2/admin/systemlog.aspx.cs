﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.SessionState;
//using AjaxControlToolkit;
public partial class user_Profile : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);





    SqlCommand cmd;
    DataSet myd = new DataSet();
    DataSet datasetcom = new DataSet();

    SqlConnection con1;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    DataTable dt = new DataTable();
    SqlDataReader dr;

    string st1;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.gridbind();
        }
    }
 

    public void gridbind()
    {
        
        SqlCommand command = new SqlCommand("SELECT [Id],[Message],[AddDate] FROM tblTest", this.con);
        SqlDataAdapter adapter = new SqlDataAdapter
        {
           SelectCommand = command
        };
        DataSet dataSet = new DataSet();
        adapter.Fill(dataSet);
        this.GridView1.DataSource = dataSet;
        this.GridView1.DataBind();
    }

   


   public void openconn()
    {

     
        if (con == null)
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());
       
        if (con.State == ConnectionState.Closed)
            con.Open();
    }
    public string executescalar(string str)
    {
        openconn();

        cmd = new SqlCommand(str, con);


        if (str != null)
            st1 = cmd.ExecuteScalar().ToString();


        return st1;
    }

    public string executenonscalar(string str)
    {
        openconn();

        cmd = new SqlCommand(str, con);


        if (str != null)
            st1 = cmd.ExecuteNonQuery().ToString();


        return st1;
    }
 

    public class DataClassesDataContext1 : DataContext
    {

        private static MappingSource mappingSource = new AttributeMappingSource();

        public DataClassesDataContext1()
            : base(System.Configuration.ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString, mappingSource)
        {
        }

        public DataClassesDataContext1(IDbConnection connection)
            : base(connection, mappingSource)
        {
        }

        public DataClassesDataContext1(string connection)
            : base(connection, mappingSource)
        {
        }

        public DataClassesDataContext1(IDbConnection connection, MappingSource mappingSource)
            : base(connection, mappingSource)
        {
        }

        public DataClassesDataContext1(string connection, MappingSource mappingSource)
            : base(connection, mappingSource)
        {
        }


        public Table<tblAdminComm> tblAdminComms
        {
            get
            {
                return this.GetTable<tblAdminComm>();
            }
        }



        public Table<tblAd> tblAds
        {
            get
            {
                return this.GetTable<tblAd>();
            }
        }
   
    

        public Table<tblAlert> tblAlerts
        {
            get
            {
                return this.GetTable<tblAlert>();
            }
        }

        //    base.GetTable<tblAlert>();

        public Table<tblAmountExact> tblAmountExacts
        {
            get
            {
                return this.GetTable<tblAmountExact>();
            }
        }

        // base.GetTable<tblAmountExact>();

        public Table<tblAPIBalance> tblAPIBalances
        {
            get
            {
                return this.GetTable<tblAPIBalance>();
            }
        }

        //   base.GetTable<tblAPIBalance>();

        public Table<tblApiBalHistory> tblApiBalHistories
        {
            get
            {
                return this.GetTable<tblApiBalHistory>();
            }
        }

        //   base.GetTable<tblApiBalHistory>();

        public Table<tblApi> tblApis
        {
            get
            {
                return this.GetTable<tblApi>();
            }
        }

        //  base.GetTable<tblApi>();

        public Table<tblBankDetail> tblBankDetails
        {
            get
            {
                return this.GetTable<tblBankDetail>();
            }
        }

        //  base.GetTable<tblBankDetail>();

        public Table<tblBank> tblBanks
        {
            get
            {
                return this.GetTable<tblBank>();
            }
        }

        //  base.GetTable<tblBank>();

        public Table<tblCharge> tblCharges
        {
            get
            {
                return this.GetTable<tblCharge>();
            }
        }
        //  base.GetTable<tblCharge>();

        public Table<tblCommission> tblCommissions
        {
            get
            {
                return this.GetTable<tblCommission>();
            }
        }
        //  base.GetTable<tblCommission>();

        public Table<tblCommPackage> tblCommPackages
        {
            get
            {
                return this.GetTable<tblCommPackage>();
            }
        }
        //   base.GetTable<tblCommPackage>();

        public Table<tblDeduction> tblDeductions
        {
            get
            {
                return this.GetTable<tblDeduction>();
            }
        }
        //  base.GetTable<tblDeduction>();

        public Table<tblGtalk> tblGtalks
        {
            get
            {
                return this.GetTable<tblGtalk>();
            }
        }
        // base.GetTable<tblGtalk>();

        public Table<tblLHistory> tblLHistories
        {
            get
            {
                return this.GetTable<tblLHistory>();
            }
        }
        // base.GetTable<tblLHistory>();

        public Table<tblLongcode> tblLongcodes
        {
            get
            {
                return this.GetTable<tblLongcode>();
            }
        }
        //   base.GetTable<tblLongcode>();

        public Table<tblMainComp> tblMainComps
        {
            get
            {
                return this.GetTable<tblMainComp>();
            }
        }
        // base.GetTable<tblMainComp>();

        public Table<tblMessageTrack> tblMessageTracks
        {
            get
            {
                return this.GetTable<tblMessageTrack>();
            }
        }
        //base.GetTable<tblMessageTrack>();

        public Table<tblMobileSery> tblMobileSeries
        {
            get
            {
                return this.GetTable<tblMobileSery>();
            }
        }
        //  base.GetTable<tblMobileSery>();

        public Table<tblOperator> tblOperators
        {
            get
            {
                return this.GetTable<tblOperator>();
            }
        }
        // base.GetTable<tblOperator>();

        public Table<tblPaymentReq> tblPaymentReqs
        {
            get
            {
                return this.GetTable<tblPaymentReq>();
            }
        }
        //    base.GetTable<tblPaymentReq>();

        public Table<tblRangeAmt> tblRangeAmts
        {
            get
            {
                return this.GetTable<tblRangeAmt>();
            }
        }
        // base.GetTable<tblRangeAmt>();

        public Table<tblRecharge> tblRecharges
        {
            get
            {
                return this.GetTable<tblRecharge>();
            }
        }
        //  base.GetTable<tblRecharge>();

        public Table<tblService> tblServices
        {
            get
            {
                return base.GetTable<tblService>();
            }
        }



        //   base.GetTable<tblService>();

        public Table<tblSMSApi> tblSMSApis
        {
            get
            {
                return this.GetTable<tblSMSApi>();
            }
        }
        //  base.GetTable<tblSMSApi>();

        public Table<tblSMSCredit> tblSMSCredits
        {
            get
            {
                return this.GetTable<tblSMSCredit>();
            }
        }
        //  base.GetTable<tblSMSCredit>();

        public Table<tblState> tblStates
        {
            get
            {
                return this.GetTable<tblState>();
            }
        }
        // base.GetTable<tblState>();

        public Table<tblTest> tblTests
        {
            get
            {
                return this.GetTable<tblTest>();
            }
        }
        //   base.GetTable<tblTest>();

        public Table<tblTicketDetail> tblTicketDetails
        {
            get
            {
                return this.GetTable<tblTicketDetail>();
            }
        }
        //  base.GetTable<tblTicketDetail>();

        public Table<tblTicket> tblTickets
        {
            get
            {
                return this.GetTable<tblTicket>();
            }
        }
        //  base.GetTable<tblTicket>();

        public Table<tblTransaction> tblTransactions
        {
            get
            {
                return this.GetTable<tblTransaction>();
            }
        }
        //   base.GetTable<tblTransaction>();

        public Table<tblUser> tblUsers
        {
            get
            {
                return this.GetTable<tblUser>();
            }
        }

      
    }


    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }


  
}

