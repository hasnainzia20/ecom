﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user_Profile : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
    

    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            tblUser addUser = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
            if (Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Username == this.txtUsername.Text) && (x.Id != addUser.Id)) == null)
            {
                if (Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Mobile == this.txtMobile.Text) && (x.Id != addUser.Id)) == null)
                {
                    addUser.Username = this.txtUsername.Text;
                    addUser.Mobile = this.txtMobile.Text;
                    addUser.CustName = this.txtName.Text;
                    addUser.Password = this.txtPassword.Text;
                    if ((this.txtEmail.Text != null) && (this.txtEmail.Text != ""))
                    {
                        addUser.Email = this.txtEmail.Text;
                    }
                    if ((this.txtCompany.Text != null) && (this.txtCompany.Text != ""))
                    {
                        addUser.Company = this.txtEmail.Text;
                    }
                    if ((this.txtCity.Text != null) && (this.txtCity.Text != ""))
                    {
                        addUser.City = this.txtCity.Text;
                    }
                    if ((this.txtPostalCode.Text != null) && (this.txtPostalCode.Text != ""))
                    {
                        addUser.PostalCode = this.txtPostalCode.Text;
                    }
                    if ((this.txtAddress.Text != null) && (this.txtAddress.Text != ""))
                    {
                        addUser.Address = this.txtAddress.Text;
                    }
                    this.db.SubmitChanges();
                    this.Popup.SetMessage("Profile updated successfully", control_ShowMessage.MessageType.Success);
                }
                else
                {
                    this.Popup.SetMessage("Mobile No already exist", control_ShowMessage.MessageType.Warning);
                }
            }
            else
            {
                this.Popup.SetMessage("User already exist", control_ShowMessage.MessageType.Warning);
            }
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    private void loadData()
    {
        tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
        this.txtUsername.Text = user.Username;
        this.txtMobile.Text = user.Mobile;
        this.txtPassword.Text = user.Password;
        this.txtName.Text = user.CustName;
        if ((user.Email != null) && (user.Email != ""))
        {
            this.txtEmail.Text = user.Email;
        }
        if ((user.City != null) && (user.City != ""))
        {
            this.txtCity.Text = user.City;
        }
        if ((user.PostalCode != null) && (user.PostalCode != ""))
        {
            this.txtPostalCode.Text = user.PostalCode;
        }
        if ((user.Address != null) && (user.Address != ""))
        {
            this.txtAddress.Text = user.Address;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.loadData();
        }
    }

   
}
