﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

public partial class user_Profile : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);

    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            tblCharge charge = this.db.tblCharges.FirstOrDefault<tblCharge>();
            if (charge != null)
            {
                charge.UserFee = new decimal?(Convert.ToDecimal(this.txtUserCharge.Text));
                charge.Type = "RechargeLimit";
                this.db.SubmitChanges();
            }
            else
            {
                tblCharge entity = new tblCharge {
                    UserFee = new decimal?(Convert.ToDecimal(this.txtUserCharge.Text)),
                    Type = "RechargeLimit"
                };
                this.db.tblCharges.InsertOnSubmit(entity);
                this.db.SubmitChanges();
            }
            this.Popup.SetMessage("Recharge Limit Amount Updated Successfully", control_ShowMessage.MessageType.Success);
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            tblCharge charge = this.db.tblCharges.FirstOrDefault<tblCharge>();
            if (charge != null)
            {
                this.txtUserCharge.Text = charge.UserFee.ToString();
            }
        }
    }

}
