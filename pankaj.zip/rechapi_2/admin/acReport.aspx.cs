﻿using AjaxControlToolkit;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_payHistory : ThemeClass, IRequiresSessionState
{
   
    private DataClassesDataContext db = new DataClassesDataContext();
  

    private void bindData(bool status)
    {
        var queryable = from x in this.db.tblTransactions
            where (x.CrUserId == Convert.ToInt32(this.Session["aUserId"].ToString())) || (x.DrUserId == Convert.ToInt32(this.Session["aUserId"].ToString()))
            orderby x.AddDate descending
            select new { 
                Id = x.Id,
                Credit = (x.CrUserId == Convert.ToInt32(this.Session["aUserId"].ToString())) ? x.Amount.ToString() : "",
                Debit = (x.DrUserId == Convert.ToInt32(this.Session["aUserId"].ToString())) ? x.Amount.ToString() : "",
                Against = (x.CrUserId == Convert.ToInt32(this.Session["aUserId"].ToString())) ? (from g in this.db.tblUsers
                    where g.Id == x.DrUserId
                    select new { Name = (g.Username + " [") + (g.Id) + "]" }).First().Name : (from g in this.db.tblUsers
                    where g.Id == x.CrUserId
                    select new { Name = (g.Username + " [") + (g.Id) + "]" }).First().Name,
                TransType = x.TransactionType,
                Amount = x.AdminBalance,
                RechargeDate = x.AddDate,
                RefId = x.RefId,
                Actual = x.ABalance
            };
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            queryable = from x in queryable
                where (x.TransType.Contains(this.txtSearch.Text) || x.TransType.Contains(this.txtSearch.Text)) || x.Id.ToString().Contains(this.txtSearch.Text)
                select x;
        }
        if (((this.txtFrom.Text != null) && (this.txtFrom.Text != "")) && ((this.txtTo.Text != null) && (this.txtTo.Text != "")))
        {
            DateTime dt;
            DateTime dt2;
            DateTime.TryParseExact(this.txtFrom.Text.Split(new char[] { '/' })[1] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[0] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt);
            DateTime.TryParseExact(this.txtTo.Text.Split(new char[] { '/' })[1] + "/" + this.txtTo.Text.Split(new char[] { '/' })[0] + "/" + this.txtTo.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt2);
            queryable = from x in queryable
                        where (x.RechargeDate.Date >= dt.Date) && (x.RechargeDate.Date <= dt2.Date)
                select x;
        }
        if (status)
        {
            this.gvMain.AllowPaging = false;
        }
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnExport_Click(object sender, EventArgs e)
    {
        this.ExportToExcel();
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData(false);
    }

    private void ddlBind()
    {
        var queryable = from x in this.db.tblUsers
            where x.UserType != clsVariables.UserType.Administrator
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + (x.Id) + "]"
            };
        this.ddlUsers.DataSource = queryable;
        this.ddlUsers.DataTextField = "Name";
        this.ddlUsers.DataValueField = "Id";
        this.ddlUsers.DataBind();
        this.ddlUsers.Items.Insert(0, "All");
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData(false);
    }

    protected void ExportToExcel()
    {
        HtmlForm child = new HtmlForm();
        string str = "attachment;filename=" + DateTime.Now.ToString("dd-MM-yyyy") + "_PayHistory.xls";
        base.Response.ClearContent();
        this.bindData(true);
        base.Response.AddHeader("content-disposition", str);
        base.Response.ContentType = "application/vnd.ms-excel";
        StringWriter writer = new StringWriter();
        HtmlTextWriter writer2 = new HtmlTextWriter(writer);
        child.Controls.Add(this.gvMain);
        this.Controls.Add(child);
        child.RenderControl(writer2);
        base.Response.Write(writer.ToString());
        base.Response.End();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData(false);
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            tblRecharge getRecharge = Queryable.SingleOrDefault<tblRecharge>(this.db.tblRecharges, x => x.Id == Convert.ToInt32(e.CommandArgument));
            if (getRecharge != null)
            {
                this.lblMobile.Text = getRecharge.Number;
                this.lblRefId.Text = getRecharge.Id.ToString();
                this.lblAmount.Text = getRecharge.Amount.ToString();
                this.lblDate.Text = getRecharge.RechargeDate.ToString("dd/MM/yyyy hh:mm:ss tt");
                this.lblTranId.Text = getRecharge.TransactionId.ToString();
                this.lblBalance.Text = getRecharge.ClosingBal.ToString();
                this.lblOperator.Text = (from g in this.db.tblOperators
                    join j in this.db.tblMainComps on g.MainCompId equals (short?) j.Id
                    where g.Id == getRecharge.OperatorId
                    let Name1 = g.Operator
                    select new { Name = (g.Operator != null) ? (j.OperatorName + " " + g.Operator) : j.OperatorName }).First().Name;
                this.ModalPopupExtender1.Show();
            }
        }
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "15",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.txtTo.Text = this.txtFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            this.bindData(false);
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
    }

  
}

