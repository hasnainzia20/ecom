﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_setComm : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
   

    private void bindData()
    {
        var queryable = from x in this.db.tblMainComps
            join z in this.db.tblServices on x.ServiceId equals z.Id 
            let Name1 = x.OperatorName
            orderby z.Id
            select new { 
                Id = x.Id,
                Operator = x.OperatorName,
                Service = z.ServiceName,
                Status = x.Down ? "Deactive" : "Active",
                Status1 = !x.Down ? "btn btn-xs btn-success" : "btn btn-xs btn-danger",
                Status2 = x.Down
            };
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("Add"))
            {
                GridViewRow namingContainer = (GridViewRow) ((Button) e.CommandSource).NamingContainer;
                HiddenField field = (HiddenField) namingContainer.FindControl("hfStatus");
                HiddenField hfId = (HiddenField) namingContainer.FindControl("hfId");
                tblMainComp comp = Queryable.Single<tblMainComp>(this.db.tblMainComps, x => x.Id == Convert.ToInt16(hfId.Value));
                if (Convert.ToBoolean(field.Value))
                {
                    comp.Down = false;
                }
                else
                {
                    comp.Down = true;
                }
                this.db.SubmitChanges();
                this.bindData();
                this.Popup.SetMessage("Status updated successfully", control_ShowMessage.MessageType.Success);
            }
            else if (e.CommandName.Equals("Add2"))
            {
                foreach (GridViewRow row2 in this.gvMain.Rows)
                {
                    HiddenField field2 = (HiddenField) row2.FindControl("hfStatus");
                    HiddenField hfId = (HiddenField) row2.FindControl("hfId");
                    tblMainComp comp2 = Queryable.Single<tblMainComp>(this.db.tblMainComps, x => x.Id == Convert.ToInt16(hfId.Value));
                    if (Convert.ToBoolean(field2.Value))
                    {
                        comp2.Down = false;
                    }
                    else
                    {
                        comp2.Down = true;
                    }
                    this.db.SubmitChanges();
                }
                this.bindData();
                this.Popup.SetMessage("Status updated successfully", control_ShowMessage.MessageType.Success);
            }
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.FindControl("hfService");
            e.Row.FindControl("hfId");
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.bindData();
        }
    }

}
