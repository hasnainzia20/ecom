﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_setComm : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
 

    private void bindData()
    {
        var queryable = from x in this.db.tblMainComps
            join y in this.db.tblOperators on x.Id equals y.MainCompId 
            join z in this.db.tblServices on x.ServiceId equals z.Id 
            let Name1 = x.OperatorName
            orderby z.Id, x.OperatorName
            select new { 
                Id = y.Id,
                Operator = ((y.Operator != null) ? (Name1 + " " + y.Operator) : Name1) + ((((z.ServiceName != clsVariables.ServiceType.Mobile) && (z.ServiceName != clsVariables.ServiceType.DTH)) && (z.ServiceName != clsVariables.ServiceType.DataCard)) ? " <span style='color:red'>[Surcharge]</span>" : ""),
                Service = z.ServiceName
            };
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    private void ddlBind()
    {
        var queryable = from x in this.db.tblApis
            orderby x.APIName
            select new { 
                Id = x.Id,
                Name = x.APIName
            };
        this.ddlAPI.DataSource = queryable;
        this.ddlAPI.DataTextField = "Name";
        this.ddlAPI.DataValueField = "Id";
        this.ddlAPI.DataBind();
        this.ddlAPI.Items.Insert(0, " - Select - ");
    }

    protected void ddlUsertype_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (this.ddlAPI.SelectedIndex > 0)
        {
            this.bindData();
        }
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("Add"))
            {
                if (this.ddlAPI.SelectedIndex > 0)
                {
                    GridViewRow namingContainer = (GridViewRow) ((Button) e.CommandSource).NamingContainer;
                    if (this.ddlAPI.SelectedIndex > 0)
                    {
                        HiddenField hfId = (HiddenField) namingContainer.FindControl("hfId");
                        TextBox box = (TextBox) namingContainer.FindControl("txtPercentage");
                        tblAdminComm comm = Queryable.SingleOrDefault<tblAdminComm>(this.db.tblAdminComms, x => (x.OperatorId == Convert.ToInt32(hfId.Value)) && (x.APIId == Convert.ToInt16(this.ddlAPI.SelectedValue)));
                        if (comm != null)
                        {
                            comm.APIId = Convert.ToInt16(this.ddlAPI.SelectedValue);
                            comm.Comm = Convert.ToDecimal(box.Text);
                            this.db.SubmitChanges();
                        }
                        else
                        {
                            tblAdminComm entity = new tblAdminComm {
                                Comm = Convert.ToDecimal(box.Text),
                                APIId = Convert.ToInt16(this.ddlAPI.SelectedValue),
                                OperatorId = Convert.ToInt16(hfId.Value)
                            };
                            this.db.tblAdminComms.InsertOnSubmit(entity);
                            this.db.SubmitChanges();
                        }
                        this.bindData();
                        this.Popup.SetMessage("Admin commission updated successfully", control_ShowMessage.MessageType.Success);
                    }
                }
            }
            else if (e.CommandName.Equals("Add2"))
            {
                foreach (GridViewRow row2 in this.gvMain.Rows)
                {
                    if (this.ddlAPI.SelectedIndex > 0)
                    {
                        HiddenField hfId = (HiddenField) row2.FindControl("hfId");
                        TextBox box2 = (TextBox) row2.FindControl("txtPercentage");
                        tblAdminComm comm3 = Queryable.SingleOrDefault<tblAdminComm>(this.db.tblAdminComms, x => (x.OperatorId == Convert.ToInt32(hfId.Value)) && (x.APIId == Convert.ToInt16(this.ddlAPI.SelectedValue)));
                        if (comm3 != null)
                        {
                            comm3.Comm = Convert.ToDecimal(box2.Text);
                            this.db.SubmitChanges();
                        }
                        else
                        {
                            tblAdminComm comm4 = new tblAdminComm {
                                Comm = Convert.ToDecimal(box2.Text),
                                APIId = Convert.ToInt16(this.ddlAPI.SelectedValue),
                                OperatorId = Convert.ToInt16(hfId.Value)
                            };
                            this.db.tblAdminComms.InsertOnSubmit(comm4);
                            this.db.SubmitChanges();
                        }
                    }
                }
                this.bindData();
                this.Popup.SetMessage("Admin commission updated successfully", control_ShowMessage.MessageType.Success);
            }
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            TextBox box = e.Row.FindControl("txtPercentage") as TextBox;
            e.Row.FindControl("hfService");
            HiddenField hfId = e.Row.FindControl("hfId") as HiddenField;
            if (this.ddlAPI.SelectedIndex > 0)
            {
                tblAdminComm comm = Queryable.SingleOrDefault<tblAdminComm>(this.db.tblAdminComms, x => (x.OperatorId == Convert.ToInt32(hfId.Value)) && (x.APIId == Convert.ToInt16(this.ddlAPI.SelectedValue)));
                if (comm != null)
                {
                    box.Text = comm.Comm.ToString();
                }
                else
                {
                    box.Text = "0.00";
                }
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.bindData();
        }
    }

 
}
