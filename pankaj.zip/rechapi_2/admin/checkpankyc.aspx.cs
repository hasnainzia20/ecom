﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.SessionState;
//using AjaxControlToolkit;
public partial class user_Profile : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);





    SqlCommand cmd;
    DataSet myd = new DataSet();
    DataSet datasetcom = new DataSet();

    SqlConnection con1;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    DataTable dt = new DataTable();
    SqlDataReader dr;

    string st1;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.gridbind();
        }
    }
  
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            Int64 id = Convert.ToInt64(commandArgs[0]);
            Int64 userid = Convert.ToInt64(commandArgs[1]);  
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => (x.Id == userid));
          
            this.lblTitle.Text = "User <b> " + user.CustName + "</b> PAN KYC Documents";
       
            string photoimage = "";
            try
            {
                photoimage = executescalar("select Photo from tblPanDoc where UserId='" + userid + "' and AgentNumber='" + id + "'");
            }
            catch
            {
                photoimage = "no-image.png";
            }

            string photoimage2 = "";
            try
            {
                photoimage2 = executescalar("select Pan from tblPanDoc where UserId='" + userid + "' and AgentNumber='" + id + "'");
            }
            catch
            {
                photoimage2 = "no-image.png";
            }

            string photoimage3 = "";
            try
            {
                photoimage3 = executescalar("select Aadhaar from tblPanDoc where UserId='" + userid + "' and AgentNumber='" + id + "'");
            }
            catch
            {
                photoimage3 = "no-image.png";
            }

         
          
            this.hfId.Value = user.Id.ToString();
          
            this.Image1.ImageUrl = "../kyc/" + photoimage;
            this.Image2.ImageUrl = "../kyc/" + photoimage2;
            this.Image3.ImageUrl = "../kyc/" + photoimage3;
          

            this.popup1222.Show();

        }

        else if (e.CommandName == "lnkapp")
        {
             string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            Int64 id = Convert.ToInt64(commandArgs[0]);
            Int64 userid = Convert.ToInt64(commandArgs[1]);  
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => (x.Id == userid));
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ConnectionString);
             string token = executescalar("select Token from tblPanApi");
            string str33 = string.Empty;
            string strrrs = "http://api.rechapi.com/kyc/kyc.php?format=json&token=" + token + "&mobile=" + id;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strrrs);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            str33 = reader.ReadToEnd();

            if (str33.Contains("200"))
            {
                //============================================
                con.Open();
                DateTime dateTime = DateTime.Now;
                string datestr = dateTime.ToString("MMM dd, yyyy hh:mm:ss tt");
                string app = "APPROVED";
                SqlCommand cmd = new SqlCommand("UPDATE tblPanAgent SET Status ='" + app + "' WHERE UserId ='" + user.Id + "' and AgentMobile = '" + id + "'", con);
                cmd.ExecuteNonQuery();
                con.Close();
                this.gridbind();
                this.popup1222.Hide();

                this.Popup.SetMessage("PAN KYC Approved Successfully", control_ShowMessage.MessageType.Success);
//============================================================
            }
            else
            {
                string rse = str33.Split(new char[] { '"' })[15];
                this.Popup.SetMessage(rse, control_ShowMessage.MessageType.Information);

            }
           
        }
      

        
    }
   


  
    public void gridbind()
    {
         //tblUser getUser = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id);
        
        SqlCommand command = new SqlCommand("SELECT [Id], [UserId], [AgentMobile], [CustomerName], [ShopName], [Address], [PinCode], [State], [Email], [Pan], [DOB], [Aadhaar], [Status] FROM [tblPanAgent] ", this.con);
        SqlDataAdapter adapter = new SqlDataAdapter
        {
           SelectCommand = command
        };
        DataSet dataSet = new DataSet();
        adapter.Fill(dataSet);
        this.GridView1.DataSource = dataSet;
        this.GridView1.DataBind();
    }

   


   public void openconn()
    {

     
        if (con == null)
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());
       
        if (con.State == ConnectionState.Closed)
            con.Open();
    }
    public string executescalar(string str)
    {
        openconn();

        cmd = new SqlCommand(str, con);


        if (str != null)
            st1 = cmd.ExecuteScalar().ToString();


        return st1;
    }

    public string executenonscalar(string str)
    {
        openconn();

        cmd = new SqlCommand(str, con);


        if (str != null)
            st1 = cmd.ExecuteNonQuery().ToString();


        return st1;
    }
 

    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }


  
}

