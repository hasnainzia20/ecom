﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user_Profile : ThemeClass, IRequiresSessionState
{
   
    private DataClassesDataContext db = new DataClassesDataContext();
  


    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            if (this.txtOldPassword.Text != this.txtNewPassword.Text)
            {
                tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                if (user.Password == this.txtOldPassword.Text)
                {
                    user.Password = this.txtNewPassword.Text;
                    this.db.SubmitChanges();
                    this.Popup.SetMessage("Password updated successfully", control_ShowMessage.MessageType.Success);
                    this.txtNewPassword.Text = "";
                    this.txtCNewPassword.Text = "";
                    this.txtOldPassword.Text = "";
                }
                else
                {
                    this.Popup.SetMessage("Old password is incorrect", control_ShowMessage.MessageType.Warning);
                }
            }
            else
            {
                this.Popup.SetMessage("Old password and new password should not be same", control_ShowMessage.MessageType.Warning);
            }
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        bool isPostBack = base.IsPostBack;
    }

   
}
