﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_addCustomer : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
 

    private void ddlBind()
    {
        var queryable = from x in this.db.tblUsers
            where x.UserType == clsVariables.UserType.Reseller
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + x.CustName + "]"
            };
        this.ddlUsers2.DataSource = queryable;
        this.ddlUsers2.DataTextField = "Name";
        this.ddlUsers2.DataValueField = "Id";
        this.ddlUsers2.DataBind();
        this.ddlUsers2.Items.Insert(0, " - Select - ");
        this.ddlUsers3.DataSource = queryable;
        this.ddlUsers3.DataTextField = "Name";
        this.ddlUsers3.DataValueField = "Id";
        this.ddlUsers3.DataBind();
        this.ddlUsers3.Items.Insert(0, " - Select - ");
    }

    protected void lnkAdd3_Click(object sender, EventArgs e)
    {
        if (Convert.ToDecimal(this.txtAmount.Text) > 0M)
        {
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.ddlUsers2.SelectedValue));
            tblUser user2 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.UserType == clsVariables.UserType.Administrator);
            clsMethods.addSMSBalanceHistory(user.Id, clsVariables.TransactionType.Credit, Convert.ToInt32(this.txtAmount.Text), user.Id, user2.Id);
            this.txtAmount.Text = "";
            this.txtRemarks.Text = "";
            this.Popup.SetMessage("SMS Credit transaction done successfully", control_ShowMessage.MessageType.Success);
        }
        else
        {
            this.Popup.SetMessage("Amount is invalid", control_ShowMessage.MessageType.Warning);
        }
    }

    protected void lnkAdd4_Click(object sender, EventArgs e)
    {
        if (Convert.ToDecimal(this.txtAmount2.Text) > 0M)
        {
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.ddlUsers3.SelectedValue));
            if (clsMethods.getSMSCredit(user.Id) >= Convert.ToInt32(this.txtAmount2.Text))
            {
                tblUser user2 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.UserType == clsVariables.UserType.Administrator);
                clsMethods.addSMSBalanceHistory(user.Id, clsVariables.TransactionType.Debit, Convert.ToInt32(this.txtAmount2.Text), user2.Id, user.Id);
                this.db.SubmitChanges();
                this.txtAmount2.Text = "";
                this.txtRemarks2.Text = "";
                this.Popup.SetMessage("SMS Debit Transaction done successfully", control_ShowMessage.MessageType.Success);
            }
            else
            {
                this.Popup.SetMessage("You can't debit amount than the available balance of user", control_ShowMessage.MessageType.Warning);
            }
        }
        else
        {
            this.Popup.SetMessage("Amount is invalid", control_ShowMessage.MessageType.Warning);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
        }
    }

 
}
