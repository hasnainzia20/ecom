﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


public partial class admin_rechargeAPI : ThemeClass, IRequiresSessionState

{
  
    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
           
          
            try
            {

              
            }

            catch (Exception ex)
            {

                this.Popup.SetMessage(ex.Message, control_ShowMessage.MessageType.Warning);

            }

        }
        catch (Exception ex)
        {

            this.Popup.SetMessage(ex.Message, control_ShowMessage.MessageType.Warning);

        }
    }

    public void refress()
    {

        TextBox4.Text = "";

        TextBox2.Text = "";

        apiname.Text = "";

        TextBox3.Text = "";


        TextBox6.Text = "";
        balcheck.Text = "";
        

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        refress();

     
    }
  
   
}
	