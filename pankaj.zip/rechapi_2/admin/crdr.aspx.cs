﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

public partial class admin_crdr : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
    private clsMethods sMethod = new clsMethods();
  

    private void ddlBind()
    {
        IEnumerable<clsVariables.DroptDownClass> enumerable = Enumerable.Where<clsVariables.DroptDownClass>(clsVariables.UserTypes(), delegate (clsVariables.DroptDownClass x) {
            if ((x.Value != clsVariables.UserType.User) && (x.Value != clsVariables.UserType.Reseller) && (x.Value != clsVariables.UserType.Retailer) && (x.Value != clsVariables.UserType.Distributor) && (x.Value != clsVariables.UserType.SuperDistributor))
            {
                return x.Value == " - Select - ";
            }
            return true;
        });
        this.ddlUsertype2.DataSource = enumerable;
        this.ddlUsertype2.DataTextField = "Text";
        this.ddlUsertype2.DataValueField = "Value";
        this.ddlUsertype2.DataBind();
        this.ddlUsertype3.DataSource = enumerable;
        this.ddlUsertype3.DataTextField = "Text";
        this.ddlUsertype3.DataValueField = "Value";
        this.ddlUsertype3.DataBind();
    }

    protected void ddlUsertype2_SelectedIndexChanged(object sender, EventArgs e)
    {
        var queryable = from x in this.db.tblUsers
            where x.UserType == this.ddlUsertype2.SelectedValue
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + x.CustName + "]"
            };
        this.ddlUsers2.DataSource = queryable;
        this.ddlUsers2.DataTextField = "Name";
        this.ddlUsers2.DataValueField = "Id";
        this.ddlUsers2.DataBind();
        this.ddlUsers2.Items.Insert(0, " - Select - ");
    }

    protected void ddlUsertype3_SelectedIndexChanged(object sender, EventArgs e)
    {
        var queryable = from x in this.db.tblUsers
            where x.UserType == this.ddlUsertype3.SelectedValue
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + x.CustName + "]"
            };
        this.ddlUsers3.DataSource = queryable;
        this.ddlUsers3.DataTextField = "Name";
        this.ddlUsers3.DataValueField = "Id";
        this.ddlUsers3.DataBind();
        this.ddlUsers3.Items.Insert(0, " - Select - ");
    }

    protected void lnkAdd3_Click(object sender, EventArgs e)
    {
        if (Convert.ToDecimal(this.txtAmount.Text) > 0M)
        {
            decimal amfordue = Convert.ToDecimal(this.txtAmount.Text);
            decimal num = 0M;
            decimal num2 = 0M;
            decimal num3 = 0M;
            if (this.ddlUsertype2.SelectedValue == clsVariables.UserType.Reseller)
            {
                num = clsMethods.getBalance(Convert.ToInt32(this.Session["aUserId"].ToString()));
            }
            else
            {
                num = clsMethods.getBalance(Convert.ToInt32(this.Session["aUserId"].ToString()));
            }
            if (num >= Convert.ToDecimal(this.txtAmount.Text))
            {
                tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.ddlUsers2.SelectedValue));
                if (this.ddlUsertype2.SelectedValue == clsVariables.UserType.Reseller)
                {
                    num3 = clsMethods.getABalance(user.Id);
                }
                else
                {
                    num3 = clsMethods.getBalance(user.Id);
                }
                tblUser user2 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.UserType == clsVariables.UserType.Administrator);
                if (this.ddlUsertype2.SelectedValue == clsVariables.UserType.Reseller)
                {
                    clsMethods.addTrans(user2.Id, Convert.ToDecimal(this.txtAmount.Text), (this.txtRemarks.Text != null) ? this.txtRemarks.Text : null, user.Id, user.Id, clsMethods.getBalance(user.Id), clsVariables.TransactionType.Credit, 0L, clsMethods.getBalance(user2.Id), clsMethods.getBalance(user.Id), user.Id, clsMethods.getABalance(user.Id) + Convert.ToDecimal(this.txtAmount.Text));
                }
                else
                {
                    clsMethods.addTrans(user2.Id, Convert.ToDecimal(this.txtAmount.Text), (this.txtRemarks.Text != null) ? this.txtRemarks.Text : null, user.Id, user.Id, clsMethods.getBalance(user.Id) + Convert.ToDecimal(this.txtAmount.Text), clsVariables.TransactionType.Credit, 0L, clsMethods.getBalance(user2.Id) - Convert.ToDecimal(this.txtAmount.Text), 0M, 0, -1M);
                }
                if (this.ddlUsertype2.SelectedValue == clsVariables.UserType.Reseller)
                {
                    num2 = clsMethods.getABalance(user.Id);
                }
                else
                {
                    num2 = clsMethods.getBalance(user.Id);
                }
                string message = "Dear " + user.CustName + ",Your Account Has Been Credited with amount." + this.txtAmount.Text + " and Your Old Bal. is Rs. " + num3.ToString() + " and New Bal. is Rs. " + num2.ToString("0,0.00") + ". Thanks.";
                clsMethods.sendSMS(user.Mobile, message, "26794");
                this.txtAmount.Text = "";
                this.txtRemarks.Text = "";
                this.Popup.SetMessage("Credit transaction done Successfully", control_ShowMessage.MessageType.Success);
                try
                {
                    if (this.due.Checked)
                    {
                        tblDueAmount entity = new tblDueAmount
                        {
                            UserId = user.Id,
                            DueAmount = amfordue,
                            DueDate = DateTime.Now,
                            PaidDate = null,
                            Status = "DUE"
                        };
                        this.db.tblDueAmounts.InsertOnSubmit(entity);
                        this.db.SubmitChanges();
                    }
                }
                catch (Exception ex)
                {
                    this.Popup.SetMessage(ex.Message, control_ShowMessage.MessageType.Error);
                }

                
            }
            else
            {
                this.Popup.SetMessage("You don't have sufficient balance to credit", control_ShowMessage.MessageType.Warning);
            }
        }
        else
        {
            this.Popup.SetMessage("Amount is invalid", control_ShowMessage.MessageType.Warning);
        }
    }

    protected void lnkAdd4_Click(object sender, EventArgs e)
    {
        if (Convert.ToDecimal(this.txtAmount2.Text) > 0M)
        {
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.ddlUsers3.SelectedValue));
            decimal num = 0M;
            if (this.ddlUsertype3.SelectedValue == clsVariables.UserType.Reseller)
            {
                num = clsMethods.getABalance(user.Id);
            }
            else
            {
                num = clsMethods.getBalance(user.Id);
            }
            if (num >= Convert.ToDecimal(this.txtAmount2.Text))
            {
                tblUser user2 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.UserType == clsVariables.UserType.Administrator);
                if (this.ddlUsertype3.SelectedValue == clsVariables.UserType.Reseller)
                {
                    clsMethods.addTrans(user.Id, Convert.ToDecimal(this.txtAmount2.Text), (this.txtRemarks2.Text != null) ? this.txtRemarks2.Text : null, user2.Id, user.Id, clsMethods.getBalance(user.Id), clsVariables.TransactionType.Debit, 0L, clsMethods.getBalance(user2.Id), 0M, user.Id, clsMethods.getABalance(user.Id) - Convert.ToDecimal(this.txtAmount2.Text));
                }
                else
                {
                    clsMethods.addTrans(user.Id, Convert.ToDecimal(this.txtAmount2.Text), (this.txtRemarks2.Text != null) ? this.txtRemarks2.Text : null, user2.Id, user.Id, clsMethods.getBalance(user.Id) - Convert.ToDecimal(this.txtAmount2.Text), clsVariables.TransactionType.Debit, 0L, clsMethods.getBalance(user2.Id) + Convert.ToDecimal(this.txtAmount2.Text), 0M, 0, -1M);
                }
                if (this.ddlUsertype3.SelectedValue == clsVariables.UserType.Reseller)
                {
                    clsMethods.getABalance(user.Id);
                }
                else
                {
                    clsMethods.getBalance(user.Id);
                }
                string message = "Dear " + user.CustName + ",Your Account Has Been Credited with amount." + this.txtAmount2.Text + " and Your Old Bal. is Rs. " + num.ToString() + " and New Bal. is Rs. " + clsMethods.getBalance(Convert.ToInt32(user.Id)).ToString("0,0.00") + ". Thanks.";
                clsMethods.sendSMS(user.Mobile, message, "26794");
                this.txtAmount2.Text = "";
                this.txtRemarks2.Text = "";
                this.Popup.SetMessage("Debit Transaction done successfully", control_ShowMessage.MessageType.Success);
            }
            else
            {
                this.Popup.SetMessage("You can't debit amount than the available balance of user", control_ShowMessage.MessageType.Warning);
            }
        }
        else
        {
            this.Popup.SetMessage("Amount is invalid", control_ShowMessage.MessageType.Warning);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
        }
    }


}

