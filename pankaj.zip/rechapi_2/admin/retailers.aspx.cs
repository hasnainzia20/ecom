﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class admin_sd13 : ThemeClass, IRequiresSessionState
{

    private DataClassesDataContext db = new DataClassesDataContext();
   
    private void bindData()
    {
        var queryable = from x in this.db.tblUsers
            join z in this.db.tblUsers on x.ParentId equals (int?) z.Id
            join y in this.db.tblCommPackages on x.SchemeId equals (short?) y.Id
            where x.UserType == clsVariables.UserType.Retailer
            orderby x.Username
            select new { 
                Id = x.Id,
                Username = x.Username,
                Name = (x.Username + " [") + x.CustName + "]",
                Parent = (z.Username + " [") + z.CustName + "]",
                Mobile = x.Mobile,
                AddDate = x.AddDate,
                Package = y.PackageName,
                Balance = clsMethods.getBalance(x.Id),
                Status = x.Status ? "Active" : "DeActive",
                Status1 = x.Status,
                CssClass = x.Status ? "btn btn-sm btn-success" : "btn btn-sm btn-danger"
            };
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            queryable = from x in queryable
                where x.Username.Contains(this.txtSearch.Text) || x.Mobile.Contains(this.txtSearch.Text)
                select x;
        }
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnAdd_Click(object sender, EventArgs e)
    {
        if (this.bttnAdd.Text == "Update User")
        {
            tblUser addSeries = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.hfId.Value));
            if (addSeries != null)
            {
                if (Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Username == this.txtUsername.Text) && (x.Id != addSeries.Id)) == null)
                {
                    if (Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Mobile == this.txtMobile.Text) && (x.Id != addSeries.Id)) == null)
                    {
                        addSeries.Username = this.txtUsername.Text;
                        addSeries.Password = this.txtPassword.Text;
                        addSeries.Mobile = this.txtMobile.Text;
                        addSeries.ParentId = new int?(Convert.ToInt32(this.ddlParent.SelectedValue));
                        addSeries.SchemeId = new short?(Convert.ToInt16(this.ddlPackage.SelectedValue));
                        if ((this.txtEmail.Text != null) && (this.txtEmail.Text != ""))
                        {
                            addSeries.Email = this.txtEmail.Text;
                        }
                        if ((this.txtCity.Text != null) && (this.txtCity.Text != ""))
                        {
                            addSeries.City = this.txtCity.Text;
                        }
                        if ((this.txtCompany.Text != null) && (this.txtCompany.Text != ""))
                        {
                            addSeries.Company = this.txtCompany.Text;
                        }
                        if ((this.txtPostalCode.Text != null) && (this.txtPostalCode.Text != ""))
                        {
                            addSeries.PostalCode = this.txtPostalCode.Text;
                        }
                        if ((this.txtAddress.Text != null) && (this.txtAddress.Text != ""))
                        {
                            addSeries.Address = this.txtAddress.Text;
                        }
                        this.db.SubmitChanges();
                        this.bindData();
                        this.popup1222.Hide();
                        this.Popup.SetMessage("Retailer updated successfully", control_ShowMessage.MessageType.Success);
                    }
                    else
                    {
                        this.Popup.SetMessage("Mobile already exist", control_ShowMessage.MessageType.Warning);
                    }
                }
                else
                {
                    this.Popup.SetMessage("Username already exist", control_ShowMessage.MessageType.Warning);
                }
            }
        }
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
        var queryable = from x in this.db.tblUsers
            where ((x.UserType == clsVariables.UserType.Administrator) || (x.UserType == clsVariables.UserType.SuperDistributor)) || (x.UserType == clsVariables.UserType.Distributor)
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + x.CustName + "]"
            };
        this.ddlParent.DataSource = queryable;
        this.ddlParent.DataTextField = "Name";
        this.ddlParent.DataValueField = "Id";
        this.ddlParent.DataBind();
        this.ddlParent.Items.Insert(0, " - Select - ");
        string domain = base.Request.Headers.Get("Host").ToString().Replace("www.", "").Replace("http://", "");

        tblUser user = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Domain.Replace("www.", "").Replace("http://", "") == domain) && ((x.UserType == clsVariables.UserType.Administrator)));
        
        var queryable2 = from x in this.db.tblCommPackages
                         where x.UserType == clsVariables.UserType.Retailer && x.UserId == user.Id
            orderby x.PackageName
            select new { 
                Id = x.Id,
                Name = x.PackageName
            };
        this.ddlPackage.DataSource = queryable2;
        this.ddlPackage.DataTextField = "Name";
        this.ddlPackage.DataValueField = "Id";
        this.ddlPackage.DataBind();
        this.ddlPackage.Items.Insert(0, " - Select - ");
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            this.lblTitle.Text = "UPDATE USER";
            this.bttnAdd.Text = "Update User";
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.hfId.Value = user.Id.ToString();
            this.txtUsername.Text = user.Username;
            this.txtName.Text = user.CustName;
            this.txtMobile.Text = user.Mobile;
            this.txtPassword.Text = user.Password;
            this.ddlParent.SelectedValue = user.ParentId.ToString();
            this.ddlPackage.SelectedValue = user.SchemeId.ToString();
            if ((user.Email != null) && (user.Email != ""))
            {
                this.txtEmail.Text = user.Email;
            }
            if ((user.Company != null) && (user.Company != ""))
            {
                this.txtCompany.Text = user.Email;
            }
            if ((user.PostalCode != null) && (user.PostalCode != ""))
            {
                this.txtPostalCode.Text = user.PostalCode;
            }
            if ((user.City != null) && (user.City != ""))
            {
                this.txtCity.Text = user.City;
            }
            if ((user.Address != null) && (user.Address != ""))
            {
                this.txtAddress.Text = user.Address;
            }
            this.popup1222.Show();
        }
        else if (e.CommandName == "lnkDelete")
        {
            tblCommPackage entity = Queryable.Single<tblCommPackage>(this.db.tblCommPackages, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.db.tblCommPackages.DeleteOnSubmit(entity);
            this.db.SubmitChanges();
            this.bindData();
            this.Popup.SetMessage("User deleted successfully", control_ShowMessage.MessageType.Success);
        }
        else if (e.CommandName.Equals("Status"))
        {
            tblUser user2 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(e.CommandArgument.ToString()));
            if (user2.Status)
            {
                user2.Status = false;
            }
            else
            {
                user2.Status = true;
            }
            this.db.SubmitChanges();
            this.bindData();
            this.Popup.SetMessage("Status updated successfully", control_ShowMessage.MessageType.Success);
        }
          else if (e.CommandName == "mservices")
        {
            this.flbl.Text = "Manage Services Authority (UserId - " + e.CommandArgument.ToString() + ")";
            this.idvalue.Value = e.CommandArgument.ToString();
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));

            ob ob = new ob();
            string auth = "";
            try
            {
                auth = ob.executescalar("select count(UserId) as UserId from tblServicesAuth where UserId = '" + this.idvalue.Value + "'").ToString();
                if (auth == "0")
                {
                    string insertvalue = "insert into tblServicesAuth values ('" + idvalue.Value + "','" + idvalue.Value + "','" + pan.Checked + "','" + panapi.Checked + "','" + rbs.Checked + "','" + money.Checked + "','" + moneyapi.Checked + "','" + android.Checked + "','" + mdfapi.Checked + "','" + dbv.Checked + "','" + dbvapi.Checked + "','" + dthinfoapi.Checked + "','" + bcheckapi.Checked + "','" + rofferapi.Checked + "')";
                    string insdatarecharge = ob.executenonscalar(insertvalue).ToString();

                    this.rechargeapi.Checked = user.RechargeAPI;

                }
                else
                {

                    string pann = ob.executescalar("select PanCard from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.pan.Checked = Convert.ToBoolean(pann);
                    string PanCardApi = ob.executescalar("select PanCardApi from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.panapi.Checked = Convert.ToBoolean(PanCardApi);
                    string Recharge = ob.executescalar("select Recharge from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.rbs.Checked = Convert.ToBoolean(Recharge);
                    this.rechargeapi.Checked = user.RechargeAPI;
                    string MoneyTransfer = ob.executescalar("select MoneyTransfer from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.money.Checked = Convert.ToBoolean(MoneyTransfer);
                    string MoneyTransferApi = ob.executescalar("select MoneyTransferApi from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.moneyapi.Checked = Convert.ToBoolean(MoneyTransferApi);
                    string AndroidApp = ob.executescalar("select AndroidApp from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.android.Checked = Convert.ToBoolean(AndroidApp);
                    string MDFApi = ob.executescalar("select MDFApi from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.mdfapi.Checked = Convert.ToBoolean(MDFApi);
                    string DBV = ob.executescalar("select DBV from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.dbv.Checked = Convert.ToBoolean(DBV);
                    string DBVApi = ob.executescalar("select DBVApi from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.dbvapi.Checked = Convert.ToBoolean(DBVApi);
                    string DTHInfoApi = ob.executescalar("select DTHInfoApi from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.dthinfoapi.Checked = Convert.ToBoolean(DTHInfoApi);
                    string BillCheckApi = ob.executescalar("select BillCheckApi from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.bcheckapi.Checked = Convert.ToBoolean(BillCheckApi);
                    string rofCheckApi = ob.executescalar("select PlanApi from tblServicesAuth where UserId='" + idvalue.Value + "'").ToString();
                    this.rofferapi.Checked = Convert.ToBoolean(rofCheckApi);
                }
            }
            catch (Exception ex)
            {
                this.Popup.SetMessage(ex.Message, control_ShowMessage.MessageType.Warning);
            }
            this.fupop.Show();
        }
    }
    protected void bttnsave_Click(object sender, EventArgs e)
    {
        ob ob = new ob();
        string auth = "";
        try
        {
            auth = ob.executescalar("select count(UserId) as UserId from tblServicesAuth where UserId = '" + this.idvalue.Value + "'").ToString();
            if (auth == "0")
            {
                string insertvalue = "insert into tblServicesAuth values ('" + idvalue.Value + "','" + this.Session["aUserId"].ToString() + "','" + pan.Checked + "','" + panapi.Checked + "','" + rbs.Checked + "','" + money.Checked + "','" + moneyapi.Checked + "','" + android.Checked + "','" + mdfapi.Checked + "','" + dbv.Checked + "','" + dbvapi.Checked + "','" + dthinfoapi.Checked + "','" + bcheckapi.Checked + "','" + rofferapi.Checked + "')";
                string insdatarecharge = ob.executenonscalar(insertvalue).ToString();
                this.Popup.SetMessage("Services Authority Updated Successfully", control_ShowMessage.MessageType.Success);
                this.fupop.Hide();
                this.bindData();
            }
            else
            {
                tblUser addSeries = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.idvalue.Value));
                if (addSeries != null)
                {
                    addSeries.RechargeAPI = this.rechargeapi.Checked;
                    this.db.SubmitChanges();
                }
                string insertvalue1 = "UPDATE tblServicesAuth SET PanCard = '" + pan.Checked + "', PanCardApi = '" + panapi.Checked + "', Recharge = '" + rbs.Checked + "', MoneyTransfer = '" + money.Checked + "', MoneyTransferApi = '" + moneyapi.Checked + "', AndroidApp = '" + android.Checked + "', MDFApi = '" + mdfapi.Checked + "', DBV = '" + dbv.Checked + "', DBVApi = '" + dbvapi.Checked + "', DTHInfoApi = '" + dthinfoapi.Checked + "', BillCheckApi = '" + bcheckapi.Checked + "', PlanApi = '" + rofferapi.Checked + "' WHERE UserId = '" + idvalue.Value + "';";
                string insdatarecharge1 = ob.executenonscalar(insertvalue1).ToString();
                this.Popup.SetMessage("Services Authority Updated Successfully", control_ShowMessage.MessageType.Success);
                this.fupop.Hide();
                this.bindData();

            }
        }
        catch (Exception ex)
        {
            this.Popup.SetMessage(ex.Message, control_ShowMessage.MessageType.Warning);
        }

    
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "20",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.bindData();
        }
    }

    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }

 
}
