﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


public partial class apiswitch : ThemeClass, IRequiresSessionState

{
    private DataClassesDataContext db = new DataClassesDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            try
            {

                tblPanApi api = Queryable.Single<tblPanApi>(this.db.tblPanApis, x => x.Id == 1);

                this.username.Text = api.Username;
                this.token.Text = api.Token;

            }
            catch
            {
                this.Popup.SetMessage("unable to load the data, there is some error", control_ShowMessage.MessageType.Error);
            }
        }
    }
    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            tblPanApi api = Queryable.Single<tblPanApi>(this.db.tblPanApis, x => x.Id == 1);
            api.Username = this.username.Text;
            api.Token = this.token.Text;
            this.db.SubmitChanges();
          
            this.Popup.SetMessage("PAN API Settings Updated Successfully ", control_ShowMessage.MessageType.Success);
           
        }
        catch
        {
            this.Popup.SetMessage("unable to update the data, there is some error", control_ShowMessage.MessageType.Error);
        }
    }
   
   
}
	