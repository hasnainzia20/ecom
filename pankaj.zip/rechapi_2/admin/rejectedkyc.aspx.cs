﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Web.Script.Serialization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.SessionState;
//using AjaxControlToolkit;
public partial class user_Profile : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);





    SqlCommand cmd;
    DataSet myd = new DataSet();
    DataSet datasetcom = new DataSet();

    SqlConnection con1;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    DataTable dt = new DataTable();
    SqlDataReader dr;

    string st1;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.gridbind();
        }
    }
 
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => (x.Id == Convert.ToInt16(e.CommandArgument.ToString())));

            this.lblTitle.Text = "User <b> " + user.CustName + "</b> KYC Documents";

            string photoimage = "";
            try
            {
                photoimage = executescalar("select Photo from tblKYCDoc where UserId='" + user.Id + "'");
            }
            catch
            {
                photoimage = "no-image.png";
            }

            string photoimage2 = "";
            try
            {
                photoimage2 = executescalar("select PanPhoto from tblKYCDoc where UserId='" + user.Id + "'");
            }
            catch
            {
                photoimage2 = "no-image.png";
            }

            string photoimage3 = "";
            try
            {
                photoimage3 = executescalar("select AddressPhoto1 from tblKYCDoc where UserId='" + user.Id + "'");
            }
            catch
            {
                photoimage3 = "no-image.png";
            }

            string photoimage4 = "";
            try
            {
                photoimage4 = executescalar("select AddressPhoto2 from tblKYCDoc where UserId='" + user.Id + "'");
            }
            catch
            {
                photoimage4 = "no-image.png";
            }



            this.hfId.Value = user.Id.ToString();
            this.Label1.Text = this.hfId.Value;
            this.Image1.ImageUrl = "../kyc/" + photoimage;
            this.Image2.ImageUrl = "../kyc/" + photoimage2;
            this.Image3.ImageUrl = "../kyc/" + photoimage3;
            this.Image4.ImageUrl = "../kyc/" + photoimage4;

            this.popup1222.Show();

        }
        if (e.CommandName == "lnkbd")
        {
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => (x.Id == Convert.ToInt16(e.CommandArgument.ToString())));

            this.lblTitle2.Text = "KYC <b> " + user.Id + "</b> Business Details";

            string lb1 = executescalar("select Bname from tblKYC where UserId='" + user.Id + "'");
            string lb2 = executescalar("select Baddress from tblKYC where UserId='" + user.Id + "'");
            string lb3 = executescalar("select NatureB from tblKYC where UserId='" + user.Id + "'");
            string lb4 = executescalar("select OtherB from tblKYC where UserId='" + user.Id + "'");




            this.Label1.Text = lb1;
            this.Label2.Text = lb2;
            this.Label3.Text = lb3;
            this.Label4.Text = lb4;


            this.popup1333.Show();

        }

    }

    public void gridbind()
    {
        //tblUser getUser = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id);

        SqlCommand command = new SqlCommand("SELECT [Id], [FullName], [DOB], [Mobile], [Gender], [City], [Pin], [Address], [State], [ProofType], [ProofId], [PAN], [Bname], [Baddress], [NatureB], [OtherB], [KYCDate], [KYCADate], [Status], [UserId] FROM [tblKYC] WHERE Status = 'REJECTED'", this.con);
        SqlDataAdapter adapter = new SqlDataAdapter
        {
            SelectCommand = command
        };
        DataSet dataSet = new DataSet();
        adapter.Fill(dataSet);
        this.GridView1.DataSource = dataSet;
        this.GridView1.DataBind();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GridView1.PageIndex = e.NewPageIndex;
        this.gridbind();
    }


    public void openconn()
    {


        if (con == null)
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());

        if (con.State == ConnectionState.Closed)
            con.Open();
    }
    public string executescalar(string str)
    {
        openconn();

        cmd = new SqlCommand(str, con);


        if (str != null)
            st1 = cmd.ExecuteScalar().ToString();


        return st1;
    }

    public string executenonscalar(string str)
    {
        openconn();

        cmd = new SqlCommand(str, con);


        if (str != null)
            st1 = cmd.ExecuteNonQuery().ToString();


        return st1;
    }


 
    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }



}

