﻿using AjaxControlToolkit;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_rechargeReport : ThemeClass, IRequiresSessionState
{
    
    private DataClassesDataContext db = new DataClassesDataContext();


    private void gredibind()
    {
        var queryable3 = from x in this.db.tblRecharges
                         join y in this.db.tblOperators on x.OperatorId equals (short?)y.Id
                         join z in this.db.tblMainComps on y.MainCompId equals (short?)z.Id 
                       
                         orderby x.RechargeDate descending
                         select new
                         {
                             OperatorName = z.OperatorName,
                             SuccessAmount = x.Amount
                        };
        this.gvMain.DataSource = queryable3;
        this.gvMain.DataBind();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.gredibind();
           // this.txtTo.Text = this.txtFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            
        }
    }

  

    public override void VerifyRenderingInServerForm(Control control)
    {
    }

  
}
