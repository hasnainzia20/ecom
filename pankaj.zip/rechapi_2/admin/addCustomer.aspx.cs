﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_addCustomer : ThemeClass, IRequiresSessionState
{

    private DataClassesDataContext db = new DataClassesDataContext();
  

    private void bindDistComm()
    {
        var queryable = from x in this.db.tblCommPackages
            where (x.UserType == clsVariables.UserType.Distributor) && (x.UserId == Convert.ToInt32(this.Session["aUserId"].ToString()))
            select new { 
                Id = x.Id,
                Name = x.PackageName
            };
        this.ddlPackages2.DataSource = queryable;
        this.ddlPackages2.DataTextField = "Name";
        this.ddlPackages2.DataValueField = "Id";
        this.ddlPackages2.DataBind();
        this.ddlPackages2.Items.Insert(0, " - Select - ");
    }

    private void bindParent1()
    {
        var queryable = from x in this.db.tblUsers
            where ((x.UserType == clsVariables.UserType.SuperDistributor) || (x.UserType == clsVariables.UserType.Distributor)) || (x.UserType == clsVariables.UserType.Administrator)
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + x.CustName + "]"
            };
        this.ddlParent.DataSource = queryable;
        this.ddlParent.DataTextField = "Name";
        this.ddlParent.DataValueField = "Id";
        this.ddlParent.DataBind();
        this.ddlParent.Items.Insert(0, " - Select - ");
    }

    private void bindParent2()
    {
        var queryable = from x in this.db.tblUsers
            where (x.UserType == clsVariables.UserType.SuperDistributor) || (x.UserType == clsVariables.UserType.Administrator)
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + x.CustName + "]"
            };
        this.ddlParent2.DataSource = queryable;
        this.ddlParent2.DataTextField = "Name";
        this.ddlParent2.DataValueField = "Id";
        this.ddlParent2.DataBind();
        this.ddlParent2.Items.Insert(0, " - Select - ");
    }

    private void bindParent3()
    {
        var queryable = from x in this.db.tblUsers
            where x.UserType == clsVariables.UserType.Administrator
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + x.CustName + "]"
            };
        this.ddlParent3.DataSource = queryable;
        this.ddlParent3.DataTextField = "Name";
        this.ddlParent3.DataValueField = "Id";
        this.ddlParent3.DataBind();
        this.ddlParent3.Items.Insert(0, " - Select - ");
    }

    private void bindRetComm()
    {
        var queryable = from x in this.db.tblCommPackages
            where (x.UserType == clsVariables.UserType.Retailer) && (x.UserId == Convert.ToInt32(this.Session["aUserId"].ToString()))
            select new { 
                Id = x.Id,
                Name = x.PackageName
            };
        this.ddlRetComm.DataSource = queryable;
        this.ddlRetComm.DataTextField = "Name";
        this.ddlRetComm.DataValueField = "Id";
        this.ddlRetComm.DataBind();
        this.ddlRetComm.Items.Insert(0, " - Select - ");
        queryable = from x in this.db.tblCommPackages
            where (x.UserType == clsVariables.UserType.User) && (x.UserId == Convert.ToInt32(this.Session["aUserId"].ToString()))
            select new { 
                Id = x.Id,
                Name = x.PackageName
            };
        this.ddlUPackage.DataSource = queryable;
        this.ddlUPackage.DataTextField = "Name";
        this.ddlUPackage.DataValueField = "Id";
        this.ddlUPackage.DataBind();
        this.ddlUPackage.Items.Insert(0, " - Select - ");
    }

    private void bindSDistComm()
    {
        var queryable = from x in this.db.tblCommPackages
            where (x.UserType == clsVariables.UserType.SuperDistributor) && (x.UserId == Convert.ToInt32(this.Session["aUserId"].ToString()))
            select new { 
                Id = x.Id,
                Name = x.PackageName
            };
        this.ddlPackages3.DataSource = queryable;
        this.ddlPackages3.DataTextField = "Name";
        this.ddlPackages3.DataValueField = "Id";
        this.ddlPackages3.DataBind();
        this.ddlPackages3.Items.Insert(0, " - Select - ");
        var queryable2 = from x in this.db.tblCommPackages
            where (x.UserType == clsVariables.UserType.Reseller) && (x.UserId == Convert.ToInt32(this.Session["aUserId"].ToString()))
            select new { 
                Id = x.Id,
                Name = x.PackageName
            };
        this.ddlPackages4.DataSource = queryable2;
        this.ddlPackages4.DataTextField = "Name";
        this.ddlPackages4.DataValueField = "Id";
        this.ddlPackages4.DataBind();
        this.ddlPackages4.Items.Insert(0, " - Select - ");
    }

    private void bindUsers()
    {
        var queryable = from x in this.db.tblUsers
            where x.UserType == clsVariables.UserType.User
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + x.CustName + "]"
            };
        this.ddlUsers.DataSource = queryable;
        this.ddlUsers.DataTextField = "Name";
        this.ddlUsers.DataValueField = "Id";
        this.ddlUsers.DataBind();
        this.ddlUsers.Items.Insert(0, " - Select - ");
    }

    private void bindUsertype()
    {
        this.ddlUsertype.DataSource = Enumerable.Where<clsVariables.DroptDownClass>(clsVariables.UserTypes(), delegate (clsVariables.DroptDownClass x) {
            if (x.Value != clsVariables.UserType.User)
            {
                return x.Value == clsVariables.UserType.Retailer;
            }
            return true;
        });
        this.ddlUsertype.DataTextField = "Text";
        this.ddlUsertype.DataValueField = "Value";
        this.ddlUsertype.DataBind();
        this.ddlUsertype.Items.Insert(0, " - Select - ");
        this.ddlUsertype2.DataSource = Enumerable.Where<clsVariables.DroptDownClass>(clsVariables.UserTypes(), delegate (clsVariables.DroptDownClass x) {
            if ((x.Value != clsVariables.UserType.User) && (x.Value != clsVariables.UserType.Retailer))
            {
                return x.Value == clsVariables.UserType.Distributor;
            }
            return true;
        });
        this.ddlUsertype2.DataTextField = "Text";
        this.ddlUsertype2.DataValueField = "Value";
        this.ddlUsertype2.DataBind();
        this.ddlUsertype2.Items.Insert(0, " - Select - ");
    }

    protected void ddlUsertype_SelectedIndexChanged(object sender, EventArgs e)
    {
        var queryable = from x in this.db.tblUsers
            where x.UserType == this.ddlUsertype.SelectedValue
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + x.CustName + "]"
            };
        this.ddlRetailer.DataSource = queryable;
        this.ddlRetailer.DataTextField = "Name";
        this.ddlRetailer.DataValueField = "Id";
        this.ddlRetailer.DataBind();
        this.ddlRetailer.Items.Insert(0, " - Select - ");
    }

    protected void ddlUsertype2_SelectedIndexChanged(object sender, EventArgs e)
    {
        var queryable = from x in this.db.tblUsers
            where x.UserType == this.ddlUsertype2.SelectedValue
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + x.CustName + "]"
            };
        this.ddlSDistributor.DataSource = queryable;
        this.ddlSDistributor.DataTextField = "Name";
        this.ddlSDistributor.DataValueField = "Id";
        this.ddlSDistributor.DataBind();
        this.ddlSDistributor.Items.Insert(0, " - Select - ");
    }

    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            if (Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => x.Mobile == this.txtMobile.Text) == null)
            {
                tblUser entity = new tblUser {
                    ParentId = new int?(Convert.ToInt32(this.Session["aUserId"].ToString())),
                    Mobile = this.txtMobile.Text,
                    CustName = this.txtName.Text,
                    SchemeId = new short?(Convert.ToInt16(this.ddlUPackage.SelectedValue)),
                    Password = clsMethods.GetUniqueKey(10)
                };
                if ((this.txtEmail.Text != null) && (this.txtEmail.Text != ""))
                {
                    entity.Email = this.txtEmail.Text;
                }
                if ((this.txtCompany.Text != null) && (this.txtCompany.Text != ""))
                {
                    entity.Company = this.txtEmail.Text;
                }
                if ((this.txtCity.Text != null) && (this.txtCity.Text != ""))
                {
                    entity.City = this.txtCity.Text;
                }
                if ((this.txtPostalCode.Text != null) && (this.txtPostalCode.Text != ""))
                {
                    entity.PostalCode = this.txtPostalCode.Text;
                }
                if ((this.txtAddress.Text != null) && (this.txtAddress.Text != ""))
                {
                    entity.Address = this.txtAddress.Text;
                }
                entity.AddDate = DateTime.Now;
                entity.UserType = clsVariables.UserType.User;
                entity.RechargeAPI = this.chkRechargeAPI.Checked;
                entity.Firstime = true;
                entity.Status = true;
                entity.Domain = this.Session["Domain"].ToString();
                this.db.tblUsers.InsertOnSubmit(entity);
                this.db.SubmitChanges();
                clsMethods.sendSMS(entity.Mobile, "Dear " + entity.CustName + ", Your account created successfully. UserId: " + entity.Id.ToString() + ", Password: " + entity.Password + ". Please login to " + this.Session["Domain"].ToString() + " to access account.", "0");
                this.reset();
                this.bindParent1();
                this.Popup.SetMessage("User created successfully", control_ShowMessage.MessageType.Success);
            }
            else
            {
                this.Popup.SetMessage("Mobile No already exist", control_ShowMessage.MessageType.Warning);
            }
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void lnkAdd2_Click(object sender, EventArgs e)
    {
        tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.ddlUsers.SelectedValue));
        user.UserType = clsVariables.UserType.Retailer;
        user.ParentId = new int?(Convert.ToInt32(this.ddlParent.SelectedValue));
        user.SchemeId = new short?(Convert.ToInt16(this.ddlRetComm.SelectedValue));
        this.db.SubmitChanges();
        this.Popup.SetMessage("Retailer created successfully", control_ShowMessage.MessageType.Success);
    }

    protected void lnkAdd3_Click(object sender, EventArgs e)
    {
        tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.ddlRetailer.SelectedValue));
        user.UserType = clsVariables.UserType.Distributor;
        user.ParentId = new int?(Convert.ToInt32(this.ddlParent2.SelectedValue));
        user.SchemeId = new short?(Convert.ToInt16(this.ddlPackages2.SelectedValue));
        this.db.SubmitChanges();
        this.Popup.SetMessage("Distributor created successfully", control_ShowMessage.MessageType.Success);
    }

    protected void lnkAdd4_Click(object sender, EventArgs e)
    {
        tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.ddlSDistributor.SelectedValue));
        user.UserType = clsVariables.UserType.SuperDistributor;
        user.ParentId = new int?(Convert.ToInt32(this.ddlParent3.SelectedValue));
        user.SchemeId = new short?(Convert.ToInt16(this.ddlPackages3.SelectedValue));
        this.db.SubmitChanges();
        this.bindParent2();
        this.Popup.SetMessage("Super Distributor created successfully", control_ShowMessage.MessageType.Success);
    }

    protected void lnkAdd5_Click(object sender, EventArgs e)
    {
        try
        {
            if (Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => x.Mobile == this.txtMobile2.Text) == null)
            {
                tblUser entity = new tblUser {
                    ParentId = new int?(Convert.ToInt32(this.Session["aUserId"].ToString())),
                    Mobile = this.txtMobile2.Text,
                    CustName = this.txtName2.Text,
                    Password = clsMethods.GetUniqueKey(10)
                };
                if ((this.txtEmail2.Text != null) && (this.txtEmail2.Text != ""))
                {
                    entity.Email = this.txtEmail2.Text;
                }
                if ((this.txtCompany2.Text != null) && (this.txtCompany2.Text != ""))
                {
                    entity.Company = this.txtCompany2.Text;
                }
                if ((this.txtCity2.Text != null) && (this.txtCity2.Text != ""))
                {
                    entity.City = this.txtCity2.Text;
                }
                if ((this.txtPostalCode2.Text != null) && (this.txtPostalCode2.Text != ""))
                {
                    entity.PostalCode = this.txtPostalCode2.Text;
                }
                if ((this.txtAddress2.Text != null) && (this.txtAddress2.Text != ""))
                {
                    entity.Address = this.txtAddress2.Text;
                }
                entity.AddDate = DateTime.Now;
                entity.UserType = clsVariables.UserType.Reseller;
                entity.RechargeAPI = this.chkRechargeAPI2.Checked;
                entity.Firstime = true;
                entity.Status = true;
                entity.SiteTitle = this.txtTitle.Text;
                entity.Domain = this.txtDomain.Text.Replace("www.", "").Replace("http://", "");
                entity.SchemeId = new short?(Convert.ToInt16(this.ddlPackages4.SelectedValue));
                this.db.tblUsers.InsertOnSubmit(entity);
                this.db.SubmitChanges();
                clsMethods.sendSMS(entity.Mobile, string.Concat(new object[] { "Dear ", entity.CustName, ", your account has been created successfully, your username is ", entity.Id, " and password is ", entity.Password, ". Thanks." }), "26793");
                this.reset();
                this.bindParent1();
                this.Popup.SetMessage("Reseller created successfully", control_ShowMessage.MessageType.Success);
            }
            else
            {
                this.Popup.SetMessage("Mobile No already exist", control_ShowMessage.MessageType.Warning);
            }
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.bindUsers();
            this.bindRetComm();
            this.bindDistComm();
            this.bindSDistComm();
            this.bindParent1();
            this.bindParent2();
            this.bindParent3();
            this.bindUsertype();
        }
    }

    private void reset()
    {
        this.txtName.Text = "";
        this.txtMobile.Text = "";
        this.txtCity.Text = "";
        this.txtEmail.Text = "";
        this.txtPostalCode.Text = "";
        this.txtAddress.Text = "";
        this.txtCompany.Text = "";
    }

    private void reset2()
    {
        this.txtName2.Text = "";
        this.txtMobile2.Text = "";
        this.txtCity2.Text = "";
        this.txtEmail2.Text = "";
        this.txtPostalCode2.Text = "";
        this.txtAddress2.Text = "";
        this.txtCompany2.Text = "";
        this.txtDomain.Text = "";
        this.txtTitle.Text = "";
        this.chkRechargeAPI2.Checked = true;
        this.ddlPackages4.SelectedIndex = 0;
    }

  
}
