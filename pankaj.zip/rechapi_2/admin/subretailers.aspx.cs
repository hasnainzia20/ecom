﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_sd11 : ThemeClass, IRequiresSessionState
{
   
    private DataClassesDataContext db = new DataClassesDataContext();
 

    private void bindData()
    {
        var queryable = from x in this.db.tblUsers
            join z in this.db.tblUsers on x.ParentId equals (int?) z.Id 
            join y in this.db.tblCommPackages on x.SchemeId equals (short?) y.Id 
            where (x.UserType == clsVariables.UserType.Retailer) && (z.UserType == clsVariables.UserType.Distributor)
            orderby x.Username
            select new { 
                Id = x.Id,
                Username = x.Username,
                Name = (x.Username + " [") + x.CustName + "]",
                Parent = (z.Username + " [") + z.CustName + "]",
                Mobile = x.Mobile,
                AddDate = x.AddDate,
                Package = y.PackageName,
                Balance = clsMethods.getBalance(x.Id)
            };
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            queryable = from x in queryable
                where x.Username.Contains(this.txtSearch.Text) || x.Mobile.Contains(this.txtSearch.Text)
                select x;
        }
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnAdd_Click(object sender, EventArgs e)
    {
        if (this.bttnAdd.Text == "Update User")
        {
            tblUser addSeries = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.hfId.Value));
            if (addSeries != null)
            {
                if (Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Username == this.txtUsername.Text) && (x.Id != addSeries.Id)) == null)
                {
                    if (Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Mobile == this.txtMobile.Text) && (x.Id != addSeries.Id)) == null)
                    {
                        addSeries.Username = this.txtUsername.Text;
                        addSeries.Mobile = this.txtMobile.Text;
                        addSeries.ParentId = new int?(Convert.ToInt32(this.ddlParent.SelectedValue));
                        addSeries.SchemeId = new short?(Convert.ToInt16(this.ddlPackage.SelectedValue));
                        if ((this.txtEmail.Text != null) && (this.txtEmail.Text != ""))
                        {
                            addSeries.Email = this.txtEmail.Text;
                        }
                        if ((this.txtCity.Text != null) && (this.txtCity.Text != ""))
                        {
                            addSeries.City = this.txtCity.Text;
                        }
                        if ((this.txtCompany.Text != null) && (this.txtCompany.Text != ""))
                        {
                            addSeries.Company = this.txtCompany.Text;
                        }
                        if ((this.txtPostalCode.Text != null) && (this.txtPostalCode.Text != ""))
                        {
                            addSeries.PostalCode = this.txtPostalCode.Text;
                        }
                        if ((this.txtAddress.Text != null) && (this.txtAddress.Text != ""))
                        {
                            addSeries.Address = this.txtAddress.Text;
                        }
                        this.db.SubmitChanges();
                        this.bindData();
                        this.popup1222.Hide();
                        this.Popup.SetMessage("Retailer updated successfully", control_ShowMessage.MessageType.Success);
                    }
                    else
                    {
                        this.Popup.SetMessage("Mobile already exist", control_ShowMessage.MessageType.Warning);
                    }
                }
                else
                {
                    this.Popup.SetMessage("Username already exist", control_ShowMessage.MessageType.Warning);
                }
            }
        }
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
        var queryable = from x in this.db.tblUsers
            where (((x.UserType == clsVariables.UserType.Administrator) || (x.UserType == clsVariables.UserType.SuperDistributor)) || (x.UserType == clsVariables.UserType.Distributor)) || (x.UserType == clsVariables.UserType.Retailer)
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + x.CustName + "]"
            };
        this.ddlParent.DataSource = queryable;
        this.ddlParent.DataTextField = "Name";
        this.ddlParent.DataValueField = "Id";
        this.ddlParent.DataBind();
        this.ddlParent.Items.Insert(0, " - Select - ");
        var queryable2 = from x in this.db.tblCommPackages
            where x.UserType == clsVariables.UserType.Retailer
            orderby x.PackageName
            select new { 
                Id = x.Id,
                Name = x.PackageName
            };
        this.ddlPackage.DataSource = queryable2;
        this.ddlPackage.DataTextField = "Name";
        this.ddlPackage.DataValueField = "Id";
        this.ddlPackage.DataBind();
        this.ddlPackage.Items.Insert(0, " - Select - ");
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            this.lblTitle.Text = "UPDATE USER";
            this.bttnAdd.Text = "Update User";
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.hfId.Value = user.Id.ToString();
            this.txtUsername.Text = user.Username;
            this.txtName.Text = user.CustName;
            this.txtMobile.Text = user.Mobile;
            this.txtPassword.Text = user.Password;
            this.ddlPackage.SelectedValue = user.SchemeId.ToString();
            this.ddlParent.SelectedValue = user.ParentId.ToString();
            if ((user.Email != null) && (user.Email != ""))
            {
                this.txtEmail.Text = user.Email;
            }
            if ((user.Company != null) && (user.Company != ""))
            {
                this.txtCompany.Text = user.Email;
            }
            if ((user.PostalCode != null) && (user.PostalCode != ""))
            {
                this.txtPostalCode.Text = user.PostalCode;
            }
            if ((user.City != null) && (user.City != ""))
            {
                this.txtCity.Text = user.City;
            }
            if ((user.Address != null) && (user.Address != ""))
            {
                this.txtAddress.Text = user.Address;
            }
            this.popup1222.Show();
        }
        else if (e.CommandName == "lnkDelete")
        {
            tblCommPackage entity = Queryable.Single<tblCommPackage>(this.db.tblCommPackages, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.db.tblCommPackages.DeleteOnSubmit(entity);
            this.db.SubmitChanges();
            this.bindData();
            this.Popup.SetMessage("User deleted successfully", control_ShowMessage.MessageType.Success);
        }
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "20",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button button3 = (Button) e.Row.FindControl("bttnDelete");
            button3.Attributes.Add("onclick", string.Concat(new object[] { "javascript:return confirm('Are you sure you want to delete this record: ", DataBinder.Eval(e.Row.DataItem, "Name"), " - ", DataBinder.Eval(e.Row.DataItem, "Mobile"), "')" }));
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.bindData();
        }
    }

  
}
