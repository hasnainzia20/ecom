﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_setComm : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
  

    private void bindData()
    {
        var queryable = from x in this.db.tblMainComps
            join y in this.db.tblOperators on x.Id equals y.MainCompId 
            join z in this.db.tblServices on x.ServiceId equals z.Id 
            let Name1 = x.OperatorName
            orderby z.Id
            select new { 
                Id = y.Id,
                Operator = ((y.Operator != null) ? (Name1 + " " + y.Operator) : Name1) + ((((z.ServiceName != clsVariables.ServiceType.Mobile) && (z.ServiceName != clsVariables.ServiceType.DTH)) && (z.ServiceName != clsVariables.ServiceType.DataCard)) ? " <span style='color:red'>[Surcharge]</span>" : ""),
                Service = z.ServiceName
            };
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void ddlAPI_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
        this.ddlUsertype.DataSource = clsVariables.UserTypes();
        this.ddlUsertype.DataTextField = "Text";
        this.ddlUsertype.DataValueField = "Value";
        this.ddlUsertype.DataBind();
    }

    protected void ddlPackage_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.bindData();
    }

    protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.bindData();
    }

    protected void ddlUsertype_SelectedIndexChanged(object sender, EventArgs e)
    {
        string domain = base.Request.Headers.Get("Host").ToString().Replace("www.", "").Replace("http://", "");

        tblUser user = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Domain.Replace("www.", "").Replace("http://", "") == domain) && ((x.UserType == clsVariables.UserType.Administrator)));
        
        var queryable = from x in this.db.tblCommPackages
            where x.UserType == this.ddlUsertype.SelectedValue && x.UserId == user.Id
            orderby x.PackageName
            select new { 
                Id = x.Id,
                Name = x.PackageName
            };
        this.ddlPackage.DataSource = queryable;
        this.ddlPackage.DataTextField = "Name";
        this.ddlPackage.DataValueField = "Id";
        this.ddlPackage.DataBind();
        this.ddlPackage.Items.Insert(0, "Select");
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("Add"))
            {
                if (this.ddlPackage.SelectedIndex > 0)
                {
                    GridViewRow namingContainer = (GridViewRow) ((Button) e.CommandSource).NamingContainer;
                    DropDownList list = (DropDownList) namingContainer.FindControl("ddlAPI");
                    if (list.SelectedIndex > 0)
                    {
                        HiddenField hfId = (HiddenField) namingContainer.FindControl("hfId");
                        TextBox box = (TextBox) namingContainer.FindControl("txtPercentage");
                        tblCommission commission = Queryable.SingleOrDefault<tblCommission>(this.db.tblCommissions, x => (x.OperatorId == Convert.ToInt32(hfId.Value)) && (x.PackageId == Convert.ToInt16(this.ddlPackage.SelectedValue)));
                        if (commission != null)
                        {
                            commission.ApiId = new short?(Convert.ToInt16(list.SelectedValue));
                            commission.Percentage = Convert.ToDecimal(box.Text);
                            this.db.SubmitChanges();
                        }
                        else
                        {
                            tblCommission entity = new tblCommission {
                                Percentage = Convert.ToDecimal(box.Text),
                                ApiId = new short?(Convert.ToInt16(list.SelectedValue)),
                                OperatorId = Convert.ToInt16(hfId.Value),
                                PackageId = Convert.ToInt16(this.ddlPackage.SelectedValue),
                                AddDate = clsMethods.getDateTime()
                            };
                            this.db.tblCommissions.InsertOnSubmit(entity);
                            this.db.SubmitChanges();
                        }
                        this.bindData();
                        this.Popup.SetMessage("Commission updated successfully", control_ShowMessage.MessageType.Success);
                    }
                }
            }
            else if (e.CommandName.Equals("Add2"))
            {
                foreach (GridViewRow row2 in this.gvMain.Rows)
                {
                    DropDownList list2 = (DropDownList) row2.FindControl("ddlAPI");
                    if (list2.SelectedIndex > 0)
                    {
                        HiddenField hfId = (HiddenField) row2.FindControl("hfId");
                        TextBox box2 = (TextBox) row2.FindControl("txtPercentage");
                        tblCommission commission3 = Queryable.SingleOrDefault<tblCommission>(this.db.tblCommissions, x => (x.OperatorId == Convert.ToInt32(hfId.Value)) && (x.PackageId == Convert.ToInt16(this.ddlPackage.SelectedValue)));
                        if (commission3 != null)
                        {
                            commission3.Percentage = Convert.ToDecimal(box2.Text);
                            this.db.SubmitChanges();
                        }
                        else
                        {
                            tblCommission commission4 = new tblCommission {
                                Percentage = Convert.ToDecimal(box2.Text),
                                ApiId = new short?(Convert.ToInt16(list2.SelectedValue)),
                                OperatorId = Convert.ToInt16(hfId.Value),
                                PackageId = Convert.ToInt16(this.ddlPackage.SelectedValue),
                                AddDate = clsMethods.getDateTime()
                            };
                            this.db.tblCommissions.InsertOnSubmit(commission4);
                            this.db.SubmitChanges();
                        }
                    }
                }
                this.bindData();
                this.Popup.SetMessage("Commission updated successfully", control_ShowMessage.MessageType.Success);
            }
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            TextBox box = e.Row.FindControl("txtPercentage") as TextBox;
            Label label = e.Row.FindControl("lblSuffix") as Label;
            DropDownList list = e.Row.FindControl("ddlAPI") as DropDownList;
            Label label2 = e.Row.FindControl("lblPrefix") as Label;
            Label label3 = e.Row.FindControl("lblS") as Label;
            HiddenField field = e.Row.FindControl("hfService") as HiddenField;
            HiddenField hfId = e.Row.FindControl("hfId") as HiddenField;
            var queryable = from x in this.db.tblApis
                orderby x.APIName
                select new { 
                    Id = x.Id,
                    Code = x.APICode
                };
            list.DataSource = queryable;
            list.DataTextField = "Code";
            list.DataValueField = "Id";
            list.DataBind();
            list.Items.Insert(0, "Select");
            if (((field.Value != clsVariables.ServiceType.Mobile) && (field.Value != clsVariables.ServiceType.DTH)) && (field.Value != clsVariables.ServiceType.DataCard))
            {
                label2.Text = "Rs.";
                label.Text = "/-";
                label3.Text = " [Surcharge]";
            }
            else
            {
                label.Text = "%";
            }
            if (this.ddlPackage.SelectedIndex > 0)
            {
                tblCommission commission = Queryable.SingleOrDefault<tblCommission>(this.db.tblCommissions, x => (x.OperatorId == Convert.ToInt32(hfId.Value)) && (x.PackageId == Convert.ToInt16(this.ddlPackage.SelectedValue)));
                if (commission != null)
                {
                    box.Text = Convert.ToString(commission.Percentage);
                    short? apiId = commission.ApiId;
                    int? nullable3 = apiId.HasValue ? new int?(apiId.GetValueOrDefault()) : null;
                    if (nullable3.HasValue)
                    {
                        list.SelectedValue = Convert.ToString(commission.ApiId);
                    }
                }
                else if (((field.Value != clsVariables.ServiceType.Mobile) && (field.Value != clsVariables.ServiceType.DTH)) && (field.Value != clsVariables.ServiceType.DataCard))
                {
                    box.Text = "0";
                }
                else
                {
                    box.Text = "0.00";
                }
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.bindData();
            this.ddlUsertype.SelectedIndex = 1;
            this.ddlUsertype_SelectedIndexChanged(sender, e);
            this.ddlPackage.SelectedIndex = 1;
            this.ddlPackage_SelectedIndexChanged(sender, e);
        }
    }

  
}
