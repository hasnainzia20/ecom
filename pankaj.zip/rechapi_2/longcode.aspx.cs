﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;

public class longcode : Page, IRequiresSessionState
{
    protected HtmlForm form1;

    private void addLongCode(string msg, string response, int userId, int resellerId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblMessageTrack entity = new tblMessageTrack {
            AddDate = DateTime.Now,
            Message = msg,
            ResellerId = new int?(resellerId),
            Response = response,
            Type = clsVariables.MessageType.Longcode
        };
        if (userId != -1)
        {
            entity.UserId = new int?(userId);
        }
        context.tblMessageTracks.InsertOnSubmit(entity);
        context.SubmitChanges();
        tblUser user = Queryable.SingleOrDefault<tblUser>(context.tblUsers, x => x.Id == resellerId);
        if (user != null)
        {
            user.SMS -= 1;
            context.SubmitChanges();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        try
        {
            ParameterExpression expression;
            string mobileno = null;
            string message = null;
            mobileno = base.Request["mobile_number"];
            message = base.Request["message"];
            if ((mobileno == null) && (message == null))
            {
                mobileno = base.Request["Mob"];
                message = base.Request["message"];
            }
            tblTest entity = new tblTest {
                Message = message + " " + mobileno,
                AddDate = DateTime.Now
            };
            context.tblTests.InsertOnSubmit(entity);
            context.SubmitChanges();
            message = message.Trim();
            mobileno = mobileno.Trim();
            mobileno = mobileno.Replace("+91", "");
            if (mobileno.StartsWith("91") && (mobileno.Length == 12))
            {
                mobileno = mobileno.Substring(2, 10);
            }
            tblUser user = Queryable.FirstOrDefault<tblUser>(context.tblUsers, System.Linq.Expressions.Expression.Lambda<Func<tblUser, bool>>(System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression = System.Linq.Expressions.Expression.Parameter(typeof(tblUser), "x"), (MethodInfo) methodof(tblUser.get_Keyword)), System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Call(System.Linq.Expressions.Expression.Constant(message), (MethodInfo) methodof(string.Split), new System.Linq.Expressions.Expression[] { System.Linq.Expressions.Expression.NewArrayInit(typeof(char), new System.Linq.Expressions.Expression[] { System.Linq.Expressions.Expression.Constant(' ', typeof(char)) }) }), System.Linq.Expressions.Expression.Constant(0, typeof(int))), false, (MethodInfo) methodof(string.op_Equality)), new ParameterExpression[] { expression }));
            if (user != null)
            {
                tblUser UserId = Queryable.SingleOrDefault<tblUser>(context.tblUsers, p => (p.Mobile == mobileno) && p.Status);
                int id = user.Id;
                if (UserId == null)
                {
                    base.Response.Write("User doesn't exist");
                    this.addLongCode(message, "User doesn't exist", -1, id);
                }
                else
                {
                    object obj2;
                    string[] messages = message.Split(new char[] { ' ' });
                    if (messages.Count<string>() == 2)
                    {
                        if (messages[1] == "BAL")
                        {
                            string str = "Dear " + UserId.CustName + ",Your Current Account Balance Is Rs." + clsMethods.getBalance(UserId.Id).ToString() + ".Thanks.";
                            base.Response.Write(clsMethods.sendSMS(mobileno, str, "26804"));
                            base.Response.Write("<br/>");
                            base.Response.Write(str);
                            this.addLongCode(message, str, UserId.Id, id);
                        }
                        else if (messages[1] == "LST")
                        {
                            var source = (from x in context.tblRecharges
                                join y in context.tblOperators on x.OperatorId equals (short?) y.Id into y
                                join z in context.tblMainComps on y.MainCompId equals (short?) z.Id into z
                                where x.UserId == UserId.Id
                                let Name1 = z.OperatorName
                                orderby x.RechargeDate descending
                                select new { 
                                    Id = x.Id,
                                    CompanyName = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                                    Amount = x.Amount,
                                    Date = x.RechargeDate,
                                    Status = x.Status,
                                    Number = x.Number,
                                    RechargeId = x.Id
                                }).Skip(0).Take(3);
                            if (source.Count() > 0)
                            {
                                string str2 = "Last 3 Transaction.";
                                int num2 = 1;
                                foreach (var type in source)
                                {
                                    obj2 = str2;
                                    str2 = string.Concat(new object[] { obj2, num2, ") ", type.Id.ToString(), " : ", type.Number, " : ", type.Amount, " : ", type.Status, " : ", type.CompanyName, " " });
                                    num2++;
                                }
                                str2 = str2 + ". Thanks.";
                                base.Response.Write(clsMethods.sendSMS(mobileno, str2, "26803"));
                                base.Response.Write("<br/>");
                                base.Response.Write(str2);
                                this.addLongCode(message, str2, UserId.Id, id);
                            }
                        }
                    }
                    else if (messages.Count<string>() == 3)
                    {
                        if (messages[1].ToUpper() == "RD")
                        {
                            if (Queryable.SingleOrDefault<tblRecharge>(context.tblRecharges, System.Linq.Expressions.Expression.Lambda<Func<tblRecharge, bool>>(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression = System.Linq.Expressions.Expression.Parameter(typeof(tblRecharge), "y"), (MethodInfo) methodof(tblRecharge.get_Id)), System.Linq.Expressions.Expression.Call(null, (MethodInfo) methodof(Convert.ToInt64), new System.Linq.Expressions.Expression[] { System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(2, typeof(int))) })), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblRecharge.get_UserId)), System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Constant(UserId), (MethodInfo) methodof(tblUser.get_Id)))), new ParameterExpression[] { expression })) != null)
                            {
                                bool flag = false;
                                if ((from <>h__TransparentIdentifier5 in Queryable.Where(from x in context.tblTickets
                                    join y in context.tblTicketDetails on x.Id equals y.TicketId
                                    select new { 
                                        x = x,
                                        y = y
                                    }, System.Linq.Expressions.Expression.Lambda(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Property(expression = System.Linq.Expressions.Expression.Parameter(typeof(<>f__AnonymousType0<tblTicket, tblTicketDetail>), "<>h__TransparentIdentifier5"), (MethodInfo) methodof(<>f__AnonymousType0<tblTicket, tblTicketDetail>.get_y, <>f__AnonymousType0<tblTicket, tblTicketDetail>)), (MethodInfo) methodof(tblTicketDetail.get_TranId)), System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(2, typeof(int))), false, (MethodInfo) methodof(string.op_Equality)), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(<>f__AnonymousType0<tblTicket, tblTicketDetail>.get_x, <>f__AnonymousType0<tblTicket, tblTicketDetail>)), (MethodInfo) methodof(tblTicket.get_Status)), System.Linq.Expressions.Expression.Property(null, (MethodInfo) methodof(clsVariables.TicketStatus.get_InProcess)), false, (MethodInfo) methodof(string.op_Equality))), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(<>f__AnonymousType0<tblTicket, tblTicketDetail>.get_x, <>f__AnonymousType0<tblTicket, tblTicketDetail>)), (MethodInfo) methodof(tblTicket.get_SupportType)), System.Linq.Expressions.Expression.Property(null, (MethodInfo) methodof(clsVariables.TicketType.get_RechargeDispute)), false, (MethodInfo) methodof(string.op_Equality))), new ParameterExpression[] { expression }))
                                    orderby <>h__TransparentIdentifier5.y.ResponseDate descending
                                    select <>h__TransparentIdentifier5.x).FirstOrDefault<tblTicket>() == null)
                                {
                                    flag = true;
                                }
                                if (flag)
                                {
                                    tblTicket ticket2 = new tblTicket {
                                        SupportType = clsVariables.TicketType.RechargeDispute,
                                        Status = clsVariables.TicketStatus.InProcess,
                                        AddDate = DateTime.Now,
                                        UserId = UserId.Id,
                                        ResellerId = new int?(id)
                                    };
                                    context.tblTickets.InsertOnSubmit(ticket2);
                                    context.SubmitChanges();
                                    tblTicketDetail detail = new tblTicketDetail {
                                        TicketId = ticket2.Id,
                                        Response = "Please chek the recharge id: " + messages[1],
                                        TranId = messages[2],
                                        ResponseDate = DateTime.Now,
                                        UserId = UserId.Id
                                    };
                                    context.tblTicketDetails.InsertOnSubmit(detail);
                                    context.SubmitChanges();
                                    string str3 = "Dear " + UserId.CustName + ", We Have Received Your Complain For Recharge Your Complain Id Is " + detail.Id.ToString() + ".Thanks.";
                                    base.Response.Write(clsMethods.sendSMS(mobileno, str3, "26802"));
                                    base.Response.Write("<br/>");
                                    base.Response.Write(str3);
                                    this.addLongCode(message, str3, UserId.Id, id);
                                }
                                else
                                {
                                    base.Response.Write("You already placed ticket for the same Ref. Id");
                                    this.addLongCode(message, "You already placed ticket for the same Ref. Id", UserId.Id, id);
                                    clsMethods.sendSMS(mobileno, "You already placed ticket for the same Ref. Id", "15977");
                                }
                            }
                            else
                            {
                                string str4 = "Sorry!, Ref. Id not found. Thanks.";
                                base.Response.Write(clsMethods.sendSMS(mobileno, str4, "26799"));
                                base.Response.Write("<br/>");
                                base.Response.Write(str4);
                                this.addLongCode(message, str4, UserId.Id, id);
                            }
                        }
                        else if (messages[0].ToUpper() == "CD")
                        {
                            tblTicketDetail getDispute = (from x in Queryable.Where<tblTicketDetail>(context.tblTicketDetails, System.Linq.Expressions.Expression.Lambda<Func<tblTicketDetail, bool>>(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression = System.Linq.Expressions.Expression.Parameter(typeof(tblTicketDetail), "x"), (MethodInfo) methodof(tblTicketDetail.get_TranId)), System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(2, typeof(int))), false, (MethodInfo) methodof(string.op_Equality)), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblTicketDetail.get_UserId)), System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Constant(UserId), (MethodInfo) methodof(tblUser.get_Id)))), new ParameterExpression[] { expression }))
                                orderby x.ResponseDate descending
                                select x).FirstOrDefault<tblTicketDetail>();
                            if (getDispute != null)
                            {
                                tblTicket ticket3 = Queryable.Single<tblTicket>(context.tblTickets, x => x.Id == getDispute.TicketId);
                                string str5 = string.Concat(new object[] { "Status: ", ticket3.Status, ", Message: ", getDispute.Response, ", Solved date: ", getDispute.ResponseDate, ". Thanks." });
                                base.Response.Write(clsMethods.sendSMS(mobileno, str5, "26801"));
                                base.Response.Write("<br/>");
                                base.Response.Write(str5);
                                this.addLongCode(message, str5, UserId.Id, id);
                            }
                            else
                            {
                                string str6 = "Sorry!, Ref. Id not found. Thanks.";
                                base.Response.Write(clsMethods.sendSMS(mobileno, str6, "26799"));
                                base.Response.Write("<br/>");
                                base.Response.Write(str6);
                                this.addLongCode(message, str6, UserId.Id, id);
                            }
                        }
                        else if (messages[1].ToUpper() == "SN")
                        {
                            var queryable2 = (from <>h__TransparentIdentifier7 in Queryable.Where(from x in context.tblRecharges
                                join y in context.tblOperators on x.OperatorId equals (short?) y.Id into y
                                join z in context.tblMainComps on y.MainCompId equals (short?) z.Id
                                select new { 
                                    <>h__TransparentIdentifier6 = <>h__TransparentIdentifier6,
                                    z = z
                                }, System.Linq.Expressions.Expression.Lambda(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Property(expression = System.Linq.Expressions.Expression.Parameter(typeof(<>f__AnonymousType6<<>f__AnonymousType0<tblRecharge, tblOperator>, tblMainComp>), "<>h__TransparentIdentifier7"), (MethodInfo) methodof(<>f__AnonymousType6<<>f__AnonymousType0<tblRecharge, tblOperator>, tblMainComp>.get_<>h__TransparentIdentifier6, <>f__AnonymousType6<<>f__AnonymousType0<tblRecharge, tblOperator>, tblMainComp>)), (MethodInfo) methodof(<>f__AnonymousType0<tblRecharge, tblOperator>.get_x, <>f__AnonymousType0<tblRecharge, tblOperator>)), (MethodInfo) methodof(tblRecharge.get_UserId)), System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Constant(UserId), (MethodInfo) methodof(tblUser.get_Id))), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(<>f__AnonymousType6<<>f__AnonymousType0<tblRecharge, tblOperator>, tblMainComp>.get_<>h__TransparentIdentifier6, <>f__AnonymousType6<<>f__AnonymousType0<tblRecharge, tblOperator>, tblMainComp>)), (MethodInfo) methodof(<>f__AnonymousType0<tblRecharge, tblOperator>.get_x, <>f__AnonymousType0<tblRecharge, tblOperator>)), (MethodInfo) methodof(tblRecharge.get_Number)), System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(2, typeof(int))), false, (MethodInfo) methodof(string.op_Equality))), new ParameterExpression[] { expression }))
                                let Name1 = <>h__TransparentIdentifier7.z.OperatorName
                                orderby <>h__TransparentIdentifier7.<>h__TransparentIdentifier6.x.RechargeDate descending
                                select new { 
                                    Id = <>h__TransparentIdentifier7.<>h__TransparentIdentifier6.x.Id,
                                    CompanyName = (<>h__TransparentIdentifier7.<>h__TransparentIdentifier6.y.Operator != null) ? (Name1 + " " + <>h__TransparentIdentifier7.<>h__TransparentIdentifier6.y.Operator) : Name1,
                                    Amount = <>h__TransparentIdentifier7.<>h__TransparentIdentifier6.x.Amount,
                                    Date = <>h__TransparentIdentifier7.<>h__TransparentIdentifier6.x.RechargeDate,
                                    Status = <>h__TransparentIdentifier7.<>h__TransparentIdentifier6.x.Status,
                                    Number = <>h__TransparentIdentifier7.<>h__TransparentIdentifier6.x.Number,
                                    RechargeId = <>h__TransparentIdentifier7.<>h__TransparentIdentifier6.x.Id
                                }).Skip(0).Take(3);
                            if (queryable2.Count() > 0)
                            {
                                string str7 = "Transaction Detail For Mobile/Id:" + messages[2] + "  is ";
                                int num3 = 1;
                                foreach (var type2 in queryable2)
                                {
                                    obj2 = str7;
                                    str7 = string.Concat(new object[] { obj2, num3, ") ", type2.Id.ToString(), " : ", type2.Number, " : ", type2.Amount, " : ", type2.Status, " : ", type2.CompanyName, ", " });
                                    num3++;
                                }
                                str7 = str7 + ". Thanks.";
                                base.Response.Write(clsMethods.sendSMS(mobileno, str7, "26797"));
                                base.Response.Write("<br/>");
                                base.Response.Write(str7);
                                this.addLongCode(message, str7, UserId.Id, id);
                            }
                        }
                        else
                        {
                            tblMobileSery getSeries = Queryable.SingleOrDefault<tblMobileSery>(context.tblMobileSeries, System.Linq.Expressions.Expression.Lambda<Func<tblMobileSery, bool>>(System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression = System.Linq.Expressions.Expression.Parameter(typeof(tblMobileSery), "x"), (MethodInfo) methodof(tblMobileSery.get_SeriesNo)), System.Linq.Expressions.Expression.Call(System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(1, typeof(int))), (MethodInfo) methodof(string.Substring), new System.Linq.Expressions.Expression[] { System.Linq.Expressions.Expression.Constant(0, typeof(int)), System.Linq.Expressions.Expression.Constant(4, typeof(int)) }), false, (MethodInfo) methodof(string.op_Equality)), new ParameterExpression[] { expression }));
                            tblMainComp getComp2 = null;
                            tblService service = null;
                            tblOperator getComp = null;
                            tblState state = null;
                            if (getSeries != null)
                            {
                                getComp2 = Queryable.SingleOrDefault<tblMainComp>(context.tblMainComps, x => x.Id == getSeries.OperatorId);
                                getComp = Queryable.First<tblOperator>(context.tblOperators, x => x.MainCompId == getComp2.Id);
                                state = Queryable.SingleOrDefault<tblState>(context.tblStates, x => x.Id == getSeries.StateId);
                                if ((getComp2 != null) && (state != null))
                                {
                                    service = Queryable.Single<tblService>(context.tblServices, x => x.Id == getComp2.ServiceId);
                                }
                            }
                            if (((getComp2 != null) && (state != null)) && (service != null))
                            {
                                if ((getComp2 != null) && getComp2.Down)
                                {
                                    base.Response.Write("Currently we have trouble for the selected operator, pls try later");
                                    clsMethods.sendSMS(UserId.Mobile, "Currently we have trouble for the selected operator, pls try later", "");
                                    this.addLongCode(message, "Currently we have trouble for the selected operator, pls try later", UserId.Id, id);
                                }
                                else
                                {
                                    tblRecharge recharge2 = Queryable.FirstOrDefault<tblRecharge>(from x in context.tblRecharges
                                        orderby x.RechargeDate descending
                                        select x, System.Linq.Expressions.Expression.Lambda<Func<tblRecharge, bool>>(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.OrElse(System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression = System.Linq.Expressions.Expression.Parameter(typeof(tblRecharge), "x"), (MethodInfo) methodof(tblRecharge.get_Status)), System.Linq.Expressions.Expression.Property(null, (MethodInfo) methodof(clsVariables.RechargeStatus.get_Success)), false, (MethodInfo) methodof(string.op_Equality)), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblRecharge.get_Status)), System.Linq.Expressions.Expression.Property(null, (MethodInfo) methodof(clsVariables.RechargeStatus.get_Pending)), false, (MethodInfo) methodof(string.op_Equality))), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblRecharge.get_UserId)), System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Constant(UserId), (MethodInfo) methodof(tblUser.get_Id)))), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblRecharge.get_Amount)), System.Linq.Expressions.Expression.Call(null, (MethodInfo) methodof(Convert.ToDecimal), new System.Linq.Expressions.Expression[] { System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(2, typeof(int))) }))), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblRecharge.get_Number)), System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(1, typeof(int))), false, (MethodInfo) methodof(string.op_Equality))), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Convert(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblRecharge.get_OperatorId)), typeof(int?)), System.Linq.Expressions.Expression.Convert(System.Linq.Expressions.Expression.Convert(System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Constant(getComp), (MethodInfo) methodof(tblOperator.get_Id)), typeof(int)), typeof(int?)))), new ParameterExpression[] { expression }));
                                    if ((recharge2 != null) && (recharge2.RechargeDate.AddMinutes(5.0) > DateTime.Now))
                                    {
                                        base.Response.Write("Your next recharge will be after 5 minutes on same number with same amount");
                                        this.addLongCode(message, "Your next recharge will be after 5 minutes on same number with same amount", UserId.Id, id);
                                    }
                                    else
                                    {
                                        string str8 = clsMethods.doRecharge2(messages[1], messages[2], getComp.LongCode, "12", UserId.Id, service.ServiceName, clsVariables.RechargeMode.SMS);
                                        if (str8.Contains("SUCCESS") || str8.Contains("FAILURE"))
                                        {
                                            base.Response.Write(clsMethods.sendSMS(UserId.Mobile, str8, "26851"));
                                            base.Response.Write("<br/>");
                                        }
                                        base.Response.Write(str8);
                                        this.addLongCode(message, str8, UserId.Id, id);
                                    }
                                }
                            }
                        }
                    }
                    else if (messages.Count<string>() == 4)
                    {
                        if (messages[1].ToUpper() == "CHP")
                        {
                            if (UserId.Password == messages[1])
                            {
                                UserId.Password = messages[1];
                                context.SubmitChanges();
                                string str9 = "Dear " + UserId.CustName + ", Your Password Has Been Reset Successfully.New Password Is " + UserId.Password + ". Thanks.";
                                base.Response.Write(clsMethods.sendSMS(mobileno, str9, "26795"));
                                base.Response.Write("<br/>");
                                base.Response.Write(str9);
                                this.addLongCode(message, str9, UserId.Id, id);
                            }
                            else
                            {
                                string str10 = "Dear " + UserId.CustName + ", Your Old Password Is Incorrect.Try Again With Correct Password. Thanks.";
                                base.Response.Write(clsMethods.sendSMS(mobileno, str10, "26796"));
                                base.Response.Write("<br/>");
                                base.Response.Write(str10);
                                this.addLongCode(message, str10, UserId.Id, id);
                            }
                        }
                        else
                        {
                            tblOperator getComp = Queryable.SingleOrDefault<tblOperator>(context.tblOperators, System.Linq.Expressions.Expression.Lambda<Func<tblOperator, bool>>(System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression = System.Linq.Expressions.Expression.Parameter(typeof(tblOperator), "x"), (MethodInfo) methodof(tblOperator.get_LongCode)), System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(3, typeof(int))), false, (MethodInfo) methodof(string.op_Equality)), new ParameterExpression[] { expression }));
                            if (getComp != null)
                            {
                                tblMainComp getComp2 = Queryable.SingleOrDefault<tblMainComp>(context.tblMainComps, x => x.Id == getComp.MainCompId);
                                tblService service2 = Queryable.Single<tblService>(context.tblServices, x => x.Id == getComp2.ServiceId);
                                tblState state2 = null;
                                if ((getComp2 != null) && getComp2.Down)
                                {
                                    base.Response.Write("Currently we have trouble for the selected operator, pls try later");
                                    clsMethods.sendSMS(UserId.Mobile, "Currently we have trouble for the selected operator, pls try later", "");
                                    this.addLongCode(message, "Currently we have trouble for the selected operator, pls try later", UserId.Id, id);
                                }
                                else
                                {
                                    if (service2.ServiceName != clsVariables.ServiceType.DTH)
                                    {
                                        if (context.tblStates.First<tblState>() == null)
                                        {
                                            string str11 = "Invalid Circle Code.\nPlease check the SMS Format Document.\nwww.M-Online.in";
                                            clsMethods.sendSMS(mobileno, str11, "");
                                            base.Response.Write("Invalid Circle Code");
                                            this.addLongCode(message, str11, UserId.Id, id);
                                        }
                                    }
                                    else
                                    {
                                        state2 = context.tblStates.First<tblState>();
                                    }
                                    tblRecharge recharge3 = Queryable.FirstOrDefault<tblRecharge>(from x in context.tblRecharges
                                        orderby x.RechargeDate descending
                                        select x, System.Linq.Expressions.Expression.Lambda<Func<tblRecharge, bool>>(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.AndAlso(System.Linq.Expressions.Expression.OrElse(System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression = System.Linq.Expressions.Expression.Parameter(typeof(tblRecharge), "x"), (MethodInfo) methodof(tblRecharge.get_Status)), System.Linq.Expressions.Expression.Property(null, (MethodInfo) methodof(clsVariables.RechargeStatus.get_Success)), false, (MethodInfo) methodof(string.op_Equality)), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblRecharge.get_Status)), System.Linq.Expressions.Expression.Property(null, (MethodInfo) methodof(clsVariables.RechargeStatus.get_Pending)), false, (MethodInfo) methodof(string.op_Equality))), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblRecharge.get_UserId)), System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Constant(UserId), (MethodInfo) methodof(tblUser.get_Id)))), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblRecharge.get_Amount)), System.Linq.Expressions.Expression.Call(null, (MethodInfo) methodof(Convert.ToDecimal), new System.Linq.Expressions.Expression[] { System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(2, typeof(int))) }))), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblRecharge.get_Number)), System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(1, typeof(int))), false, (MethodInfo) methodof(string.op_Equality))), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Convert(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblRecharge.get_OperatorId)), typeof(int?)), System.Linq.Expressions.Expression.Convert(System.Linq.Expressions.Expression.Convert(System.Linq.Expressions.Expression.Property(System.Linq.Expressions.Expression.Constant(getComp), (MethodInfo) methodof(tblOperator.get_Id)), typeof(int)), typeof(int?)))), new ParameterExpression[] { expression }));
                                    if ((recharge3 != null) && (recharge3.RechargeDate.AddMinutes(5.0) > DateTime.Now))
                                    {
                                        base.Response.Write("Your next recharge will be after 5 minutes on same number with same amount");
                                        this.addLongCode(message, "Your next recharge will be after 5 minutes on same number with same amount", UserId.Id, id);
                                    }
                                    else
                                    {
                                        string str12 = clsMethods.doRecharge2(messages[1], messages[2], getComp.LongCode, "12", UserId.Id, service2.ServiceName, clsVariables.RechargeMode.SMS);
                                        if (str12.Contains("SUCCESS") || str12.Contains("FAILURE"))
                                        {
                                            base.Response.Write(clsMethods.sendSMS(UserId.Mobile, str12, "26851"));
                                            base.Response.Write("<br/>");
                                        }
                                        base.Response.Write(str12);
                                        this.addLongCode(message, str12, UserId.Id, id);
                                    }
                                }
                            }
                        }
                    }
                    else if (((((messages.Count<string>() == 5) && (messages[1].ToUpper() == "TNSF")) && ((messages[3].ToUpper() == "C") || (messages[3].ToUpper() == "D"))) && (((UserId.UserType == clsVariables.UserType.Administrator) || (UserId.UserType == clsVariables.UserType.SuperDistributor)) || (UserId.UserType == clsVariables.UserType.Distributor))) && (Convert.ToDecimal(messages[2]) > 0M))
                    {
                        tblUser user2 = Queryable.SingleOrDefault<tblUser>(context.tblUsers, System.Linq.Expressions.Expression.Lambda<Func<tblUser, bool>>(System.Linq.Expressions.Expression.OrElse(System.Linq.Expressions.Expression.OrElse(System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression = System.Linq.Expressions.Expression.Parameter(typeof(tblUser), "x"), (MethodInfo) methodof(tblUser.get_Username)), System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(4, typeof(int))), false, (MethodInfo) methodof(string.op_Equality)), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Call(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblUser.get_Id)), (MethodInfo) methodof(int.ToString), new System.Linq.Expressions.Expression[0]), System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(4, typeof(int))), false, (MethodInfo) methodof(string.op_Equality))), System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Property(expression, (MethodInfo) methodof(tblUser.get_Mobile)), System.Linq.Expressions.Expression.ArrayIndex(System.Linq.Expressions.Expression.Constant(messages), System.Linq.Expressions.Expression.Constant(4, typeof(int))), false, (MethodInfo) methodof(string.op_Equality))), new ParameterExpression[] { expression }));
                        if (user2 != null)
                        {
                            decimal num4 = clsMethods.getBalance(Convert.ToInt32(UserId.Id));
                            if ((num4 < Convert.ToDecimal(messages[2])) && (messages[3].ToUpper() == "C"))
                            {
                                string str13 = "You are not able to Debit Because Debit Amount Exceed the Available Balance.Thanks," + clsMethods.getBalance(Convert.ToInt32(UserId.Id)).ToString("0,0.00");
                                clsMethods.sendSMS(UserId.Mobile, str13, "");
                                base.Response.Write("Balance is not sufficient");
                                this.addLongCode(message, str13, UserId.Id, id);
                            }
                            else
                            {
                                decimal num5 = clsMethods.getBalance(Convert.ToInt32(user2.Id));
                                if ((num5 < Convert.ToDecimal(messages[2])) && (messages[3].ToUpper() == "D"))
                                {
                                    string str14 = "You are not able to Debit Because Debit Amount Exceed the Available Balance.Thanks," + clsMethods.getBalance(UserId.Id).ToString("0,0.00");
                                    clsMethods.sendSMS(UserId.Mobile, str14, "");
                                    base.Response.Write("You can't debit amount exceed the available balance");
                                    this.addLongCode(message, str14, UserId.Id, id);
                                }
                                else if (messages[3].ToUpper() == "C")
                                {
                                    tblUser user3 = Queryable.Single<tblUser>(context.tblUsers, x => x.UserType == clsVariables.UserType.Administrator);
                                    int num6 = clsMethods.addTrans(UserId.Id, Convert.ToDecimal(messages[2]), "", user2.Id, user2.Id, clsMethods.getBalance(user2.Id) + Convert.ToDecimal(messages[2]), clsVariables.TransactionType.Credit, 0L, clsMethods.getBalance(user3.Id), clsMethods.getBalance(id), id, -1M);
                                    clsMethods.addTrans(UserId.Id, Convert.ToDecimal(messages[2]), "", user2.Id, UserId.Id, clsMethods.getBalance(UserId.Id) - Convert.ToDecimal(messages[2]), clsVariables.TransactionType.Debit, (long) num6, clsMethods.getBalance(user3.Id), clsMethods.getBalance(id), id, -1M);
                                    string str15 = "Dear " + user2.CustName + ",Your Account Has Been Credited with amount." + messages[2].ToString() + " and Your Old Bal. is Rs. " + num5.ToString() + " and New Bal. is Rs. " + clsMethods.getBalance(Convert.ToInt32(user2.Id)).ToString("0,0.00") + ". Thanks.";
                                    string str16 = "Dear " + UserId.CustName + ",Your Account Has Been Debited with amount." + messages[2].ToString() + " and Your Old Bal. is Rs. " + num4.ToString() + " and New Bal. is Rs. " + clsMethods.getBalance(Convert.ToInt32(UserId.Id)).ToString("0,0.00") + ". Thanks.";
                                    base.Response.Write(clsMethods.sendSMS(user2.Mobile, str15, "26794"));
                                    base.Response.Write(clsMethods.sendSMS(UserId.Mobile, str16, "26794"));
                                    base.Response.Write("<br/>");
                                    base.Response.Write(str15);
                                    base.Response.Write("<br/>");
                                    base.Response.Write(str16);
                                    this.addLongCode(message, str15, user2.Id, id);
                                    this.addLongCode(message, str16, UserId.Id, id);
                                }
                                else if (messages[3].ToUpper() == "D")
                                {
                                    tblUser user4 = Queryable.Single<tblUser>(context.tblUsers, x => x.UserType == clsVariables.UserType.Administrator);
                                    int num7 = clsMethods.addTrans(user2.Id, Convert.ToDecimal(messages[2]), "", UserId.Id, user2.Id, clsMethods.getBalance(user2.Id) - Convert.ToDecimal(messages[2]), clsVariables.TransactionType.Debit, 0L, clsMethods.getBalance(user4.Id), clsMethods.getBalance(id), id, -1M);
                                    clsMethods.addTrans(user2.Id, Convert.ToDecimal(messages[2]), "", UserId.Id, UserId.Id, clsMethods.getBalance(UserId.Id) + Convert.ToDecimal(messages[2]), clsVariables.TransactionType.Credit, (long) num7, clsMethods.getBalance(user4.Id), clsMethods.getBalance(id), id, -1M);
                                    string str17 = "Dear " + user2.CustName + ",Your Account Has Been Debited with amount." + messages[2].ToString() + " and Your Old Bal. is " + num5.ToString() + " and New Bal. is Rs. " + clsMethods.getBalance(Convert.ToInt32(user2.Id)).ToString("0,0.00") + ". Thanks. www.BhavaniMobile.in";
                                    string str18 = "Dear " + UserId.CustName + ",Your Account Has Been Credited with amount." + messages[2].ToString() + " and Your Old Bal. is " + num5.ToString() + " and New Bal. is Rs. " + clsMethods.getBalance(Convert.ToInt32(UserId.Id)).ToString("0,0.00") + ". Thanks. www.BhavaniMobile.in";
                                    base.Response.Write(clsMethods.sendSMS(user2.Mobile, str17, "26794"));
                                    base.Response.Write(clsMethods.sendSMS(UserId.Mobile, str18, "26794"));
                                    base.Response.Write("<br/>");
                                    base.Response.Write(str17);
                                    base.Response.Write("<br/>");
                                    base.Response.Write(str18);
                                    this.addLongCode(message, str17, user2.Id, id);
                                    this.addLongCode(message, str18, UserId.Id, id);
                                }
                            }
                        }
                        else
                        {
                            base.Response.Write(messages[3] + " not registered");
                        }
                    }
                }
            }
            else
            {
                this.addLongCode(message, "Keyword not found: " + message.Split(new char[] { ' ' })[0], 0, 0);
            }
        }
        catch (Exception exception)
        {
            base.Response.Write(exception.Message);
        }
    }

}
