using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.Drawing;
using System.Configuration;
using System.Data.SqlClient;

public partial class ForgotPasswordCS : System.Web.UI.Page
{
    protected void SendRequest(object sender, EventArgs e)
    {
        string username = string.Empty;
        string password = string.Empty;
        string mobile = string.Empty;
        string custname = string.Empty;
        string constr = ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT Username, [Password], [Mobile], [CustName] FROM tblUsers WHERE Id = @Id"))
            {
                cmd.Parameters.AddWithValue("@Id", txtuserid.Text.Trim());
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    if (sdr.Read())
                    {
                        username = sdr["Username"].ToString();
                        password = sdr["Password"].ToString();
                        mobile = sdr["Mobile"].ToString();
                        custname = sdr["CustName"].ToString();
                    }
                }
                con.Close();
            }
        }
        if (!string.IsNullOrEmpty(password))
        {

           string smsmessage2 = "Dear " + custname + ", Your Password Is Here: " + password + " Thanks.";

            lblMessage.ForeColor = Color.Green;
            lblMessage.Text = "Hi " + username + ".  Your Password Has Been Sent To Your Registered Mobile Number..!";
            clsMethods.sendSMS(mobile, smsmessage2, "");
        }

        else
        {
            
            lblMessage.ForeColor = Color.Red;
            lblMessage.Text = "This User Id Is Not Found.";
        }
    }
}