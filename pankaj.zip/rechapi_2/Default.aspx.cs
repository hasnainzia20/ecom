﻿using System.IO;
using System;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Data.SqlClient;
using System.Xml;
using System.Collections;
using System.Text.RegularExpressions;
using System.Net;
using System.Collections.Generic;
using System.Web.Services;
using System.Linq;
using System.Web.Script.Serialization;
using System.Web.SessionState;
using System.Security.Cryptography;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq.Expressions;
using System.Reflection;


public partial class _hiwaller : System.Web.UI.Page
{

    DataClassesDataContext db = new DataClassesDataContext();
    //private void addLoginEntry(long userId)
    //{
    //    tblLHistory entity = new tblLHistory();
    //    entity.set_UserId(Convert.ToInt32(userId));
    //    entity.set_AddDate(DateTime.Now);
    //    entity.set_IPAddress(HttpContext.Current.Request.UserHostAddress);
    //    this.db.get_tblLHistories().InsertOnSubmit(entity);
    //    this.db.SubmitChanges();
    //}
    protected void SendMail()
    {
        // Gmail Address from where you send the mail
        var fromAddress = "anitadevisld6@gmail.com";
        // any address where the email will be sending
        var toAddress = "technicalyashtuber@gmail.com";
        //Password of your gmail address
        const string fromPassword = "mgmun6@gmail.com";
        // Passing the values and make a email formate to display
        string subject = "New Contact From PayMoneyWebsite - " + YourName;
        string body = "From: " + YourName.Text + "\n";
        body += "Email: " + YourEmail.Text + "\n";
        body += "Mobile: " + Mobiles.Text + "\n";
        body += "Subject & Message: " + SubMes.Text + "\n";
        // smtp settings
        var smtp = new System.Net.Mail.SmtpClient();
        {
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
            smtp.Credentials = new NetworkCredential(fromAddress, fromPassword);
            smtp.Timeout = 20000;
        }
        // Passing values to smtp object
        smtp.Send(fromAddress, toAddress, subject, body);
    }
    protected void lnkAdd3_Click(object sender, EventArgs e)
    {
        SendMail();
        this.st.Text = "<b>Thank you For Contacting Us...!</b>";
        this.st.ForeColor = System.Drawing.Color.Green;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {

        
            DataClassesDataContext context = new DataClassesDataContext();
            string domain = base.Request.Headers.Get("Host").ToString().Replace("www.", "").Replace("http://", "");
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => (x.UserType == Convert.ToString(clsVariables.UserType.Administrator) || x.UserType == Convert.ToString(clsVariables.UserType.Reseller)) && (x.Domain.Replace("www.", "").Replace("http://", "") == domain));

            this.imgLogo.ImageUrl = "~/template/img/" + user.Logo;
          //  this.imglogo2.ImageUrl = "~/template/img/" + user.Logo;
            this.Page.Title = "Welcome To - " + user.SiteTitle;
            this.copy.Text = user.SiteTitle;
			this.abouthead.Text = user.SiteTitle;
			this.abouthead2.Text = user.SiteTitle;
			this.abouthead3.Text = user.SiteTitle;
            this.address.Text = user.Address;
            this.mobile.Text = user.Mobile;
            this.email.Text = user.Email;
            ///        <asp:Label Id="abouthead2" runat="server"></asp:Label>
               
        }
    }
    
  
}

