﻿using System;
using System.Net;
using System.Net.Mail;
using System.Web;

public class emailClass
{
    private static string ExtractImages(string body, ref int count)
    {
        int num2;
        int index = body.ToLower().IndexOf("<img src=\"", count);
        if (index >= 0)
        {
            num2 = body.IndexOf("\"", (int) (index + 10));
        }
        else
        {
            return "";
        }
        index += 10;
        string str = body.Substring(index, num2 - index);
        count = index;
        return str;
    }

    public static void SendEmail(string from, string to, string cc, string subject, string body, string attachedFiles)
    {
        try
        {
            MailMessage message = new MailMessage();
            SmtpClient client = new SmtpClient("mychoicerecharge.com", 0x19) {
                Credentials = new NetworkCredential(clsVariables.MailSetting.FromEmail, clsVariables.MailSetting.Password)
            };
            message.From = new MailAddress(from);
            string[] strArray = to.Split(new char[] { ';' });
            for (int i = 0; i < strArray.Length; i++)
            {
                if (strArray[i].ToString().Length > 1)
                {
                    message.To.Add(strArray[i].ToString());
                }
            }
            strArray = cc.Split(new char[] { ';' });
            for (int j = 0; j < strArray.Length; j++)
            {
                if (strArray[j].ToString().Length > 1)
                {
                    message.CC.Add(strArray[j].ToString());
                }
            }
            strArray = attachedFiles.Split(new char[] { ';' });
            for (int k = 0; k < strArray.Length; k++)
            {
                if (strArray[k].ToString().Length > 1)
                {
                    message.Attachments.Add(new Attachment(strArray[k].ToString()));
                }
            }
            message.Subject = subject;
            message.Body = body;
            message.IsBodyHtml = true;
            int count = 0;
            string oldValue = ExtractImages(body, ref count);
            Random random = new Random();
            while (oldValue != "")
            {
                string str2 = oldValue;
                int index = str2.ToLower().IndexOf("images/");
                if (index > 0)
                {
                    str2 = str2.Substring(index).Replace("/", @"\");
                    Attachment item = new Attachment(HttpContext.Current.Request.PhysicalApplicationPath + @"\" + str2) {
                        ContentId = random.Next(0x186a0, 0x98967f).ToString()
                    };
                    body = body.Replace(oldValue, "cid:" + item.ContentId);
                    message.Attachments.Add(item);
                    oldValue = ExtractImages(body, ref count);
                }
                else
                {
                    oldValue = ExtractImages(body, ref count);
                }
            }
            message.Body = body;
            client.Send(message);
        }
        catch (Exception exception)
        {
            HttpContext.Current.Response.Write(exception.Message);
        }
    }
}

