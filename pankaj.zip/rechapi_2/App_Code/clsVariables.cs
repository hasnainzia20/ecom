﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.UI.WebControls;

public class clsVariables
{
    public static List<DroptDownClass> AccountTypes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem(" - Select - ", " - Select - "), new ListItem(AccountType.Saving, AccountType.Saving), new ListItem(AccountType.Current, AccountType.Current) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> ApiTypes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem(" - Select - ", " - Select - "), new ListItem(ApiType.Real, ApiType.Real), new ListItem(ApiType.Lapu, ApiType.Lapu) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> ChargeTypes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem(" - Select - ", " - Select - "), new ListItem(ChargeType.SMS, ChargeType.SMS) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> CreditList()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("All", "All"), new ListItem(TransactionType.Balance, TransactionType.Balance), new ListItem(TransactionType.Debit, TransactionType.Debit), new ListItem(TransactionType.RechargeCommRevert, TransactionType.RechargeCommRevert) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> CreditList2()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("All", "All"), new ListItem(TransactionType.Credit, TransactionType.Credit), new ListItem(TransactionType.Payment, TransactionType.Payment), new ListItem(TransactionType.RechargeComm, TransactionType.RechargeComm) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> DebitList()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("All", "All"), new ListItem(TransactionType.Payment, TransactionType.Payment), new ListItem(TransactionType.Credit, TransactionType.Credit), new ListItem(TransactionType.RechargeComm, TransactionType.RechargeComm) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> DebitList2()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("All", "All"), new ListItem(TransactionType.Debit, TransactionType.Debit), new ListItem(TransactionType.Recharge, TransactionType.Recharge), new ListItem(TransactionType.RechargeCommRevert, TransactionType.RechargeCommRevert), new ListItem(TransactionType.RegFees, TransactionType.RegFees) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> PaymentModes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem(" - Select - ", " - Select - "), new ListItem(PaymentMode.Cash, PaymentMode.Cash), new ListItem(PaymentMode.ChequeDD, PaymentMode.ChequeDD), new ListItem(PaymentMode.OnlineETransfer, PaymentMode.OnlineETransfer), new ListItem(PaymentMode.NEFTRTGS, PaymentMode.NEFTRTGS) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> RechargeAPIs()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("Select", "Select"), new ListItem(RechargeAPI.AnshiTelecom, RechargeAPI.AnshiTelecom), new ListItem(RechargeAPI.SMSAcharya, RechargeAPI.SMSAcharya) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> RechargeModes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("All", "All"), new ListItem(RechargeMode.Web, RechargeMode.Web), new ListItem(RechargeMode.GPRS, RechargeMode.GPRS), new ListItem(RechargeMode.SMS, RechargeMode.SMS), new ListItem(RechargeMode.USSD, RechargeMode.USSD) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> RechargeStatuss()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("All", "All"), new ListItem(RechargeStatus.Success, RechargeStatus.Success), new ListItem(RechargeStatus.Failure, RechargeStatus.Failure), new ListItem(RechargeStatus.Pending, RechargeStatus.Pending), new ListItem(RechargeStatus.Reversed, RechargeStatus.Reversed) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> RechargeStatuss2()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("Select", "Select"), new ListItem(RechargeStatus.Success, RechargeStatus.Success), new ListItem(RechargeStatus.Failure, RechargeStatus.Failure), new ListItem(RechargeStatus.Reversed, RechargeStatus.Reversed) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> RequestTypes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("All", "All"), new ListItem(RequestType.Accepted, RequestType.Accepted), new ListItem(RequestType.Rejected, RequestType.Rejected) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> RequestTypes2()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem(" - Select - ", " - Select - "), new ListItem(RequestType.Wallet, RequestType.Wallet), new ListItem(RequestType.SMS, RequestType.SMS) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> SearchTypes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("Select", "Select"), new ListItem(SearchType.Username, SearchType.Username), new ListItem(SearchType.Name, SearchType.Name), new ListItem(SearchType.MobileNumber, SearchType.MobileNumber) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> ServerTypes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem(Servers.Server1, Servers.Server1), new ListItem(Servers.Server2, Servers.Server2) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> ServiceTypes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("Select", "Select"), new ListItem("All", "All"), new ListItem(ServiceType.Mobile, ServiceType.Mobile), new ListItem(ServiceType.DTH, ServiceType.DTH) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> SMSAPIs()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("Select", "Select"), new ListItem(SMSAPI.SMSAchariya, SMSAPI.SMSAchariya) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> TicketStatuss()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("All", "All"), new ListItem(TicketStatus.Open, TicketStatus.Open), new ListItem(TicketStatus.InProcess, TicketStatus.InProcess), new ListItem(TicketStatus.Closed, TicketStatus.Closed) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> TicketTypes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem(" - Select - ", " - Select - "), new ListItem(TicketType.RechargeDispute, TicketType.RechargeDispute), new ListItem(TicketType.OtherTechnical, TicketType.OtherTechnical) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> TransactionTypes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("All", "All"), new ListItem(TransactionType.Credit, TransactionType.Credit), new ListItem(TransactionType.Debit, TransactionType.Debit) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> TransactionTypes2()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem("All", "All"), new ListItem(TransactionType.Credit, TransactionType.Credit), new ListItem(TransactionType.Debit, TransactionType.Debit), new ListItem(TransactionType.Recharge, TransactionType.Recharge), new ListItem(TransactionType.RechargeRevert, TransactionType.RechargeRevert), new ListItem(TransactionType.RechargeComm, TransactionType.RechargeComm), new ListItem(TransactionType.RechargeCommRevert, TransactionType.RechargeCommRevert), new ListItem(TransactionType.Payment, TransactionType.Payment) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    public static List<DroptDownClass> UserTypes()
    {
        ListItem[] itemArray = new ListItem[] { new ListItem(" - Select - ", " - Select - "), new ListItem(UserType.SuperDistributor, UserType.SuperDistributor), new ListItem(UserType.Distributor, UserType.Distributor), new ListItem(UserType.Retailer, UserType.Retailer), new ListItem(UserType.Reseller, UserType.Reseller), new ListItem(UserType.User, UserType.User) };
        return (from eObj in itemArray select new DroptDownClass { 
            Text = eObj.Text,
            Value = eObj.Value
        }).ToList<DroptDownClass>();
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct AccountType
    {
        public static string Saving
        {
            get
            {
                return "Saving";
            }
        }
        public static string Current
        {
            get
            {
                return "Current";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct AlertType
    {
        public static string Advertisement
        {
            get
            {
                return "Advertisement";
            }
        }
        public static string Announcement
        {
            get
            {
                return "Announcement";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct ApiType
    {
        public static string Lapu
        {
            get
            {
                return "Lapu";
            }
        }
        public static string Real
        {
            get
            {
                return "Real";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct ChargeType
    {
        public static string SMS
        {
            get
            {
                return "SMS";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct ComplainStatus
    {
        public static string Pending
        {
            get
            {
                return "Pending";
            }
        }
        public static string Solved
        {
            get
            {
                return "Solved";
            }
        }
        public static string UnSolved
        {
            get
            {
                return "Unsolved";
            }
        }
    }

    public class DroptDownClass
    {
        public string Text { get; set; }

        public string Value { get; set; }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct MailSetting
    {
        public static string FromEmail
        {
            get
            {
                return "no-reply@shreerecharge.com";
            }
        }
        public static string Password
        {
            get
            {
                return "admin.123";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct MessageType
    {
        public static string Longcode
        {
            get
            {
                return "Longcode";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct PaymentMode
    {
        public static string Cash
        {
            get
            {
                return "Cash";
            }
        }
        public static string ChequeDD
        {
            get
            {
                return "Cheque/DD";
            }
        }
        public static string OnlineETransfer
        {
            get
            {
                return "Online E-Transfer";
            }
        }
        public static string NEFTRTGS
        {
            get
            {
                return "NEFT/RTGS";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct PaymentType
    {
        public static string InitialBalanceDep
        {
            get
            {
                return "Initial Balance Deposit";
            }
        }
        public static string PaymentReq
        {
            get
            {
                return "Payment Request";
            }
        }
        public static string RechargeComm
        {
            get
            {
                return "Recharge Comm.";
            }
        }
        public static string Recharge
        {
            get
            {
                return "Recharge";
            }
        }
        public static string Credit
        {
            get
            {
                return "Credit";
            }
        }
        public static string Debit
        {
            get
            {
                return "Debit";
            }
        }
        public static string TNSF
        {
            get
            {
                return "TNSF";
            }
        }
    }


    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct RechargeAPI
    {
        public static string ShreeRecharge
        {
            get
            {
                return "Shree Recharge";
            }
        }
        public static string Emoneygroup
        {
            get
            {
                return "Emoneygroup";
            }
        }
        public static string AvishaTraders
        {
            get
            {
                return "AvishaTraders";
            }
        }
        public static string Yahoo1
        {
            get
            {
                return "Yahoo1";
            }
        }
        public static string Yahoo2
        {
            get
            {
                return "Yahoo2";
            }
        }
        public static string OnlyRecharge
        {
            get
            {
                return "Only Recharge";
            }
        }
        public static string Bonrix
        {
            get
            {
                return "Bonrix";
            }
        }
        public static string Bonrix2
        {
            get
            {
                return "Bonrix2";
            }
        }
        public static string Suvidha
        {
            get
            {
                return "Suvidha";
            }
        }
        public static string SMSAcharya
        {
            get
            {
                return "SMS Acharya";
            }
        }
        public static string Mars
        {
            get
            {
                return "Mars";
            }
        }
        public static string SIPRC
        {
            get
            {
                return "SIPRC";
            }
        }
        public static string PAYMONEY
        {
            get
            {
                return "PAYMONEY";
            }
        }
        public static string ezulix
        {
            get
            {
                return "ezulix";
            }
        }
        public static string esupport
        {
            get
            {
                return "esupport";
            }
        }
        public static string Skcommunition
        {
            get
            {
                return "Skcommunition";
            }
        }

        public static string AvishaTraders2
        {
            get
            {
                return "AvishaTraders2";
            }
        }
        public static string DishTV
        {
            get
            {
                return "Dish TV";
            }
        }
        public static string TataSky
        {
            get
            {
                return "Tata Sky";
            }
        }
        public static string Gtalk
        {
            get
            {
                return "Gtalk";
            }
        }
        public static string Recharge4ushop
        {
            get
            {
                return "Recharge4ushop";
            }
        }
        public static string Jolo
        {
            get
            {
                return "Jolo";
            }
        }
        public static string Champrecharge
        {
            get
            {
                return "Champrecharge";
            }
        }
        public static string Champ
        {
            get
            {
                return "Champ";
            }
        }
        public static string pay1all
        {
            get
            {
                return "pay1all";
            }
        }
        public static string mrobo
        {
            get
            {
                return "mrobo";
            }
        }
        public static string AnshiTelecom
        {
            get
            {
                return "AnshiTelecom";
            }
        }

        public static string Prechaarge
        {
            get
            {
                return "Prechaarge";
            }
        }
        public static string RechApi
        {
            get
            {
                return "RechApi";
            }
        }
        public static string IndiaCart
        {
            get
            {
                return "IndiaCart";
            }
        }
    }
    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct RechargeMode
    {
        public static string API
        {
            get
            {
                return "API";
            }
        }
        public static string Web
        {
            get
            {
                return "Web";
            }
        }
        public static string SMS
        {
            get
            {
                return "SMS";
            }
        }
        public static string GPRS
        {
            get
            {
                return "GPRS";
            }
        }
        public static string USSD
        {
            get
            {
                return "USSD";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct RechargeStatus
    {
        public static string Pending
        {
            get
            {
                return "In Process";
            }
        }
        public static string Success
        {
            get
            {
                return "Success";
            }
        }
        public static string Failure
        {
            get
            {
                return "Failure";
            }
        }
        public static string Reversed
        {
            get
            {
                return "Reversed";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct RequestType
    {
        public static string Pending
        {
            get
            {
                return "Pending";
            }
        }
        public static string Accepted
        {
            get
            {
                return "Accepted";
            }
        }
        public static string Rejected
        {
            get
            {
                return "Rejected";
            }
        }
        public static string Wallet
        {
            get
            {
                return "Wallet";
            }
        }
        public static string SMS
        {
            get
            {
                return "SMS";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct SearchType
    {
        public static string Username
        {
            get
            {
                return "Username";
            }
        }
        public static string MobileNumber
        {
            get
            {
                return "Mobile Number";
            }
        }
        public static string Name
        {
            get
            {
                return "Name";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct Servers
    {
        public static string Server1
        {
            get
            {
                return "Server 1";
            }
        }
        public static string Server2
        {
            get
            {
                return "Server 2";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct ServiceType
    {
        public static string Mobile
        {
            get
            {
                return "Mobile";
            }
        }
        public static string DTH
        {
            get
            {
                return "DTH";
            }
        }
        public static string DataCard
        {
            get
            {
                return "Data Card";
            }
        }
        public static string Postpaid
        {
            get
            {
                return "Postpaid";
            }
        }
        public static string Landline
        {
            get
            {
                return "Landline";
            }
        }
        public static string Electricity
        {
            get
            {
                return "Electricity";
            }
        }
        public static string Gas
        {
            get
            {
                return "Gas";
            }
        }
        public static string Insurance
        {
            get
            {
                return "Insurance";
            }
        }
        public static string MoneyTransfer
        {
            get
            {
                return "Money Transfer";
            }
        }
        public static string PanCard
        {
            get
            {
                return "Pan Card";
            }
        }
        public static string WaterBill
        {
            get
            {
                return "Water Bill";
            }
        }
        public static string MetroCard
        {
            get
            {
                return "Metro Card";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct SMSAPI
    {
        public static string DoveSMS
        {
            get
            {
                return "Dove SMS";
            }
        }
        public static string SMS2
        {
            get
            {
                return "SMS2";
            }
        }
        public static string SMS3
        {
            get
            {
                return "SMS3";
            }
        }
        public static string SMS4
        {
            get
            {
                return "SMS4";
            }
        }
        public static string SMSAchariya
        {
            get
            {
                return "SMS Achariya";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct TicketStatus
    {
        public static string Open
        {
            get
            {
                return "Open";
            }
        }
        public static string InProcess
        {
            get
            {
                return "In Process";
            }
        }
        public static string Closed
        {
            get
            {
                return "Closed";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct TicketType
    {
        public static string RechargeDispute
        {
            get
            {
                return "Mobile Recharge Dispute";
            }
        }
        public static string OtherTechnical
        {
            get
            {
                return "Other Technical Support";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct TransactionType
    {
        public static string ABalance
        {
            get
            {
                return "Actual Balance";
            }
        }
        public static string Recharge
        {
            get
            {
                return "Recharge";
            }
        }
        public static string RechargeRevert
        {
            get
            {
                return "Recharge Revert";
            }
        }
        public static string RechargeFailure
        {
            get
            {
                return "Recharge Failure";
            }
        }
        public static string Payment
        {
            get
            {
                return "Payment";
            }
        }
        public static string Credit
        {
            get
            {
                return "Credit";
            }
        }
        public static string Debit
        {
            get
            {
                return "Debit";
            }
        }
        public static string Balance
        {
            get
            {
                return "Balance";
            }
        }
        public static string RegFees
        {
            get
            {
                return "Reg. Fees";
            }
        }
        public static string RechargeComm
        {
            get
            {
                return "Recharge Comm.";
            }
        }
        public static string RechargeCommFailure
        {
            get
            {
                return "Recharge Comm. Failure";
            }
        }
        public static string RechargeCommRevert
        {
            get
            {
                return "Recharge Comm. Revert";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct UserType
    {
        public static string APIUser
        {
            get
            {
                return "API User";
            }
        }
        public static string Retailer
        {
            get
            {
                return "Retailer";
            }
        }
        public static string Distributor
        {
            get
            {
                return "Distributor";
            }
        }
        public static string User
        {
            get
            {
                return "User";
            }
        }
        public static string SuperDistributor
        {
            get
            {
                return "Super Distributor";
            }
        }
        public static string Reseller
        {
            get
            {
                return "Administrator";
            }
        }
        public static string Administrator
        {
            get
            {
                return "Super Admin";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct USSD
    {
        public static string Username
        {
            get
            {
                return "mychoice";
            }
        }
        public static string Password
        {
            get
            {
                return "j~V7Y!N!";
            }
        }
    }

    [StructLayout(LayoutKind.Sequential, Size=1)]
    public struct VMNType
    {
        public static string USSD
        {
            get
            {
                return "USSD";
            }
        }
        public static string SMS
        {
            get
            {
                return "SMS";
            }
        }
    }
}

