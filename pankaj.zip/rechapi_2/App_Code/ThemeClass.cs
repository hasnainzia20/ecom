﻿using System;
using System.Web.UI;

public class ThemeClass : Page
{
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (this.Session["Theme"] != null)
        {
            this.Page.Theme = this.Session["Theme"].ToString();
        }
    }
}

