﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web.Security;
using System.Collections.Specialized;
using System.Web.Script.Serialization;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public class clsMethods
{
    private DataClassesDataContext db = new DataClassesDataContext();
    private int indirectCount;

    public static string AashishAPIRecharge(string MobileNumber, string Amount, string Type, string operatorCode)
    {
        string str2 = getDateTime().ToString("MM.dd.yyyy hh:mm:s");
        return AshishApiRequest("http://www.aashishtelecom.com/_API/_APIPROCS.ASPX?_prcsr=9374909099&_urlenc=0000|" + MobileNumber.Trim() + "|" + Amount.Trim() + "|" + operatorCode + "|" + Type + "|" + str2 + "&_encuse=0");
    }

    public static void addABalance(int userId, decimal amount, int RefId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblAPIBalance balance = Queryable.SingleOrDefault<tblAPIBalance>(context.tblAPIBalances, x => x.UserId == userId);
        if (balance != null)
        {
            balance.Balance += amount;
            context.SubmitChanges();
            tblApiBalHistory entity = new tblApiBalHistory
            {
                UserId = userId,
                TransType = clsVariables.TransactionType.Credit,
                Amount = amount,
                TransId = new int?(RefId),
                AddDate = DateTime.Now
            };
            context.tblApiBalHistories.InsertOnSubmit(entity);
            context.SubmitChanges();
        }
    }

    public static void addBalanceHistory(int userid, string transType, decimal amount)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblApiBalHistory entity = new tblApiBalHistory
        {
            TransType = transType,
            Amount = Convert.ToDecimal(amount),
            AddDate = DateTime.Now,
            UserId = userid
        };
        context.tblApiBalHistories.InsertOnSubmit(entity);
        context.SubmitChanges();
        tblAPIBalance balance = Queryable.SingleOrDefault<tblAPIBalance>(context.tblAPIBalances, x => x.UserId == userid);
        if (balance != null)
        {
            if (transType == clsVariables.TransactionType.Credit)
            {
                balance.Balance += Convert.ToDecimal(amount);
            }
            else
            {
                balance.Balance -= Convert.ToDecimal(amount);
            }
            context.SubmitChanges();
        }
        else
        {
            tblAPIBalance balance2 = new tblAPIBalance
            {
                Balance = Convert.ToDecimal(amount),
                UserId = userid
            };
            context.tblAPIBalances.InsertOnSubmit(balance2);
            context.SubmitChanges();
        }
    }

    public static void addReferelComm(int parentId, int apiId, int opeeratorId, decimal amount, string number, string username, int adminId, decimal commPer, int userId, long rechargeId, int resellerId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblUser getUser = Queryable.SingleOrDefault<tblUser>(context.tblUsers, x => (x.Id == parentId) && (x.UserType != clsVariables.UserType.Administrator));
        if (getUser != null)
        {
            decimal num = 0M;
            tblCommission commission = Queryable.FirstOrDefault<tblCommission>(context.tblCommissions, x => (x.PackageId == getUser.SchemeId) && (x.OperatorId == opeeratorId));
            if (commission != null)
            {
                num = commission.Percentage - commPer;
                decimal cost = (amount * num) / 100M;
                addTrans(adminId, cost, string.Concat(new object[] { "Recharge Commission from recharge done on number ", number, " | amt ", amount, " username ", username }), getUser.Id, getUser.Id, getBalance(getUser.Id) + cost, clsVariables.TransactionType.RechargeComm, rechargeId, userId, getBalance(adminId), getBalance(resellerId), resellerId, getABalance(resellerId) + cost);
            }
            if (getUser.ParentId.HasValue)
            {
                addReferelComm(getUser.ParentId.Value, apiId, opeeratorId, amount, number, username, adminId, (commission != null) ? commission.Percentage : 0M, userId, rechargeId, resellerId);
            }
        }
    }

    public static void addSMSBalanceHistory(int userid, string transType, int smsCount, int crUserId, int drUserId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblSMSCredit entity = new tblSMSCredit
        {
            Type = transType,
            SMS = smsCount,
            AddDate = DateTime.Now,
            CrUserId = crUserId,
            DrUserId = drUserId,
            UserId = userid
        };
        context.tblSMSCredits.InsertOnSubmit(entity);
        context.SubmitChanges();
        tblUser user = Queryable.SingleOrDefault<tblUser>(context.tblUsers, x => x.Id == userid);
        if (user != null)
        {
            if (transType == clsVariables.TransactionType.Credit)
            {
                user.SMS = new int?(user.SMS.HasValue ? (user.SMS.Value + smsCount) : smsCount);
            }
            else
            {
                user.SMS = new int?(user.SMS.HasValue ? (user.SMS.Value - smsCount) : smsCount);
            }
            context.SubmitChanges();
        }
    }

    public static int addTrans(int druserid, decimal cost, string remarks, int cruserid, int userid, decimal balance, string transType, long refId, decimal adminBalance, decimal balanc2, int resellerId, decimal aBalance)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblTransaction entity = new tblTransaction
        {
            DrUserId = druserid,
            CrUserId = cruserid,
            Amount = cost,
            AdminBalance = new decimal?(adminBalance),
            AddDate = DateTime.Now,
            Remarks = remarks
        };
        if (aBalance != -1M)
        {
            entity.ABalance = new decimal?(aBalance);
        }
        entity.AdminId = new int?(resellerId);
        entity.UserId = userid;
        entity.Balance = balance;
        entity.Balance2 = new decimal?(balanc2);
        entity.TransactionType = transType;
        if (refId != 0L)
        {
            entity.RefId = new long?(refId);
        }
        context.tblTransactions.InsertOnSubmit(entity);
        context.SubmitChanges();
        return entity.Id;
    }

    public static int addTrans(int druserid, decimal cost, string remarks, int cruserid, int userid, decimal balance, string transType, long refId, int rechargeUserId, decimal adminBalance, decimal balance2, int resellerId, decimal aBalance)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblTransaction entity = new tblTransaction
        {
            DrUserId = druserid,
            CrUserId = cruserid,
            AdminBalance = new decimal?(adminBalance),
            RechargeUserId = new int?(rechargeUserId),
            RefId = new long?(refId),
            AdminId = new int?(resellerId),
            Amount = cost
        };
        if (aBalance != -1M)
        {
            entity.ABalance = new decimal?(aBalance);
        }
        entity.Balance2 = new decimal?(balance2);
        entity.AddDate = DateTime.Now;
        entity.Remarks = remarks;
        entity.UserId = userid;
        entity.Balance = balance;
        entity.TransactionType = transType;
        context.tblTransactions.InsertOnSubmit(entity);
        context.SubmitChanges();
        return entity.Id;
    }

    public static string airnetBal(string apiurl, string username, string password)
    {
        string str = apiurl + "?";
        string str2 = "Mob=" + username + "&message=Bal+" + password + "&source=API";
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }
    //===============================================RechApi Money Transfer Section==================================================
    public static string Getcustdetails(string number)
    {
        string str33 = string.Empty;
        string strrrs = "http://api.rechapi.com/moneyTransfer/cusDetails.php?format=json&token=aFaBR0XDy3DCn8mjTeIb&customerMobile=" + number;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strrrs);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }

    }
    public static string RegisterMoneyUser(string number, string name, string pin)
    {
        string str33 = string.Empty;
        string strrrs = "http://api.rechapi.com/moneyTransfer/customerRegistration.php?format=json&token=aFaBR0XDy3DCn8mjTeIb&customerName=" + name + "&customerPincode=" + pin + "&customerMobile=" + number;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strrrs);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }

    }
    public static string RegisterMoneyUserOTP(string number, string otp)
    {
        string str33 = string.Empty;
        string strrrs = "http://api.rechapi.com/moneyTransfer/customerVerify.php?format=json&token=aFaBR0XDy3DCn8mjTeIb&customerMobile=" + number + "&otp=" + otp;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strrrs);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }

    }
    public static string addBeneficiary(string number, string bname, string mobile, string acno, string ifsc)
    {
        string str33 = string.Empty;
        string strrrs = "http://api.rechapi.com/moneyTransfer/addBeneficiary.php?format=json&token=aFaBR0XDy3DCn8mjTeIb&customerMobile=" + number + "&beneficiaryName=" + bname + "&beneficiaryMobileNumber=" + mobile + "&beneficiaryAccountNumber=" + acno + "&ifscCode=" + ifsc;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strrrs);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }

    }
    public static string BeneficiaryValidation(string number, string acno, string ifsc)
    {
        Random r = new Random();
        int rond = r.Next(465421);
        string str2 = "http://api.rechapi.com/moneyTransfer/beneficiaryValidate.php?format=json&token=aFaBR0XDy3DCn8mjTeIb&customerMobile=" + number + "&beneficiaryAccountNumber=" + acno + "&ifscCode=" + ifsc + "&urid=" + rond;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }

    }
    public static string addBeneficiaryVerify(string number, string otp, string bid)
    {
        string str33 = string.Empty;
        string strrrs = "http://api.rechapi.com/moneyTransfer/beneficiaryVerifiy.php?format=json&token=aFaBR0XDy3DCn8mjTeIb&customerMobile=" + number + "&otp=" + otp + "&beneficiaryId=" + bid;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strrrs);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }

    }
    public static string BeneficiaryDelete(string number, string bid)
    {
        string str33 = string.Empty;
        string strrrs = "http://api.rechapi.com/moneyTransfer/deleteBeneficiary.php?format=json&token=aFaBR0XDy3DCn8mjTeIb&customerMobile=" + number + "&beneficiaryId=" + bid;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strrrs);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }

    }
    public static string BeneficiaryDeleteOtp(string number, string otp, string bid)
    {
        string str33 = string.Empty;
        string strrrs = "http://api.rechapi.com/moneyTransfer/deleteBeneficiaryVerifiy.php?format=json&token=aFaBR0XDy3DCn8mjTeIb&&customerMobile=" + number + "&beneficiaryId=" + bid + "&otp=" + otp;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strrrs);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }

    }
    public static string MoneyTransfer(string number, string amt, string bid, string maxid)
    {
        string str2 = "http://api.rechapi.com/moneyTransfer/sendMoney.php?format=json&token=aFaBR0XDy3DCn8mjTeIb&customerMobile=" + number + "&amount=" + amt + "&beneficiaryId=" + bid + "&urid=" + maxid;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }

    }
    //===============================================RechApi Money Transfer Section==================================================
    public static string AshishApiRequest(string url)
    {
        StringBuilder builder = new StringBuilder();
        byte[] bytes = Encoding.ASCII.GetBytes(url);
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
        request.Method = "POST";
        request.ContentType = "application/x-www-form-urlencoded";
        request.ContentLength = bytes.Length;
        using (Stream stream = request.GetRequestStream())
        {
            stream.Write(bytes, 0, bytes.Length);
            stream.Close();
        }
        Stream responseStream = ((HttpWebResponse)request.GetResponse()).GetResponseStream();
        string str = null;
        int count = 0;
        do
        {
            count = responseStream.Read(bytes, 0, bytes.Length);
            if (count != 0)
            {
                str = Encoding.ASCII.GetString(bytes, 0, count);
                builder.Append(str);
            }
        }
        while (count > 0);
        return builder.ToString();
    }

    public static string decryptforEuronet(string encryptPin)
    {
        byte[] inputBuffer = Convert.FromBase64String(encryptPin);
        string s = "abcd8683mhary9512";
        MD5CryptoServiceProvider provider = new MD5CryptoServiceProvider();
        byte[] buffer = provider.ComputeHash(Encoding.UTF8.GetBytes(s));
        provider.Clear();
        TripleDESCryptoServiceProvider provider2 = new TripleDESCryptoServiceProvider
        {
            Key = buffer,
            Mode = CipherMode.ECB,
            Padding = PaddingMode.PKCS7
        };
        byte[] bytes = provider2.CreateDecryptor().TransformFinalBlock(inputBuffer, 0, inputBuffer.Length);
        provider2.Clear();
        return Encoding.UTF8.GetString(bytes, 0, bytes.Length);
    }
    //===============================================AREA OF RECHARGE============================================
    public static string doRecharge(string number, string amount, string opeartorcode, string circle, int userId, string rechargeType, string rechargeMode, long ClientId, string op1, string op2, string op3)
    {

        if (Convert.ToDecimal(amount) <= 0M)
        {
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                string json = new JavaScriptSerializer().Serialize(new
                {
                    ResponseStatus = "FAILURE",
                    Message = "Amount is invalid"
                });
              
                return json;
            }
            return "Amount is invalid";
        }
        DataClassesDataContext context = new DataClassesDataContext();
        tblRecharge recharge = (from x in context.tblRecharges
                                orderby x.RechargeDate descending
                                select x).FirstOrDefault<tblRecharge>(x => (((((x.Status == clsVariables.RechargeStatus.Success) || (x.Status == clsVariables.RechargeStatus.Pending)) && (x.UserId == userId)) && (x.Amount == Convert.ToDecimal(amount))) && (x.Number == number)) && (x.OperatorId == Convert.ToInt32(opeartorcode)));
        if ((recharge != null) && ((recharge == null) || (recharge.RechargeDate.AddMinutes(30.0) >= DateTime.Now)))
        {
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                string json = new JavaScriptSerializer().Serialize(new
                {
                    ResponseStatus = "FAILURE",
                    Message = "Same Amount Hit Again Recharge After 30 Min for Same Amount & Same Number"
                });

                return json;
            }
            return "Your next recharge will be after 30 minutes on same number with same amount";
        }
        tblUser getUser = context.tblUsers.Single<tblUser>(x => x.Id == userId);
        if (!getUser.Status)
        {
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                string json = new JavaScriptSerializer().Serialize(new
                {
                    ResponseStatus = "FAILURE",
                    Message = "User is inactive, please contact administrator"
                });

                return json;
              
            }
            return "User is inactive, please contact administrator";
        }
        tblApi api = null;
        int resellerId = 0;
        resellerId = clsMethods.getadminId3(getUser.Id);
        if (resellerId == 0)
        {
            resellerId = clsMethods.getadminId2(getUser.Id);
        }
        tblCommission getCommission = null;
        bool flag = false;
        int schemeid = 0;
        if (getUser.SchemeId.HasValue)
        {
            getCommission = context.tblCommissions.FirstOrDefault<tblCommission>(x => (x.PackageId == getUser.SchemeId) && (x.OperatorId == Convert.ToInt16(opeartorcode)));
            if ((getCommission != null) && getCommission.ApiId.HasValue)
            {
                schemeid = getCommission.PackageId;
                api = context.tblApis.Single<tblApi>(x => x.Id == ((int)getCommission.ApiId.Value));
            }
        }
        string str = null;
        if (getCommission == null)
        {
            if (resellerId != 0)
            {
                tblUser getReseller = context.tblUsers.Single<tblUser>(x => x.Id == resellerId);
                tblCommission getResellerComm = context.tblCommissions.SingleOrDefault<tblCommission>(x => (x.PackageId == getReseller.SchemeId) && (x.OperatorId == Convert.ToInt32(opeartorcode)));
                if (getResellerComm != null)
                {
                    schemeid = getResellerComm.PackageId;
                    if (getResellerComm.ApiId.HasValue)
                    {
                        api = context.tblApis.Single<tblApi>(x => x.Id == ((int)getResellerComm.ApiId.Value));
                    }
                }
            }
            else
            {
                api = context.tblApis.First<tblApi>();
            }
        }
        else
        {
            tblUser getReseller = context.tblUsers.Single<tblUser>(x => x.Id == resellerId);
            tblCommission getResellerComm = context.tblCommissions.SingleOrDefault<tblCommission>(x => (x.PackageId == getReseller.SchemeId) && (x.OperatorId == Convert.ToInt32(opeartorcode)));
            if (getResellerComm != null)
            {
                schemeid = getResellerComm.PackageId;
                if (getResellerComm.ApiId.HasValue)
                {
                    api = context.tblApis.Single<tblApi>(x => x.Id == ((int)getResellerComm.ApiId.Value));
                }
            }
        }
        if (context.tblCommPackages.SingleOrDefault<tblCommPackage>(x => (x.Id == schemeid)).Locked)
        {
            flag = true;
        }
        decimal num = clsMethods.getBalance(userId);
        if (num < Convert.ToDecimal(amount))
        {
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                string json = new JavaScriptSerializer().Serialize(new
                {
                    ResponseStatus = "FAILURE",
                    Message = "You don't have sufficient balance to recharge"
                });

                return json;
             
            }
            return "Insufficient Balance";
        }
        ob ob1 = new ob();
        tblCharge charge = context.tblCharges.Single<tblCharge>(x => x.Type == Convert.ToString("RechargeLimit"));
        decimal numm = clsMethods.getBalance(userId);
        if (numm > 0 && Convert.ToDecimal(amount) <= charge.UserFee)
        {
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                string json = new JavaScriptSerializer().Serialize(new
                {
                    ResponseStatus = "FAILURE",
                    Message = "You Can not Recharge From Your Minimum Balance Limit"
                });

                return json;
            }
            return "You Can't Recharge From Your Minimum Balance Limit";
        }

        tblCharge block = context.tblCharges.Single<tblCharge>(x => x.Type == Convert.ToString("AmountBlock"));
        decimal bcamt = 0;
        if (getUser.UserType == clsVariables.UserType.SuperDistributor)
        {
            bcamt = Convert.ToInt32(block.SD);
        }
        else if (getUser.UserType == clsVariables.UserType.Distributor)
        {
            bcamt = Convert.ToInt32(block.Dist);
        }
        else if (getUser.UserType == clsVariables.UserType.Retailer)
        {
            bcamt = Convert.ToInt32(block.Retailer);
        }
        else
        {
            bcamt = Convert.ToInt32(block.UserFee);
        }

        if (numm > 0 && Convert.ToDecimal(amount) <= bcamt)
        {
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                string json = new JavaScriptSerializer().Serialize(new
                {
                    ResponseStatus = "FAILURE",
                    Message = "You don't have sufficient balance to recharge"
                });

                return json;
            }
            return "Insufficient Balance";
        }
        

        tblOperator getOperator = context.tblOperators.SingleOrDefault<tblOperator>(x => x.Id == Convert.ToInt32(opeartorcode));
        if (getOperator == null)
        {
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                string json = new JavaScriptSerializer().Serialize(new
                {
                    ResponseStatus = "FAILURE",
                    Message = "Operator Not Found or Due To Some Error!"
                });

                return json;
             
            }
            return "Sorry!! Contact Service Provider 1";
        }
        tblMainComp comp = context.tblMainComps.Single<tblMainComp>(x => x.Id == getOperator.MainCompId);
        if (comp.Down)
        {
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                string json = new JavaScriptSerializer().Serialize(new
                {
                    ResponseStatus = "FAILURE",
                    Message = comp.OperatorName + " service currently not available, please try later."
                });

                return json;

            }
            return (comp.OperatorName + " service currently not available, please try later.");
        }
        if (!flag)
        {
            IQueryable<tblAmountExact> source = from x in context.tblAmountExacts
                                                where (x.OperatorId == getOperator.MainCompId) && x.Status
                                                select x;
            bool flag2 = false;
            if (source.Count<tblAmountExact>() > 0)
            {
                using (IEnumerator<tblAmountExact> enumerator = source.GetEnumerator())
                {
                    tblAmountExact g;
                    while (enumerator.MoveNext())
                    {
                        g = enumerator.Current;
                        string[] strArray = g.Amount.Split(new char[] { ',' });
                        for (int j = 0; j < strArray.Length; j++)
                        {
                            if (Convert.ToDecimal(amount) == Convert.ToDecimal(strArray[j]))
                            {
                                api = context.tblApis.Single<tblApi>(x => x.Id == g.APIId);
                                if (api.Id == g.APIId)
                                {
                                    flag2 = true;
                                    continue;
                                }
                            }
                        }
                    }
                }
            }
            if (!flag2)
            {
                IQueryable<tblRangeAmt> queryable2 = from x in context.tblRangeAmts
                                                     where (((Convert.ToDecimal(amount) >= x.MinAmt) && (Convert.ToDecimal(amount) <= x.MaxAmt)) && (x.OperatorId == getOperator.MainCompId)) && x.Status
                                                     select x;
                if (queryable2.Count<tblRangeAmt>() > 0)
                {
                    using (IEnumerator<tblRangeAmt> enumerator2 = queryable2.GetEnumerator())
                    {
                        tblRangeAmt i;
                        while (enumerator2.MoveNext())
                        {
                            i = enumerator2.Current;
                            api = context.tblApis.Single<tblApi>(x => x.Id == i.APIId);
                            if (api.Id == i.APIId)
                            {
                                goto Label_128A;
                            }
                        }
                    }
                }
            }
        }

    Label_128A:
        if (api != null)
        {
            if ((((((api.APIName == clsVariables.RechargeAPI.OnlyRecharge) && (getOperator.ORCode == null)) || ((api.APIName == clsVariables.RechargeAPI.AvishaTraders2) && (getOperator.BonrixCode == null))) || (((api.APIName == clsVariables.RechargeAPI.Suvidha) && (getOperator.RCCode == null)) || ((api.APIName == clsVariables.RechargeAPI.SMSAcharya) && (getOperator.SACode == null)))) || ((((api.APIName == clsVariables.RechargeAPI.Bonrix2) && (getOperator.BonrixCode == null)) || ((api.APIName == clsVariables.RechargeAPI.Emoneygroup) && (getOperator.RCCode == null))) || (((api.APIName == clsVariables.RechargeAPI.AvishaTraders) && (getOperator.RCCode == null)) || ((api.APIName == clsVariables.RechargeAPI.Yahoo1) && (getOperator.ORCode == null))))) || ((((api.APIName == clsVariables.RechargeAPI.Recharge4ushop) && (getOperator.R4uCode == null)) || ((api.APIName == clsVariables.RechargeAPI.Yahoo2) && (getOperator.Yahoo2 == null))) || ((((api.APIName == clsVariables.RechargeAPI.AnshiTelecom) && (getOperator.APICode2 == null)) || ((api.APIName == clsVariables.RechargeAPI.Jolo) && (getOperator.APICode3 == null))) || ((api.APIName == clsVariables.RechargeAPI.Gtalk) && (getOperator.APICode1 == null)))))
            {
                if (rechargeMode == clsVariables.RechargeMode.API)
                {
                    string json = new JavaScriptSerializer().Serialize(new
                    {
                        ResponseStatus = "FAILURE",
                        Message = "Sorry!! Contact Service Provider"
                    });

                    return json;
                 
                }
                return "Sorry!! Contact Service Provider";
            }
            tblState state = context.tblStates.SingleOrDefault<tblState>(x => x.Id == Convert.ToInt32(circle));
            if ((state == null) && (rechargeType == clsVariables.ServiceType.Mobile))
            {
                if (rechargeMode == clsVariables.RechargeMode.API)
                {
                    string json = new JavaScriptSerializer().Serialize(new
                    {
                        ResponseStatus = "FAILURE",
                        Message = "Sorry!! Contact Service Provider or State Issue!"
                    });

                    return json;
                }
                return "Sorry!! Contact Service Provider";
            }
            tblUser user = context.tblUsers.Single<tblUser>(x => x.UserType == clsVariables.UserType.Administrator);
            if (resellerId == 0)
            {
                resellerId = clsMethods.getadminId2(getUser.Id);
            }
            tblUser user2 = context.tblUsers.Single<tblUser>(x => x.Id == resellerId);
            decimal num3 = 0M;
            if (user2.UserType == clsVariables.UserType.Reseller)
            {
                num3 = clsMethods.getABalance(resellerId);
            }
            else
            {
                num3 = 99999M;
            }
            if (num3 >= Convert.ToDecimal(amount))
            {
                tblRecharge entity = new tblRecharge();
                if (rechargeMode == clsVariables.RechargeMode.API)
                {
                    tblRecharge recharge3 = (from x in context.tblRecharges
                                             where x.UserId == userId
                                             orderby x.ClientSequenceId descending
                                             select x).FirstOrDefault<tblRecharge>();
                    if (recharge3 == null)
                    {
                        entity.ClientSequenceId = 1;
                    }
                    else
                    {
                        entity.ClientSequenceId = recharge3.ClientSequenceId + 1;
                    }
                    entity.ClientId = new long?(ClientId);
                }
                entity.OperatorId = new short?(Convert.ToInt16(opeartorcode));
                entity.APIId = new short?(api.Id);
                entity.OpeningBal = num;
                entity.Amount = Convert.ToDecimal(amount);
                entity.Optional1 = op1;
                entity.Optional2 = op2;
                entity.Optional3 = op3;
                entity.Number = number;
                entity.BalanceType = str;
                entity.RechargeDate = DateTime.Now;
                entity.Status = clsVariables.RechargeStatus.Pending;
                entity.AdminId = new int?(user.Id);
                entity.ResellerId = new int?(resellerId);
                try
                {
                    if (rechargeType == clsVariables.ServiceType.Electricity)
                    {
                        ob ob = new ob();

                        string getidchargeidd = ob.executescalar("select Id from tblUtilityRange where " + amount + " >= MinAmt AND " + amount + " <= MaxAmt ").ToString();
                        string getidchargee = ob.executescalar("select Charge from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
                        string gettypechargee = ob.executescalar("select Type from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
                        string getutypece = ob.executescalar("select UserType from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
                        string gestypece = ob.executescalar("select Service from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
                        if (getutypece == user.UserType)
                        {
                            if (gestypece == clsVariables.ServiceType.Electricity)
                            {
                                if (gettypechargee == "Percentage")
                                {
                                    entity.Cost = Convert.ToDecimal(amount) + (Convert.ToDecimal(amount) * Convert.ToDecimal(getidchargee) / 100M);
                                    entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                                }
                                else
                                {
                                    entity.Cost = Convert.ToDecimal(amount) + (Convert.ToDecimal(getidchargee));
                                    entity.ClosingBal = (entity.OpeningBal - entity.Cost);

                                }
                            }
                            else
                            {
                                entity.Cost = Convert.ToDecimal(amount);
                                entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                            }
                        }
                        else
                        {
                            entity.Cost = Convert.ToDecimal(amount);
                            entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                        }

                    }

                    else if (rechargeType == clsVariables.ServiceType.Postpaid)
                    {

                        ob ob = new ob();

                        string getidchargeidd = ob.executescalar("select Id from tblUtilityRange where " + amount + " >= MinAmt AND " + amount + " <= MaxAmt ").ToString();
                        string getidchargee = ob.executescalar("select Charge from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
                        string gettypechargee = ob.executescalar("select Type from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
                        string getutypece = ob.executescalar("select UserType from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
                        string gestypece = ob.executescalar("select Service from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
                        if (getutypece == user.UserType)
                        {
                            if (gestypece == clsVariables.ServiceType.Postpaid)
                            {
                                if (gettypechargee == "Percentage")
                                {
                                    entity.Cost = Convert.ToDecimal(amount) + (Convert.ToDecimal(amount) * Convert.ToDecimal(getidchargee) / 100M);
                                    entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                                }
                                else
                                {
                                    entity.Cost = Convert.ToDecimal(amount) + (Convert.ToDecimal(getidchargee));
                                    entity.ClosingBal = (entity.OpeningBal - entity.Cost);

                                }
                            }
                            else
                            {
                                entity.Cost = Convert.ToDecimal(amount);
                                entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                            }
                        }
                        else
                        {
                            entity.Cost = Convert.ToDecimal(amount);
                            entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                        }

                    }
                    else if (rechargeType == "Pan Card")
                    {

                        if (amount == "2")
                        {
                            entity.Cost = Convert.ToDecimal("220");
                            entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                        }
                        else if (amount == "3")
                        {
                            entity.Cost = Convert.ToDecimal("330");
                            entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                        }
                        else if (amount == "5")
                        {
                            entity.Cost = Convert.ToDecimal("550");
                            entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                        }
                        else if (amount == "10")
                        {
                            entity.Cost = Convert.ToDecimal("1100");
                            entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                        }
                        else if (amount == "20")
                        {
                            entity.Cost = Convert.ToDecimal("2200");
                            entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                        }
                        else if (amount == "30")
                        {
                            entity.Cost = Convert.ToDecimal("3300");
                            entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                        }
                    }

                    else
                    {
                        if (getCommission != null)
                        {
                            entity.Cost = Convert.ToDecimal(amount) - ((Convert.ToDecimal(amount) * getCommission.Percentage) / 100M);
                            entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                        }
                        else
                        {
                            entity.Cost = Convert.ToDecimal(amount);
                            entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                        }
                    }
                }
                catch (Exception ex)
                {
                    return (ex.Message);
                }
                entity.UserId = userId;
                entity.CrUserId = user2.Id;
                entity.DrUserId = userId;
                if ((getCommission != null) && (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.DTH)) || (rechargeType == clsVariables.ServiceType.DataCard)))
                {
                    entity.CommAmt = new decimal?((Convert.ToDecimal(amount) * getCommission.Percentage) / 100M);
                    entity.CommPer = new decimal?(getCommission.Percentage);
                }
                else
                {
                    entity.CommAmt = 0;
                    entity.CommPer = 0;
                }
                entity.RechargeMode = rechargeMode;
                entity.ServiceId = new short?(context.tblServices.Single<tblService>(x => (x.ServiceName == rechargeType)).Id);
                entity.TransactionType = clsVariables.TransactionType.Recharge;
                context.tblRecharges.InsertOnSubmit(entity);
                context.SubmitChanges();
                clsMethods.addTrans(userId, entity.Cost, "Recharge done on number: " + entity.Number + " | " + entity.Amount.ToString(), -1, userId, clsMethods.getBalance(getUser.Id) - entity.Cost, clsVariables.TransactionType.Recharge, entity.Id, clsMethods.getBalance(user.Id), clsMethods.getBalance(resellerId), resellerId, clsMethods.getABalance(resellerId) - entity.Cost);
                if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.DTH)) || (rechargeType == clsVariables.ServiceType.DataCard))
                {
                    clsMethods.addReferelComm(getUser.ParentId.Value, api.Id, getOperator.Id, entity.Amount, entity.Number, getUser.Username, user.Id, entity.CommPer.Value, entity.UserId, entity.Id, resellerId);
                }
                if (api.APIName == clsVariables.RechargeAPI.OnlyRecharge)
                {
                    string str2 = null;
                    string clientId = entity.Id.ToString();
                    if (rechargeType == clsVariables.ServiceType.Mobile)
                    {
                        str2 = clsMethods.executeAPI(api.Username, api.Password, state.CircleCode, getOperator.ORCode.ToString(), number, amount, clientId);
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str2 = clsMethods.executeAPI(api.Username, api.Password, "*", getOperator.ORCode.ToString(), number, amount, clientId);
                    }
                    entity.Response = str2;
                    entity.OurTransId = clientId;
                    context.SubmitChanges();
                    if (str2.StartsWith("0"))
                    {
                        entity.Status = clsVariables.RechargeStatus.Success;
                        entity.TransactionId = str2.Split(new char[] { '|' })[2];
                        entity.OperatorRef = str2.Split(new char[] { '|' })[4];
                    }
                    else if (str2.StartsWith("1"))
                    {
                        entity.Status = clsVariables.RechargeStatus.Failure;
                        entity.TransactionId = str2.Split(new char[] { '|' })[2];
                        entity.OperatorRef = str2.Split(new char[] { '|' })[4];
                        entity.ClosingBal = (entity.OpeningBal);
                    }
                    else if (str2.StartsWith("2"))
                    {
                        entity.TransactionId = str2.Split(new char[] { '|' })[2];
                    }
                    context.SubmitChanges();
                }
                else if ((api.APIName == clsVariables.RechargeAPI.AvishaTraders2) || (api.APIName == clsVariables.RechargeAPI.Bonrix2))
                {
                    string str4 = null;
                    string rechargeId = entity.Id.ToString();
                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.DataCard)) || (rechargeType == clsVariables.ServiceType.Postpaid))
                    {
                        str4 = clsMethods.sendAirnet(api.Apiurl, api.Username, api.Password, getOperator.BonrixCodeType, getOperator.BonrixCode, number, amount.ToString(), rechargeId);
                    }
                    else if (((rechargeType == clsVariables.ServiceType.DTH) || (rechargeType == clsVariables.ServiceType.Electricity)) || ((rechargeType == clsVariables.ServiceType.Gas) || (rechargeType == clsVariables.ServiceType.Insurance)))
                    {
                        str4 = clsMethods.sendAirnet(api.Apiurl, api.Username, api.Password, getOperator.BonrixCodeType, getOperator.BonrixCode, number, amount.ToString(), rechargeId);
                    }
                    entity.Response = str4;
                    entity.OurTransId = rechargeId;
                    context.SubmitChanges();
                    if (str4.Length > 0)
                    {
                        if (str4.Contains("Success"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = str4.Split(new char[] { ',' })[2].Split(new char[] { ':' })[1];
                            entity.OperatorRef = str4.Split(new char[] { ':' })[4];

                        }
                        else if (((str4.Contains("fail") || str4.Contains("Mobile number must not be less than 10 digits")) || (str4.Contains("you can't send same Recharge Request for 20 min..") || str4.Contains("You can not recharge with same amount for 30 min(s)"))) || (str4.Contains("Sorry, You do not have Sufficient Balance.") || str4.Contains("Insufficient balance for this Recharge. your balance")))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.ClosingBal = (entity.OpeningBal);
                            if ((!str4.Contains("Mobile number must not be less than 10 digits") && !str4.Contains("you can't send same Recharge Request for 20 min..")) && (!str4.Contains("Sorry, You do not have Sufficient Balance.") && !str4.Contains("Insufficient balance for this Recharge. your balance")))
                            {
                                entity.TransactionId = str4.Split(new char[] { ',' })[2].Split(new char[] { ':' })[1];
                            }
                        }
                        else
                        {
                            entity.TransactionId = str4.Split(new char[] { ',' })[2].Split(new char[] { ':' })[1];
                        }
                    }
                    context.SubmitChanges();
                }


                //prem
                else if (api.APIName == "PAYMONEY")
                {
                    string str6 = null;
                    string str7 = entity.Id.ToString();

                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        try
                        {
                            str6 = myapihit(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.Yahoo2.ToString(), number, amount.ToString(), entity.Id.ToString());
                            //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}

                        }
                        catch { }
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str6 = myapihit(api.Apiurl, api.Username, api.Password, "*", getOperator.Yahoo2.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }

                    entity.Response = str6;
                    entity.OurTransId = str7;
                    context.SubmitChanges();


                    if (str6.Length > 0)
                    {

                        //   Failure,0,10107,826458050,15,Invalid Operator Code
                        //{"STATUS":"FAILED","MOBILE":"151218120","AMOUNT":"30","RPID":"","AGENTID":"10000","OPID":"","BAL":3000.0,"MSG":"FAILED! Invalid Amount"}  string strapiid = "0";
                        string strapiid = "0";
                        string strstatus = "0";
                        try
                        {
                            string[] P1 = str6.Split('"');
                            //STATUS = P1[0].ToString();
                            //TRID = P1[1].ToString();
                            //CLIENTID = P1[2].ToString();
                            //MOBILE = P1[3].ToString();
                            //AMOUNT = P1[4].ToString();


                            //strstatus = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                            strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                            // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                            strapiid = P1[15].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                        }
                        catch
                        {
                            strapiid = "0";
                        }

                        if (str6.Contains("SUCCESS"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = strapiid;
                            entity.OperatorRef = str6.Split(new char[] { '"' })[23];
                        }
                        else if (str6.Contains("FAILED"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.TransactionId = strapiid;
                            entity.OperatorRef = str6.Split(new char[] { '"' })[23];
                            entity.ClosingBal = (entity.OpeningBal);
                        }
                        else
                        {
                            entity.TransactionId = strapiid;
                        }

                    }
                    context.SubmitChanges();
                }
                //prem  
                // for example i test on this api for electrcity
                else if (api.APIName == "mrobo")
                {
                    string str6 = null;
                    string str7 = entity.Id.ToString();

                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        try
                        {
                            str6 = myapihitpost(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.PwProdName.ToString(), number, amount.ToString(), entity.Id.ToString());
                            //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}

                        }
                        catch { }
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str6 = myapihitpost(api.Apiurl, api.Username, api.Password, "*", getOperator.PwProdName.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }
                    else if (rechargeType == clsVariables.ServiceType.Electricity)
                    {
                        str6 = elehit(api.Apiurl, api.Username, api.Password, "*", getOperator.PwProdName.ToString(), number, op1, op2, op3, amount.ToString(), entity.Id.ToString());
                    }

                    entity.Response = str6;
                    entity.OurTransId = str7;
                    context.SubmitChanges();


                    if (str6.Length > 0)
                    {

                        string strapiid = "0";
                        string strstatus = "0";
                        try
                        {
                            string[] P1 = str6.Split('"');

                            strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                            // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                            strapiid = P1[18].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                        }
                        catch
                        {
                            strapiid = "0";
                        }
                        var gettingop = new JavaScriptSerializer().Deserialize<Myopb>(str6);
                        if (str6.Contains("success") || str6.Contains("Successfully"))
                        {

                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = strapiid.Replace(":", "").Replace(",", "");
                            entity.OperatorRef = gettingop.tnx_id;
                        }
                        else if (str6.Contains("failed") || str6.Contains("failure"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.TransactionId = strapiid.Replace(":", "").Replace(",", "");
                            entity.OperatorRef = gettingop.tnx_id;
                            entity.ClosingBal = (entity.OpeningBal);
                        }
                        else
                        {
                            entity.TransactionId = strapiid.Replace(":", "").Replace(",", "");
                        }

                    }
                    context.SubmitChanges();
                }
                //prem
                else if (api.APIName == "Skcommunition")
                {
                    string str6 = null;
                    string str7 = entity.Id.ToString();

                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        try
                        {
                            str6 = myapihit(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.PyOpType.ToString(), number, amount.ToString(), entity.Id.ToString());
                            //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}

                        }
                        catch { }
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str6 = myapihit(api.Apiurl, api.Username, api.Password, "*", getOperator.PyOpType.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }

                    entity.Response = str6;
                    entity.OurTransId = str7;
                    context.SubmitChanges();


                    if (str6.Length > 0)
                    {

                        //   Failure,0,10107,826458050,15,Invalid Operator Code
                        //{"STATUS":"FAILED","MOBILE":"151218120","AMOUNT":"30","RPID":"","AGENTID":"10000","OPID":"","BAL":3000.0,"MSG":"FAILED! Invalid Amount"}  string strapiid = "0";
                        string strapiid = "0";
                        string strstatus = "0";
                        try
                        {
                            string[] P1 = str6.Split('>');
                            strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                            // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                            strapiid = P1[16].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                        }
                        catch
                        {
                            strapiid = "0";
                        }

                        if (str6.Contains("SUCCESS"))
                        {

                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = str6.Split(new char[] { '>' })[13].Replace("</field1", "");
                            entity.OperatorRef = str6.Split(new char[] { '>' })[17].Replace("</apirefid", "");
                        }
                        else if (str6.Contains("FAILED") || str6.Contains("REFUND"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.TransactionId = strapiid.Replace("</apirefid", "");
                            // entity.OperatorRef = str6.Split(new char[] { '"' })[23];
                            entity.ClosingBal = (entity.OpeningBal);
                        }
                        else
                        {
                            entity.TransactionId = strapiid.Replace("</apirefid", "");
                        }

                    }
                    context.SubmitChanges();
                }
                //prem
                else if (api.APIName == "pay1all")
                {
                    string str6 = null;
                    string str7 = entity.Id.ToString();

                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        try
                        {
                            str6 = myapihit(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.PyOpCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                            //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}

                        }
                        catch { }
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str6 = myapihit(api.Apiurl, api.Username, api.Password, "*", getOperator.PyOpCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }

                    entity.Response = str6;
                    entity.OurTransId = str7;
                    context.SubmitChanges();


                    if (str6.Length > 0)
                    {

                        // {"ERROR":"1","STATUS":"PENDING","MESSAGE":"Recharge Pending","ip":"148.72.64.205","request":{"member_id":"7988604440","api_password":"7988604440","api_pin":"76539","opcode":"184","number":"9466462872","amount":"10","request_id":"10005"}}
                        string strapiid = "0";
                        string strstatus = "0";
                        string scode = "0";
                        try
                        {
                            string[] P1 = str6.Split('"');
                            //STATUS = P1[0].ToString();
                            //TRID = P1[1].ToString();
                            //CLIENTID = P1[2].ToString();
                            //MOBILE = P1[3].ToString();
                            //AMOUNT = P1[4].ToString();

                            scode = P1[7].ToString();
                            //strstatus = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                            strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                            // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                            strapiid = P1[11].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                        }
                        catch
                        {
                            strapiid = "0";
                        }

                        if (scode.Contains("1"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = strapiid;
                            entity.OperatorRef = str6.Split(new char[] { '"' })[15];
                        }
                        else if (scode.Contains("3"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.TransactionId = strapiid;
                            entity.OperatorRef = str6.Split(new char[] { '"' })[15];
                            entity.ClosingBal = (entity.OpeningBal);
                        }
                        else
                        {
                            entity.TransactionId = strapiid;
                        }

                    }
                    context.SubmitChanges();
                }
                //prem
                else if (api.APIName == "esupport")
                {
                    string str6 = null;
                    string str7 = entity.Id.ToString();

                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        try
                        {
                            str6 = myapihit(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.SACode.ToString(), number, amount.ToString(), entity.Id.ToString());
                            //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}

                        }
                        catch { }
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str6 = myapihit(api.Apiurl, api.Username, api.Password, "*", getOperator.PwOpCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }

                    entity.Response = str6;
                    entity.OurTransId = str7;
                    context.SubmitChanges();


                    if (str6.Length > 0)
                    {

                        // {"ERROR":"1","STATUS":"PENDING","MESSAGE":"Recharge Pending","ip":"148.72.64.205","request":{"member_id":"7988604440","api_password":"7988604440","api_pin":"76539","opcode":"184","number":"9466462872","amount":"10","request_id":"10005"}}
                        string strapiid = "0";
                        string strstatus = "0";
                        try
                        {
                            string[] P1 = str6.Split('"');
                            //STATUS = P1[0].ToString();
                            //TRID = P1[1].ToString();
                            //CLIENTID = P1[2].ToString();
                            //MOBILE = P1[3].ToString();
                            //AMOUNT = P1[4].ToString();


                            //strstatus = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                            strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                            // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                            strapiid = P1[7].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                        }
                        catch
                        {
                            strapiid = "0";
                        }

                        if (str6.Contains("SUCCESS"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = strapiid;
                            entity.OperatorRef = str6.Split(new char[] { '"' })[3];
                        }
                        else if (str6.Contains("FAILURE"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.TransactionId = strapiid;
                            entity.OperatorRef = str6.Split(new char[] { '"' })[3];
                            entity.ClosingBal = (entity.OpeningBal);
                        }
                        else
                        {
                            entity.TransactionId = strapiid;
                        }

                    }
                    context.SubmitChanges();
                }


             
                //prem

                else if (api.APIName == "RechApi")
                {
                    string str6 = null;
                    string str7 = entity.Id.ToString();

                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard) || (rechargeType == clsVariables.ServiceType.Gas))
                    {


                        try
                        {
                            str6 = myapihit(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.R4uCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                            //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}
                        }
                        catch { }
                        //}
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str6 = myapihit(api.Apiurl, api.Username, api.Password, "*", getOperator.R4uCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }
                    else if (rechargeType == clsVariables.ServiceType.Electricity)
                    {
                        str6 = elehit(api.Apiurl, api.Username, api.Password, "*", getOperator.R4uCode.ToString(), number, op1, op2, op3, amount.ToString(), entity.Id.ToString());
                    }
                    else if (rechargeType == clsVariables.ServiceType.Insurance)
                    {
                        str6 = elehit(api.Apiurl, api.Username, api.Password, "*", getOperator.R4uCode.ToString(), number, op1.Replace("/", "-"), op2, op3, amount.ToString(), entity.Id.ToString());
                    }
                    entity.Response = str6;
                    entity.OurTransId = str7;
                    context.SubmitChanges();


                    if (str6.Length > 0)
                    {

                        //   Failure,0,10107,826458050,15,Invalid Operator Code
                        // {"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"} 
                        string strapiid = "0";
                        string strstatus = "0";
                        try
                        {
                            string[] P1 = str6.Split('|');
                            //STATUS = P1[0].ToString();
                            //TRID = P1[1].ToString();
                            //CLIENTID = P1[2].ToString();
                            //MOBILE = P1[3].ToString();
                            //AMOUNT = P1[4].ToString();


                            //strstatus = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                            strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                            // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                            strapiid = P1[0].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                        }
                        catch
                        {
                            strapiid = "0";
                        }



                        if (str6.Contains("SUCCESS"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = strapiid;
                            entity.OperatorRef = str6.Split(new char[] { '|' })[4];
                        }
                        else if (str6.Contains("FAILED"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.TransactionId = strapiid;
                            entity.OperatorRef = str6.Split(new char[] { '|' })[4];
                            entity.ClosingBal = (entity.OpeningBal);
                        }
                        else
                        {
                            entity.TransactionId = strapiid;
                        }

                    }
                    context.SubmitChanges();
                }




                else if (api.APIName == clsVariables.RechargeAPI.AnshiTelecom)
                {
                    string str12 = null;
                    string str13 = entity.Id.ToString();
                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        str12 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, state.CircleCode, getOperator.APICode2.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str12 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, "*", getOperator.APICode2.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }
                    entity.Response = str12;
                    entity.OurTransId = str13;
                    context.SubmitChanges();
                    if (str12.Length > 0)
                    {
                        if (str12.StartsWith("1") || str12.Contains("You don't have sufficient balance to recharge"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.ClosingBal = (entity.OpeningBal);
                            entity.TransactionId = str12.Split(new char[] { '|' })[1];
                            entity.OperatorRef = str12.Split(new char[] { '|' })[3];
                        }
                        else if (str12.StartsWith("0"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = str12.Split(new char[] { '|' })[1];
                            entity.OperatorRef = str12.Split(new char[] { '|' })[3];
                        }
                        else
                        {
                            entity.TransactionId = str12.Split(new char[] { '|' })[1];
                        }
                    }
                    context.SubmitChanges();
                }

                else if (api.APIName == clsVariables.RechargeAPI.IndiaCart)
                {
                    string str12 = null;
                    string str13 = entity.Id.ToString();
                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        str12 = clsMethods.sendindiaRequest(api.Apiurl, api.Username, api.Password, state.CircleCode, getOperator.APICode2.ToString(), number, amount.ToString(), entity.Id.ToString(), op1, op2, op3);
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str12 = clsMethods.sendindiaRequest(api.Apiurl, api.Username, api.Password, "*", getOperator.APICode2.ToString(), number, amount.ToString(), entity.Id.ToString(), op1, op2, op3);
                    }
                    entity.Response = str12;
                    entity.OurTransId = str13;
                    context.SubmitChanges();
                    if (str12.Length > 0)
                    {
                        var gettingop = new JavaScriptSerializer().Deserialize<RCRESPONSE>(str12);
                        if (gettingop.RechargeStatus == "Failed")
                           
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.ClosingBal = (entity.OpeningBal);
                            entity.TransactionId = gettingop.TransactionId;
                            entity.OperatorRef = gettingop.OperatorRef;
                        }
                        else if (gettingop.RechargeStatus == "Success")
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = gettingop.TransactionId;
                            entity.OperatorRef = gettingop.OperatorRef;
                        }
                        else
                        {
                            entity.TransactionId = gettingop.TransactionId;
                        }
                    }
                    context.SubmitChanges();
                }
                else if (api.APIName == clsVariables.RechargeAPI.DishTV)
                {
                    string str14 = null;
                    string str15 = entity.Id.ToString();
                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        str14 = clsMethods.sendDTHReq(api.Apiurl, api.Username, api.Password, state.CircleCode, "DT", number, amount.ToString(), entity.Id.ToString());
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str14 = clsMethods.sendDTHReq(api.Apiurl, api.Username, api.Password, "*", "DT", number, amount.ToString(), entity.Id.ToString());
                    }
                    entity.Response = str14;
                    entity.OurTransId = str15;
                    context.SubmitChanges();
                    if (str14.Length > 0)
                    {
                        if (str14.StartsWith("1"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.ClosingBal = (entity.OpeningBal);
                        }
                        else if (str14.StartsWith("0"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.OperatorRef = str14.Split(new char[] { '|' })[1];
                        }
                    }
                    context.SubmitChanges();
                }
                else if (api.APIName == clsVariables.RechargeAPI.TataSky)
                {
                    string str16 = null;
                    string str17 = entity.Id.ToString();
                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        str16 = clsMethods.sendTataReq(api.Apiurl, api.Username, api.Password, state.CircleCode, "TA", number, amount.ToString(), entity.Id.ToString());
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str16 = clsMethods.sendTataReq(api.Apiurl, api.Username, api.Password, "*", "TA", number, amount.ToString(), entity.Id.ToString());
                    }
                    entity.Response = str16;
                    entity.OurTransId = str17;
                    context.SubmitChanges();
                    if (str16.Length > 0)
                    {
                        if (str16.StartsWith("1"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.ClosingBal = (entity.OpeningBal);
                        }
                        else if (str16.StartsWith("0"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.OperatorRef = str16.Split(new char[] { '|' })[1] + " " + str16.Split(new char[] { '|' })[5].Split(new char[] { '.' })[1];
                        }
                    }
                    context.SubmitChanges();
                }
                else if (api.APIName == clsVariables.RechargeAPI.SMSAcharya)
                {
                    string str18 = null;
                    string uniqueId = entity.Id.ToString();
                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.DataCard)) || (rechargeType == clsVariables.ServiceType.Postpaid))
                    {
                        str18 = clsMethods.SMSAcharya(api.Apiurl, api.Username, api.Password, number, amount.ToString(), getOperator.SACode, uniqueId, "12");
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str18 = clsMethods.SMSAcharya(api.Apiurl, api.Username, api.Password, number, amount.ToString(), getOperator.SACode, uniqueId, "*");
                    }
                    entity.Response = str18;
                    entity.OurTransId = uniqueId;
                    context.SubmitChanges();
                    if (str18.Contains("SUCCESS"))
                    {
                        entity.Status = clsVariables.RechargeStatus.Success;
                        entity.TransactionId = str18.Split(new char[] { ',' })[0];
                        entity.OperatorRef = str18.Split(new char[] { ',' })[8];
                    }
                    else if (str18.Contains("FAILURE"))
                    {
                        entity.Status = clsVariables.RechargeStatus.Failure;
                        entity.TransactionId = str18.Split(new char[] { ',' })[2];
                        entity.OperatorRef = str18.Split(new char[] { ',' })[8];
                        entity.ClosingBal = (entity.OpeningBal);
                    }
                    else if (str18.Contains("Pending"))
                    {
                        entity.TransactionId = str18.Split(new char[] { ',' })[0];
                    }
                    context.SubmitChanges();
                }
                else if (api.APIName == clsVariables.RechargeAPI.Suvidha)
                {
                    string str20 = null;
                    string str21 = entity.Id.ToString();
                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        str20 = clsMethods.sendSuvidhaRequest(api.Apiurl, api.Username, api.Password, state.CircleCode, getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str20 = clsMethods.sendSuvidhaRequest(api.Apiurl, api.Username, api.Password, "*", getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }
                    entity.Response = str20;
                    entity.OurTransId = str21;
                    context.SubmitChanges();
                    if (str20.Length > 0)
                    {
                        if (str20.Contains("Failure"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.ClosingBal = (entity.OpeningBal);
                            entity.TransactionId = str20.Split(new char[] { '#' })[0];
                        }
                        else if (str20.Contains("WARNING"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.ClosingBal = (entity.OpeningBal);
                        }
                        else if (str20.Contains("Success"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = str20.Split(new char[] { '#' })[0];
                        }
                        else if (str20.Contains("Pending"))
                        {
                            entity.TransactionId = str20.Split(new char[] { '#' })[0];
                        }
                    }
                    context.SubmitChanges();
                }
                else if (api.APIName == clsVariables.RechargeAPI.AvishaTraders)
                {
                    string str22 = null;
                    string str23 = entity.Id.ToString();
                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        str22 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, state.CircleCode, getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str22 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, "*", getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }
                    entity.Response = str22;
                    entity.OurTransId = str23;
                    context.SubmitChanges();
                    if (str22.Length > 0)
                    {
                        if (str22.StartsWith("2"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.ClosingBal = (entity.OpeningBal);
                            entity.TransactionId = str22.Split(new char[] { '|' })[2];
                        }
                        else if (str22.StartsWith("0"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = str22.Split(new char[] { '|' })[2];
                        }
                        else
                        {
                            entity.TransactionId = str22.Split(new char[] { '|' })[2];
                        }
                    }
                    context.SubmitChanges();
                }
                else if (api.APIName == clsVariables.RechargeAPI.Emoneygroup)
                {
                    string str24 = null;
                    string str25 = entity.Id.ToString();
                    if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
                    {
                        str24 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, state.CircleCode, getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }
                    else if (rechargeType == clsVariables.ServiceType.DTH)
                    {
                        str24 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, "*", getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    }
                    entity.Response = str24;
                    entity.OurTransId = str25;
                    context.SubmitChanges();
                    if (str24.Length > 0)
                    {
                        if (str24.StartsWith("2"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.ClosingBal = (entity.OpeningBal);
                            entity.TransactionId = str24.Split(new char[] { '|' })[2];
                        }
                        else if (str24.StartsWith("0"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = str24.Split(new char[] { '|' })[2];
                        }
                        else
                        {
                            entity.TransactionId = str24.Split(new char[] { '|' })[2];
                        }
                    }
                    context.SubmitChanges();
                }
                else if (api.APIName == clsVariables.RechargeAPI.Mars)
                {
                    string str26 = null;
                    string uniqueKey = clsMethods.GetUniqueKey(8);
                    str26 = clsMethods.sendMarsRequest(api.Apiurl, getOperator.Mars.ToString(), number, amount.ToString(), uniqueKey);
                    entity.Response = str26;
                    entity.OurTransId = uniqueKey;
                    context.SubmitChanges();
                    if ((str26.Length > 0) && !str26.Contains("System.Net.WebException"))
                    {
                        if (str26.Contains("REQUEST ERROR"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Failure;
                            entity.ClosingBal = (entity.OpeningBal);
                            entity.TransactionId = str26.Split(new char[] { '=' })[2].Split(new char[] { ';' })[0].Replace("\r\r", " ").Replace("\r\n", " ").Replace("\r", " ").Replace("\n", " ").Replace("\"", "").Trim();
                        }
                        else if (str26.StartsWith("0"))
                        {
                            entity.Status = clsVariables.RechargeStatus.Success;
                            entity.TransactionId = str26.Split(new char[] { '=' })[2].Replace("\r\r", " ").Replace("\r\n", " ").Replace("\r", " ").Replace("\n", " ").Replace("\"", "").Trim();
                        }
                        else
                        {
                            entity.TransactionId = str26.Split(new char[] { '=' })[2].Replace("\r\r", " ").Replace("\r\n", " ").Replace("\r", " ").Replace("\n", " ").Replace("\"", "").Trim();
                        }
                    }
                    context.SubmitChanges();
                }
                if (rechargeMode == clsVariables.RechargeMode.API)
                {
                    if (entity.Status == clsVariables.RechargeStatus.Failure)
                    {
                        clsMethods.addTrans(-1, entity.Cost, "Recharge failure on number: " + entity.Number + " | " + entity.Amount.ToString(), getUser.Id, userId, clsMethods.getBalance(getUser.Id) + entity.Cost, clsVariables.TransactionType.RechargeFailure, 0L, clsMethods.getBalance(user.Id), clsMethods.getBalance(resellerId) + entity.Cost, resellerId, clsMethods.getABalance(resellerId) + entity.Cost);
                        string json = new JavaScriptSerializer().Serialize(new
                        {
                            TransactionId = entity.TransactionId,
                            ClientId = entity.ClientId.ToString(),
                            RechargeId = entity.Id,
                            RechargeStatus = entity.Status,
                            ResponseStatus = "SUCCESS",
                            Message = "Recharge Failed"
                        });

                        return json;
                    }
                    if (entity.Status == clsVariables.RechargeStatus.Success)
                    {
                        string json = new JavaScriptSerializer().Serialize(new
                        {
                            TransactionId = entity.TransactionId,
                            ClientId = entity.ClientId.ToString(),
                            OperatorRef = entity.OperatorRef,
                            RechargeId = entity.Id,
                            RechargeStatus = entity.Status,
                            ResponseStatus = "SUCCESS",
                            Message = "Recharge Successfully"
                        });

                        return json;
                    }
                    string jsonforpending = new JavaScriptSerializer().Serialize(new
                    {
                        TransactionId = entity.TransactionId,
                        ClientId = entity.ClientId.ToString(),
                        OperatorRef = entity.OperatorRef,
                        RechargeId = entity.Id,
                        RechargeStatus = entity.Status,
                        ResponseStatus = "SUCCESS",
                        Message = "Recharge Pending"
                    });

                    return jsonforpending;
                }
                if (entity.Status == clsVariables.RechargeStatus.Pending)
                {
                    return string.Concat(new object[] { "Recharge request submitted successfully. Recharge Id: ", entity.Id.ToString(), ". Your current balance is: ", clsMethods.getBalance(getUser.Id) });
                }
                if (entity.Status != clsVariables.RechargeStatus.Success)
                {
                    if (entity.Status != clsVariables.RechargeStatus.Failure)
                    {
                        return "";
                    }
                    clsMethods.addTrans(-1, entity.Cost, "Recharge failure on number: " + entity.Number + " | " + entity.Amount.ToString(), getUser.Id, userId, clsMethods.getBalance(getUser.Id) + entity.Cost, clsVariables.TransactionType.RechargeFailure, 0L, clsMethods.getBalance(user.Id), clsMethods.getBalance(resellerId), resellerId, clsMethods.getABalance(resellerId) + entity.Cost);
                    if ((getUser.UserType != clsVariables.UserType.User) && (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.DTH)) || (rechargeType == clsVariables.ServiceType.DataCard)))
                    {
                        clsMethods.removeReferelComm2(getUser.ParentId.Value, entity.APIId.Value, entity.OperatorId.Value, entity.Amount, entity.Number, getUser.Username, user.Id, entity.CommPer.Value, entity.UserId, entity.Id, resellerId);
                    }
                }
                return string.Concat(new object[] { "Your recharge has been ", entity.Status.ToUpper(), ". Your current balance is: ", clsMethods.getBalance(getUser.Id) });
            }
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                string json = new JavaScriptSerializer().Serialize(new
                {
                    ResponseStatus = "FAILURE",
                    Message = "Sorry, Service unavailable"
                });
                return json;
               
            }
            return "Sorry!! Service unavailable 3";
        }
        if (rechargeMode == clsVariables.RechargeMode.API)
        {
            string json = new JavaScriptSerializer().Serialize(new
            {
                ResponseStatus = "FAILURE",
                Message = "Sorry, Contact Service Provider"
            });
            return json;
          
        }
        return "Sorry!! Contact Service Provider 2";
    }
    public static string doRecharge2(string number, string amount, string opeartorcode, string circle, int userId, string rechargeType, string rechargeMode, string op1, string op2, string op3)
    {
        if (Convert.ToDecimal(amount) <= 0M)
        {
            return "Amount is invalid";
        }
        DataClassesDataContext context = new DataClassesDataContext();
        tblOperator getOperator = Queryable.SingleOrDefault<tblOperator>(context.tblOperators, x => x.LongCode == opeartorcode);
        if (getOperator == null)
        {
            return "Sorry!! Contact Service Provider (4)";
        }
        tblMainComp comp = Queryable.Single<tblMainComp>(context.tblMainComps, x => x.Id == getOperator.MainCompId);
        if (comp.Down)
        {
            return (comp.OperatorName + " service currently not available, please try later.");
        }
        tblRecharge recharge = Queryable.FirstOrDefault<tblRecharge>(from x in context.tblRecharges
                                                                     orderby x.RechargeDate descending
                                                                     select x, x => (((((x.Status == clsVariables.RechargeStatus.Success) || (x.Status == clsVariables.RechargeStatus.Pending)) && (x.UserId == userId)) && (x.Amount == Convert.ToDecimal(amount))) && (x.Number == number)) && (x.OperatorId == getOperator.Id));
        if ((recharge != null) && ((recharge == null) || (recharge.RechargeDate.AddMinutes(30.0) >= DateTime.Now)))
        {
            return "Your next recharge will be after 30 minutes on same number with same amount";
        }
        tblUser getUser = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == userId);
        if (!getUser.Status)
        {
            return "User is inactive, please contact administrator";
        }
        bool flag = false;
        int schemeid = 0;
        tblApi api = null;
        int resellerId = 0;
        resellerId = clsMethods.getadminId3(getUser.Id);
        if (resellerId == 0)
        {
            resellerId = clsMethods.getadminId2(getUser.Id);
        }
        tblCommission getCommission = null;
        if (getUser.SchemeId.HasValue)
        {
            getCommission = Queryable.FirstOrDefault<tblCommission>(context.tblCommissions, x => (x.PackageId == getUser.SchemeId) && (x.OperatorId == getOperator.Id));
            if ((getCommission != null) && getCommission.ApiId.HasValue)
            {
                schemeid = getCommission.PackageId;
                api = Queryable.Single<tblApi>(context.tblApis, x => x.Id == ((int)getCommission.ApiId.Value));
            }
        }
        string str = null;
        if (getCommission == null)
        {
            if (resellerId != 0)
            {
                tblUser getReseller = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == resellerId);
                tblCommission getResellerComm = Queryable.SingleOrDefault<tblCommission>(context.tblCommissions, x => (x.PackageId == getReseller.SchemeId) && (x.OperatorId == getOperator.Id));
                if (getResellerComm != null)
                {
                    schemeid = getResellerComm.PackageId;
                    if (getResellerComm.ApiId.HasValue)
                    {
                        api = Queryable.Single<tblApi>(context.tblApis, x => x.Id == ((int)getResellerComm.ApiId.Value));
                    }
                }
            }
            else
            {
                api = context.tblApis.First<tblApi>();
            }
        }
        else
        {
            tblUser getReseller = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == resellerId);
            tblCommission getResellerComm = Queryable.SingleOrDefault<tblCommission>(context.tblCommissions, x => (x.PackageId == getReseller.SchemeId) && (x.OperatorId == getOperator.Id));
            if (getResellerComm != null)
            {
                schemeid = getResellerComm.PackageId;
                if (getResellerComm.ApiId.HasValue)
                {
                    api = Queryable.Single<tblApi>(context.tblApis, x => x.Id == ((int)getResellerComm.ApiId.Value));
                }
            }
        }
        if (Queryable.SingleOrDefault<tblCommPackage>(context.tblCommPackages, x => x.Id == schemeid).Locked)
        {
            flag = true;
        }
        decimal num = clsMethods.getBalance(userId);
        if (num < Convert.ToDecimal(amount))
        {
            return "Insufficient Balance";
        }
        ob ob1 = new ob();
        tblCharge charge = context.tblCharges.Single<tblCharge>(x => x.Type == Convert.ToString("RechargeLimit"));
        decimal numm = clsMethods.getBalance(userId);
        if (numm > 0 && Convert.ToDecimal(amount) <= charge.UserFee)
        {
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                string json = new JavaScriptSerializer().Serialize(new
                {
                    ResponseStatus = "FAILURE",
                    Message = "You Can not Recharge From Your Minimum Balance Limit"
                });

                return json;
            }
            return "You Can't Recharge From Your Minimum Balance Limit";
        }

        tblCharge block = context.tblCharges.Single<tblCharge>(x => x.Type == Convert.ToString("AmountBlock"));
        decimal bcamt = 0;
        if (getUser.UserType == clsVariables.UserType.SuperDistributor)
        {
            bcamt = Convert.ToInt32(block.SD);
        }
        else if (getUser.UserType == clsVariables.UserType.Distributor)
        {
            bcamt = Convert.ToInt32(block.Dist);
        }
        else if (getUser.UserType == clsVariables.UserType.Retailer)
        {
            bcamt = Convert.ToInt32(block.Retailer);
        }
        else
        {
            bcamt = Convert.ToInt32(block.UserFee);
        }

        if (numm > 0 && Convert.ToDecimal(amount) <= bcamt)
        {
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                string json = new JavaScriptSerializer().Serialize(new
                {
                    ResponseStatus = "FAILURE",
                    Message = "You don't have sufficient balance to recharge"
                });

                return json;
            }
            return "Insufficient Balance";
        }
        
        string permission = "";
        try
        {
            permission = ob1.executescalar("select Recharge from tblServicesAuth where UserId = '" + userId + "'");
        }
        catch
        {
            permission = "False";
        }


        if (permission == "False")
        {
            if (rechargeMode == clsVariables.RechargeMode.API)
            {
                return "You Are Not Authorized to use this service";
            }
            return "You Are Not Authorized to use this service";
        }
        if (!flag)
        {
            IQueryable<tblAmountExact> source = from x in context.tblAmountExacts
                                                where (x.OperatorId == getOperator.MainCompId) && x.Status
                                                select x;
            bool flag2 = false;
            if (source.Count<tblAmountExact>() > 0)
            {
                using (IEnumerator<tblAmountExact> enumerator = source.GetEnumerator())
                {
                    tblAmountExact g;
                    while (enumerator.MoveNext())
                    {
                        g = enumerator.Current;
                        string[] strArray = g.Amount.Split(new char[] { ',' });
                        for (int j = 0; j < strArray.Length; j++)
                        {
                            if (Convert.ToDecimal(amount) == Convert.ToDecimal(strArray[j]))
                            {
                                api = Queryable.Single<tblApi>(context.tblApis, x => x.Id == g.APIId);
                                if (api.Id == g.APIId)
                                {
                                    flag2 = true;
                                    continue;
                                }
                            }
                        }
                    }
                }
            }
            if (!flag2)
            {
                IQueryable<tblRangeAmt> queryable2 = from x in context.tblRangeAmts
                                                     where (((Convert.ToDecimal(amount) >= x.MinAmt) && (Convert.ToDecimal(amount) <= x.MaxAmt)) && (x.OperatorId == getOperator.MainCompId)) && x.Status
                                                     select x;
                if (queryable2.Count<tblRangeAmt>() > 0)
                {
                    using (IEnumerator<tblRangeAmt> enumerator2 = queryable2.GetEnumerator())
                    {
                        tblRangeAmt i;
                        while (enumerator2.MoveNext())
                        {
                            i = enumerator2.Current;
                            api = Queryable.Single<tblApi>(context.tblApis, x => x.Id == i.APIId);
                            if (api.Id == i.APIId)
                            {
                                goto Label_1249;
                            }
                        }
                    }
                }
            }
        }
    Label_1249:
        if (api == null)
        {
            return "Sorry!! Contact Service Provider (3)";
        }
        if ((((((api.APIName == clsVariables.RechargeAPI.OnlyRecharge) && (getOperator.ORCode == null)) || ((api.APIName == clsVariables.RechargeAPI.AvishaTraders2) && (getOperator.BonrixCode == null))) || (((api.APIName == clsVariables.RechargeAPI.Suvidha) && (getOperator.RCCode == null)) || ((api.APIName == clsVariables.RechargeAPI.SMSAcharya) && (getOperator.SACode == null)))) || ((((api.APIName == clsVariables.RechargeAPI.Bonrix2) && (getOperator.BonrixCode == null)) || ((api.APIName == clsVariables.RechargeAPI.Emoneygroup) && (getOperator.RCCode == null))) || (((api.APIName == clsVariables.RechargeAPI.AvishaTraders) && (getOperator.RCCode == null)) || ((api.APIName == clsVariables.RechargeAPI.Yahoo1) && (getOperator.ORCode == null))))) || ((((api.APIName == clsVariables.RechargeAPI.Recharge4ushop) && (getOperator.R4uCode == null)) || ((api.APIName == clsVariables.RechargeAPI.Yahoo2) && (getOperator.Yahoo2 == null))) || ((((api.APIName == clsVariables.RechargeAPI.AnshiTelecom) && (getOperator.APICode2 == null)) || ((api.APIName == clsVariables.RechargeAPI.Jolo) && (getOperator.APICode3 == null))) || ((api.APIName == clsVariables.RechargeAPI.Gtalk) && (getOperator.APICode1 == null)))))
        {
            return "Sorry!! Contact Service Provider (1)";
        }
        tblState state = Queryable.SingleOrDefault<tblState>(context.tblStates, x => x.CircleCode == circle);
        if ((state == null) && (rechargeType == clsVariables.ServiceType.Mobile))
        {
            return "Sorry!! Contact Service Provider (2)";
        }
        tblUser user = Queryable.Single<tblUser>(context.tblUsers, x => x.UserType == clsVariables.UserType.Administrator);
        if (resellerId == 0)
        {
            resellerId = clsMethods.getadminId2(getUser.Id);
        }
        tblUser user2 = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == resellerId);
        decimal num3 = 0M;
        if (user2.UserType == clsVariables.UserType.Reseller)
        {
            num3 = clsMethods.getABalance(resellerId);
        }
        else
        {
            num3 = 99999M;
        }
        if (num3 < Convert.ToDecimal(amount))
        {
            return "Sorry!! Service unavailable";
        }

        tblRecharge entity = new tblRecharge
        {
            OperatorId = new short?(getOperator.Id),
            APIId = new short?(api.Id),
            OpeningBal = num,
            Amount = Convert.ToDecimal(amount),
            Number = number,
            BalanceType = str,
            RechargeDate = DateTime.Now,
            Status = clsVariables.RechargeStatus.Pending,
            Optional1 = op1,
            Optional2 = op2,
            Optional3 = op3
        };

          
        if (rechargeType == clsVariables.ServiceType.Electricity)
        {
            ob ob = new ob();

            string getidchargeidd = ob.executescalar("select Id from tblUtilityRange where " + amount + " >= MinAmt AND " + amount + " <= MaxAmt ").ToString();
            string getidchargee = ob.executescalar("select Charge from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
            string gettypechargee = ob.executescalar("select Type from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
            string getutypece = ob.executescalar("select UserType from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
            string gestypece = ob.executescalar("select Service from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
            if (getutypece == user.UserType)
            {
                if (gestypece == clsVariables.ServiceType.Electricity)
                {
                    if (gettypechargee == "Percentage")
                    {
                        entity.Cost = Convert.ToDecimal(amount) + (Convert.ToDecimal(amount) * Convert.ToDecimal(getidchargee) / 100M);
                        entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                    }
                    else
                    {
                        entity.Cost = Convert.ToDecimal(amount) + (Convert.ToDecimal(getidchargee));
                        entity.ClosingBal = (entity.OpeningBal - entity.Cost);

                    }
                }
                else
                {
                    entity.Cost = Convert.ToDecimal(amount);
                    entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                }
            }
            else
            {
                entity.Cost = Convert.ToDecimal(amount);
                entity.ClosingBal = (entity.OpeningBal - entity.Cost);
            }

        }

        else if (rechargeType == clsVariables.ServiceType.Postpaid)
        {

            ob ob = new ob();

            string getidchargeidd = ob.executescalar("select Id from tblUtilityRange where " + amount + " >= MinAmt AND " + amount + " <= MaxAmt ").ToString();
            string getidchargee = ob.executescalar("select Charge from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
            string gettypechargee = ob.executescalar("select Type from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
            string getutypece = ob.executescalar("select UserType from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
            string gestypece = ob.executescalar("select Service from tblUtilityRange where Id='" + getidchargeidd + "'").ToString();
            if (getutypece == user.UserType)
            {
                if (gestypece == clsVariables.ServiceType.Postpaid)
                {
                    if (gettypechargee == "Percentage")
                    {
                        entity.Cost = Convert.ToDecimal(amount) + (Convert.ToDecimal(amount) * Convert.ToDecimal(getidchargee) / 100M);
                        entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                    }
                    else
                    {
                        entity.Cost = Convert.ToDecimal(amount) + (Convert.ToDecimal(getidchargee));
                        entity.ClosingBal = (entity.OpeningBal - entity.Cost);

                    }
                }
                else
                {
                    entity.Cost = Convert.ToDecimal(amount);
                    entity.ClosingBal = (entity.OpeningBal - entity.Cost);
                }
            }
            else
            {
                entity.Cost = Convert.ToDecimal(amount);
                entity.ClosingBal = (entity.OpeningBal - entity.Cost);
            }

        }
        else
        {
            if (getCommission != null)
            {
                entity.Cost = Convert.ToDecimal(amount) - ((Convert.ToDecimal(amount) * getCommission.Percentage) / 100M);
                entity.ClosingBal = (entity.OpeningBal - entity.Cost);
            }
            else
            {
                entity.Cost = Convert.ToDecimal(amount);
                entity.ClosingBal = (entity.OpeningBal - entity.Cost);
            }
        }
        entity.UserId = userId;
        entity.CrUserId = user2.Id;
        entity.DrUserId = userId;
        if ((getCommission != null) && (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.DTH)) || (rechargeType == clsVariables.ServiceType.DataCard)))
        {
            entity.CommAmt = new decimal?((Convert.ToDecimal(amount) * getCommission.Percentage) / 100M);
            entity.CommPer = new decimal?(getCommission.Percentage);
        }
        else
        {
            entity.CommAmt = 0;
            entity.CommPer = 0;
        }
        entity.RechargeMode = rechargeMode;
        entity.ServiceId = new short?(Queryable.Single<tblService>(context.tblServices, x => x.ServiceName == rechargeType).Id);
        entity.TransactionType = clsVariables.TransactionType.Recharge;
        entity.AdminId = new int?(user.Id);
        entity.ResellerId = new int?(resellerId);
        context.tblRecharges.InsertOnSubmit(entity);
        context.SubmitChanges();
        clsMethods.addTrans(userId, entity.Cost, "Recharge done on number: " + entity.Number + " | " + entity.Amount.ToString(), -1, userId, clsMethods.getBalance(getUser.Id) - entity.Cost, clsVariables.TransactionType.Recharge, entity.Id, clsMethods.getBalance(user.Id), clsMethods.getBalance(resellerId), resellerId, clsMethods.getABalance(resellerId) - entity.Cost);
        if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.DTH)) || (rechargeType == clsVariables.ServiceType.DataCard))
        {
            clsMethods.addReferelComm(getUser.ParentId.Value, api.Id, getOperator.Id, entity.Amount, entity.Number, getUser.Username, user.Id, entity.CommPer.Value, entity.UserId, entity.Id, resellerId);
        }

        if (api.APIName == clsVariables.RechargeAPI.OnlyRecharge)
        {
            string str2 = null;
            string clientId = entity.Id.ToString();
            if (rechargeType == clsVariables.ServiceType.Mobile)
            {
                str2 = clsMethods.executeAPI(api.Username, api.Password, state.CircleCode, getOperator.ORCode.ToString(), number, amount, clientId);
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str2 = clsMethods.executeAPI(api.Username, api.Password, "*", getOperator.ORCode.ToString(), number, amount, clientId);
            }
            entity.Response = str2;
            entity.OurTransId = clientId;
            context.SubmitChanges();
            if (str2.StartsWith("0"))
            {
                entity.Status = clsVariables.RechargeStatus.Success;
                entity.TransactionId = str2.Split(new char[] { '|' })[2];
                entity.OperatorRef = str2.Split(new char[] { '|' })[4];
            }
            else if (str2.StartsWith("1"))
            {
                entity.Status = clsVariables.RechargeStatus.Failure;
                entity.TransactionId = str2.Split(new char[] { '|' })[2];
                entity.OperatorRef = str2.Split(new char[] { '|' })[4];
                entity.ClosingBal = (entity.OpeningBal);
            }
            else if (str2.StartsWith("2"))
            {
                entity.TransactionId = str2.Split(new char[] { '|' })[2];
            }
            context.SubmitChanges();
        }
        else if ((api.APIName == clsVariables.RechargeAPI.AvishaTraders2) || (api.APIName == clsVariables.RechargeAPI.Bonrix2))
        {

            string str4 = null;
            string rechargeId = entity.Id.ToString();
            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.DataCard)) || (rechargeType == clsVariables.ServiceType.Postpaid))
            {
                str4 = clsMethods.sendAirnet(api.Apiurl, api.Username, api.Password, getOperator.BonrixCodeType, getOperator.BonrixCode, number, amount.ToString(), rechargeId);
            }
            else if (((rechargeType == clsVariables.ServiceType.DTH) || (rechargeType == clsVariables.ServiceType.Electricity)) || ((rechargeType == clsVariables.ServiceType.Gas) || (rechargeType == clsVariables.ServiceType.Insurance)))
            {
                str4 = clsMethods.sendAirnet(api.Apiurl, api.Username, api.Password, getOperator.BonrixCodeType, getOperator.BonrixCode, number, amount.ToString(), rechargeId);
            }
            entity.Response = str4;
            entity.OurTransId = rechargeId;
            context.SubmitChanges();
            if (str4.Length > 0)
            {
                if (str4.Contains("Success"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = str4.Split(new char[] { ',' })[2].Split(new char[] { ':' })[1];
                    entity.OperatorRef = str4.Split(new char[] { ':' })[4];
                }
                else if (((str4.Contains("fail") || str4.Contains("Mobile number must not be less than 10 digits")) || (str4.Contains("you can't send same Recharge Request for 20 min..") || str4.Contains("You can not recharge with same amount for 30 min(s)"))) || (str4.Contains("Sorry, You do not have Sufficient Balance.") || str4.Contains("Insufficient balance for this Recharge. your balance")))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.ClosingBal = (entity.OpeningBal);
                    if ((!str4.Contains("Mobile number must not be less than 10 digits") && !str4.Contains("you can't send same Recharge Request for 20 min..")) && (!str4.Contains("Sorry, You do not have Sufficient Balance.") && !str4.Contains("Insufficient balance for this Recharge. your balance")))
                    {
                        entity.TransactionId = str4.Split(new char[] { ',' })[2].Split(new char[] { ':' })[1];
                    }
                }
                else
                {
                    entity.TransactionId = str4.Split(new char[] { ',' })[2].Split(new char[] { ':' })[1];
                }
            }
            context.SubmitChanges();
        }
        //prem
        else if (api.APIName == "RechApi")
        {
            string str6 = null;
            string str7 = entity.Id.ToString();

            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                try
                {
                    str6 = myapihit(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.R4uCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}
                }
                catch { }
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str6 = myapihit(api.Apiurl, api.Username, api.Password, "*", getOperator.R4uCode.ToString(), number, amount.ToString(), entity.Id.ToString());
            }
            else if (rechargeType == clsVariables.ServiceType.Electricity)
            {
                str6 = elehit(api.Apiurl, api.Username, api.Password, "*", getOperator.R4uCode.ToString(), number, op1, op2, op3, amount.ToString(), entity.Id.ToString());
            }
            else if (rechargeType == clsVariables.ServiceType.Insurance)
            {
                str6 = elehit(api.Apiurl, api.Username, api.Password, "*", getOperator.R4uCode.ToString(), number, op1.Replace("/", "-"), op2, op3, amount.ToString(), entity.Id.ToString());
            }
            entity.Response = str6;
            entity.OurTransId = str7;
            context.SubmitChanges();


            if (str6.Length > 0)
            {

                string strapiid = "0";
                string strstatus = "0";
                try
                {
                    string[] P1 = str6.Split('|');

                    strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();


                    strapiid = P1[0].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                }
                catch
                {
                    strapiid = "0";
                }



                if (str6.Contains("SUCCESS"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = strapiid;
                    entity.OperatorRef = str6.Split(new char[] { '|' })[4];
                }
                else if (str6.Contains("FAILED"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.TransactionId = strapiid;
                    entity.OperatorRef = str6.Split(new char[] { '|' })[4];
                    entity.ClosingBal = (entity.OpeningBal);
                }
                else
                {
                    entity.TransactionId = strapiid;
                }
            }
            context.SubmitChanges();
        }
        //prem
        else if (api.APIName == "pay1all")
        {
            string str6 = null;
            string str7 = entity.Id.ToString();

            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                try
                {
                    str6 = myapihit(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.PyOpCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}

                }
                catch { }
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str6 = myapihit(api.Apiurl, api.Username, api.Password, "*", getOperator.PyOpCode.ToString(), number, amount.ToString(), entity.Id.ToString());
            }

            entity.Response = str6;
            entity.OurTransId = str7;
            context.SubmitChanges();


            if (str6.Length > 0)
            {

                // {"ERROR":"1","STATUS":"PENDING","MESSAGE":"Recharge Pending","ip":"148.72.64.205","request":{"member_id":"7988604440","api_password":"7988604440","api_pin":"76539","opcode":"184","number":"9466462872","amount":"10","request_id":"10005"}}
                string strapiid = "0";
                string strstatus = "0";
                string scode = "0";
                try
                {
                    string[] P1 = str6.Split('"');
                    //STATUS = P1[0].ToString();
                    //TRID = P1[1].ToString();
                    //CLIENTID = P1[2].ToString();
                    //MOBILE = P1[3].ToString();
                    //AMOUNT = P1[4].ToString();
                    scode = P1[7].ToString();

                    //strstatus = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                    strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                    // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                    strapiid = P1[11].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                }
                catch
                {
                    strapiid = "0";
                }

                if (scode.Contains("1"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = strapiid;
                    entity.OperatorRef = str6.Split(new char[] { '"' })[15];
                }
                else if (scode.Contains("3"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.TransactionId = strapiid;
                    entity.OperatorRef = str6.Split(new char[] { '"' })[15];
                    entity.ClosingBal = (entity.OpeningBal);
                }
                else
                {
                    entity.TransactionId = strapiid;
                }

            }
            context.SubmitChanges();
        }


        //prem
        else if (api.APIName == "cyrus")
        {
            string str6 = null;
            string str7 = entity.Id.ToString();

            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                try
                {
                    str6 = cyrusHit(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.PyOpCode.ToString(), number, amount.ToString(), entity.Id.ToString());
                    //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}
                    //$url = "https://cyrusrecharge.in/api/recharge.aspx?memberid=AP782972&pin=F75C34C5A3&number=".$post->mobile."&operator=".$operator->code1."&circle=".$circle->code."&amount=".$post->amount."&usertx=".$post->txn_id."&format=json";
                }
                catch { }
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str6 = myapihit(api.Apiurl, api.Username, api.Password, "*", getOperator.PyOpCode.ToString(), number, amount.ToString(), entity.Id.ToString());
            }

            entity.Response = str6;
            entity.OurTransId = str7;
            context.SubmitChanges();


            if (str6.Length > 0)
            {

                // {"ERROR":"1","STATUS":"PENDING","MESSAGE":"Recharge Pending","ip":"148.72.64.205","request":{"member_id":"7988604440","api_password":"7988604440","api_pin":"76539","opcode":"184","number":"9466462872","amount":"10","request_id":"10005"}}
                string strapiid = "0";
                string strstatus = "0";
                string scode = "0";
                try
                {
                    string[] P1 = str6.Split('"');
                    //STATUS = P1[0].ToString();
                    //TRID = P1[1].ToString();
                    //CLIENTID = P1[2].ToString();
                    //MOBILE = P1[3].ToString();
                    //AMOUNT = P1[4].ToString();
                    scode = P1[7].ToString();

                    //strstatus = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                    strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                    // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                    strapiid = P1[11].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                }
                catch
                {
                    strapiid = "0";
                }

                if (scode.Contains("1"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = strapiid;
                    entity.OperatorRef = str6.Split(new char[] { '"' })[15];
                }
                else if (scode.Contains("3"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.TransactionId = strapiid;
                    entity.OperatorRef = str6.Split(new char[] { '"' })[15];
                    entity.ClosingBal = (entity.OpeningBal);
                }
                else
                {
                    entity.TransactionId = strapiid;
                }

            }
            context.SubmitChanges();
        }

//prem  
        else if (api.APIName == "mrobo")
        {
            string str6 = null;
            string str7 = entity.Id.ToString();

            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                try
                {
                    str6 = myapihitpost(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.PwProdName.ToString(), number, amount.ToString(), entity.Id.ToString());
                    //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}

                }
                catch { }
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str6 = myapihitpost(api.Apiurl, api.Username, api.Password, "*", getOperator.PwProdName.ToString(), number, amount.ToString(), entity.Id.ToString());
            }

            entity.Response = str6;
            entity.OurTransId = str7;
            context.SubmitChanges();


            if (str6.Length > 0)
            {

                //   Failure,0,10107,826458050,15,Invalid Operator Code
                //{"STATUS":"FAILED","MOBILE":"151218120","AMOUNT":"30","RPID":"","AGENTID":"10000","OPID":"","BAL":3000.0,"MSG":"FAILED! Invalid Amount"}  string strapiid = "0";
                string strapiid = "0";
                string strstatus = "0";
                try
                {
                    string[] P1 = str6.Split('"');
               

                    //strstatus = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                    strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                    // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                    strapiid = P1[18].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                }
                catch
                {
                    strapiid = "0";
                }

                var gettingop = new JavaScriptSerializer().Deserialize<Myopb>(str6);
                if (str6.Contains("success") || str6.Contains("Successfully"))
                {

                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = strapiid.Replace(":", "").Replace(",", "");
                    entity.OperatorRef = gettingop.tnx_id;
                }
                else if (str6.Contains("failed") || str6.Contains("failure"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.TransactionId = strapiid.Replace(":", "").Replace(",", "");
                    entity.OperatorRef = gettingop.tnx_id;
                    entity.ClosingBal = (entity.OpeningBal);
                }
                else
                {
                    entity.TransactionId = strapiid.Replace(":", "").Replace(",", "");
                }

            }
            context.SubmitChanges();
        }
        //prem
        else if (api.APIName == "Champ")
        {
            string str6 = null;
            string str7 = entity.Id.ToString();

            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                try
                {
                    str6 = myapihit(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.APICode1.ToString(), number, amount.ToString(), entity.Id.ToString());
                    //Pending,785,1194436,9662663250,50,REQUEST ACCEPTED 
                }
                catch { }
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str6 = myapihit(api.Apiurl, api.Username, api.Password, "*", getOperator.APICode1.ToString(), number, amount.ToString(), entity.Id.ToString());
            }

            entity.Response = str6;
            entity.OurTransId = str7;
            context.SubmitChanges();


            if (str6.Length > 0)
            {

                // {"ERROR":"1","STATUS":"PENDING","MESSAGE":"Recharge Pending","ip":"148.72.64.205","request":{"member_id":"7988604440","api_password":"7988604440","api_pin":"76539","opcode":"184","number":"9466462872","amount":"10","request_id":"10005"}}
                string strapiid = "0";
                string strstatus = "0";
                try
                {
                    string[] P1 = str6.Split(',');
               

                    //strstatus = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                    strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                    // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                    strapiid = P1[1].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                }
                catch
                {
                    strapiid = "0";
                }

                if (str6.Contains("Success"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = strapiid;
                    entity.OperatorRef = str6.Split(new char[] { ',' })[5];
                }
                else if (str6.Contains("Failure"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.TransactionId = strapiid;
                    entity.OperatorRef = str6.Split(new char[] { ',' })[5];
                    entity.ClosingBal = (entity.OpeningBal);
                }
                else
                {
                    entity.TransactionId = strapiid;
                }

            }
            context.SubmitChanges();
        }
        //prem
        else if (api.APIName == "Skcommunition")
        {
            string str6 = null;
            string str7 = entity.Id.ToString();

            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                try
                {
                    str6 = myapihit(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.PyOpType.ToString(), number, amount.ToString(), entity.Id.ToString());
                    //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}

                }
                catch { }
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str6 = myapihit(api.Apiurl, api.Username, api.Password, "*", getOperator.PyOpType.ToString(), number, amount.ToString(), entity.Id.ToString());
            }

            entity.Response = str6;
            entity.OurTransId = str7;
            context.SubmitChanges();


            if (str6.Length > 0)
            {

                //   Failure,0,10107,826458050,15,Invalid Operator Code
                //{"STATUS":"FAILED","MOBILE":"151218120","AMOUNT":"30","RPID":"","AGENTID":"10000","OPID":"","BAL":3000.0,"MSG":"FAILED! Invalid Amount"}  string strapiid = "0";
                string strapiid = "0";
                string strstatus = "0";
                try
                {
                    string[] P1 = str6.Split('>');
             

                    //strstatus = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                    strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                    // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                    strapiid = P1[16].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                }
                catch
                {
                    strapiid = "0";
                }

                if (str6.Contains("SUCCESS"))
                {

                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = str6.Split(new char[] { '>' })[13].Replace("</field1", "");
                    entity.OperatorRef = str6.Split(new char[] { '>' })[17].Replace("</apirefid", "");
                }
                else if (str6.Contains("FAILED") || str6.Contains("REFUND"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.TransactionId = strapiid.Replace("</apirefid", "");
                    // entity.OperatorRef = str6.Split(new char[] { '"' })[23];
                    entity.ClosingBal = (entity.OpeningBal);
                }
                else
                {
                    entity.TransactionId = strapiid.Replace("</apirefid", "");
                }

            }
            context.SubmitChanges();
        }
        //prem
        else if (api.APIName == "PAYMONEY")
        {
            string str6 = null;
            string str7 = entity.Id.ToString();

            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                try
                {
                    str6 = myapihit(api.Apiurl.ToString(), api.Username.ToString(), api.Password.ToString(), state.CircleCode.ToString(), getOperator.Yahoo2.ToString(), number, amount.ToString(), entity.Id.ToString());
                    //{"STATUS":"PENDING","MOBILE":"8826458050","AMOUNT":"15","RPID":"16070623113083B471","AGENTID":"10085","OPID":"","BAL":75.0,"MSG":"Url Not Set please set the Callback Url"}

                }
                catch { }
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str6 = myapihit(api.Apiurl, api.Username, api.Password, "*", getOperator.Yahoo2.ToString(), number, amount.ToString(), entity.Id.ToString());
            }

            entity.Response = str6;
            entity.OurTransId = str7;
            context.SubmitChanges();


            if (str6.Length > 0)
            {
 string strapiid = "0";
                string strstatus = "0";
                try
                {
                    string[] P1 = str6.Split('"');
                  
                    strstatus = P1[0].ToString(); // strstatus.Split(',')[1].ToString().Split(',')[0].ToString();

                    // strapiid = str6.Replace("\"", "").Replace("{", "").Replace("}", "");
                    strapiid = P1[15].ToString(); //strapiid.Split(':')[4].ToString().Split(',')[0].ToString();
                }
                catch
                {
                    strapiid = "0";
                }

                if (str6.Contains("SUCCESS"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = strapiid;
                    entity.OperatorRef = str6.Split(new char[] { '"' })[23];
                }
                else if (str6.Contains("FAILED"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.TransactionId = strapiid;
                    entity.OperatorRef = str6.Split(new char[] { '"' })[23];
                    entity.ClosingBal = (entity.OpeningBal);
                }
                else
                {
                    entity.TransactionId = strapiid;
                }

            }
            context.SubmitChanges();
        }

        else if (api.APIName == clsVariables.RechargeAPI.AnshiTelecom)
        {
            string str12 = null;
            string str13 = entity.Id.ToString();
            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                str12 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, state.CircleCode, getOperator.APICode2.ToString(), number, amount.ToString(), entity.Id.ToString());
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str12 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, "*", getOperator.APICode2.ToString(), number, amount.ToString(), entity.Id.ToString());
            }
            entity.Response = str12;
            entity.OurTransId = str13;
            context.SubmitChanges();
            if (str12.Length > 0)
            {
                if (str12.StartsWith("1") || str12.Contains("You don't have sufficient balance to recharge"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.ClosingBal = (entity.OpeningBal);
                    entity.TransactionId = str12.Split(new char[] { '|' })[1];
                    entity.OperatorRef = str12.Split(new char[] { '|' })[3];
                }
                else if (str12.StartsWith("0"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = str12.Split(new char[] { '|' })[1];
                    entity.OperatorRef = str12.Split(new char[] { '|' })[3];
                }
                else
                {
                    entity.TransactionId = str12.Split(new char[] { '|' })[1];
                }
            }
            context.SubmitChanges();
        }
        else if (api.APIName == clsVariables.RechargeAPI.DishTV)
        {
            string str14 = null;
            string str15 = entity.Id.ToString();
            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                str14 = clsMethods.sendDTHReq(api.Apiurl, api.Username, api.Password, state.CircleCode, "DT", number, amount.ToString(), entity.Id.ToString());
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str14 = clsMethods.sendDTHReq(api.Apiurl, api.Username, api.Password, "*", "DT", number, amount.ToString(), entity.Id.ToString());
            }
            entity.Response = str14;
            entity.OurTransId = str15;
            context.SubmitChanges();
            if (str14.Length > 0)
            {
                if (str14.StartsWith("1"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.ClosingBal = (entity.OpeningBal);
                }
                else if (str14.StartsWith("0"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.OperatorRef = str14.Split(new char[] { '|' })[1];
                }
            }
            context.SubmitChanges();
        }
        else if (api.APIName == clsVariables.RechargeAPI.TataSky)
        {
            string str16 = null;
            string str17 = entity.Id.ToString();
            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                str16 = clsMethods.sendTataReq(api.Apiurl, api.Username, api.Password, state.CircleCode, "TA", number, amount.ToString(), entity.Id.ToString());
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str16 = clsMethods.sendTataReq(api.Apiurl, api.Username, api.Password, "*", "TA", number, amount.ToString(), entity.Id.ToString());
            }
            entity.Response = str16;
            entity.OurTransId = str17;
            context.SubmitChanges();
            if (str16.Length > 0)
            {
                if (str16.StartsWith("1"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.ClosingBal = (entity.OpeningBal);
                }
                else if (str16.StartsWith("0"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.OperatorRef = str16.Split(new char[] { '|' })[1] + " " + str16.Split(new char[] { '|' })[5].Split(new char[] { '.' })[1];
                }
            }
            context.SubmitChanges();
        }
        else if (api.APIName == clsVariables.RechargeAPI.SMSAcharya)
        {
            string str18 = null;
            string uniqueId = entity.Id.ToString();
            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.DataCard)) || (rechargeType == clsVariables.ServiceType.Postpaid))
            {
                str18 = clsMethods.SMSAcharya(api.Apiurl, api.Username, api.Password, number, amount.ToString(), getOperator.SACode, uniqueId, "12");
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str18 = clsMethods.SMSAcharya(api.Apiurl, api.Username, api.Password, number, amount.ToString(), getOperator.SACode, uniqueId, "*");
            }
            entity.Response = str18;
            entity.OurTransId = uniqueId;
            context.SubmitChanges();
            if (str18.Contains("SUCCESS"))
            {
                entity.Status = clsVariables.RechargeStatus.Success;
                entity.TransactionId = str18.Split(new char[] { ',' })[0];
                entity.OperatorRef = str18.Split(new char[] { ',' })[8];
            }
            else if (str18.Contains("FAILURE"))
            {
                entity.Status = clsVariables.RechargeStatus.Failure;
                entity.TransactionId = str18.Split(new char[] { ',' })[2];
                entity.OperatorRef = str18.Split(new char[] { ',' })[8];
                entity.ClosingBal = (entity.OpeningBal);
            }
            else if (str18.Contains("Pending"))
            {
                entity.TransactionId = str18.Split(new char[] { ',' })[0];
            }
            context.SubmitChanges();
        }
        else if (api.APIName == clsVariables.RechargeAPI.Suvidha)
        {
            string str20 = null;
            string str21 = entity.Id.ToString();
            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                str20 = clsMethods.sendSuvidhaRequest(api.Apiurl, api.Username, api.Password, state.CircleCode, getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str20 = clsMethods.sendSuvidhaRequest(api.Apiurl, api.Username, api.Password, "*", getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
            }
            entity.Response = str20;
            entity.OurTransId = str21;
            context.SubmitChanges();
            if (str20.Length > 0)
            {
                if (str20.Contains("Failure"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.ClosingBal = (entity.OpeningBal);
                    entity.TransactionId = str20.Split(new char[] { '#' })[0];
                }
                else if (str20.Contains("WARNING"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.ClosingBal = (entity.OpeningBal);
                }
                else if (str20.Contains("Success"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = str20.Split(new char[] { '#' })[0];
                }
                else if (str20.Contains("Pending"))
                {
                    entity.TransactionId = str20.Split(new char[] { '#' })[0];
                }
            }
            context.SubmitChanges();
        }
        else if (api.APIName == clsVariables.RechargeAPI.AvishaTraders)
        {
            string str22 = null;
            string str23 = entity.Id.ToString();
            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                str22 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, state.CircleCode, getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str22 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, "*", getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
            }
            entity.Response = str22;
            entity.OurTransId = str23;
            context.SubmitChanges();
            if (str22.Length > 0)
            {
                if (str22.StartsWith("2"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.ClosingBal = (entity.OpeningBal);
                    entity.TransactionId = str22.Split(new char[] { '|' })[2];
                }
                else if (str22.StartsWith("0"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = str22.Split(new char[] { '|' })[2];
                }
                else
                {
                    entity.TransactionId = str22.Split(new char[] { '|' })[2];
                }
            }
            context.SubmitChanges();
        }
        else if (api.APIName == clsVariables.RechargeAPI.Emoneygroup)
        {
            string str24 = null;
            string str25 = entity.Id.ToString();
            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.Postpaid)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                str24 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, state.CircleCode, getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
            }
            else if (rechargeType == clsVariables.ServiceType.DTH)
            {
                str24 = clsMethods.sendShreeRequest(api.Apiurl, api.Username, api.Password, "*", getOperator.RCCode.ToString(), number, amount.ToString(), entity.Id.ToString());
            }
            entity.Response = str24;
            entity.OurTransId = str25;
            context.SubmitChanges();
            if (str24.Length > 0)
            {
                if (str24.StartsWith("2"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.ClosingBal = (entity.OpeningBal);
                    entity.TransactionId = str24.Split(new char[] { '|' })[2];
                }
                else if (str24.StartsWith("0"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = str24.Split(new char[] { '|' })[2];
                }
                else
                {
                    entity.TransactionId = str24.Split(new char[] { '|' })[2];
                }
            }
            context.SubmitChanges();
        }
        else if (api.APIName == clsVariables.RechargeAPI.Mars)
        {
            string str26 = null;
            string uniqueKey = clsMethods.GetUniqueKey(8);
            str26 = clsMethods.sendMarsRequest(api.Apiurl, getOperator.Mars.ToString(), number, amount.ToString(), uniqueKey);
            entity.Response = str26;
            entity.OurTransId = uniqueKey;
            context.SubmitChanges();
            if ((str26.Length > 0) && !str26.Contains("System.Net.WebException"))
            {
                if (str26.Contains("REQUEST ERROR"))
                {
                    entity.Status = clsVariables.RechargeStatus.Failure;
                    entity.ClosingBal = (entity.OpeningBal);
                    entity.TransactionId = str26.Split(new char[] { '=' })[2].Split(new char[] { ';' })[0].Replace("\r\r", " ").Replace("\r\n", " ").Replace("\r", " ").Replace("\n", " ").Replace("\"", "").Trim();
                }
                else if (str26.StartsWith("0"))
                {
                    entity.Status = clsVariables.RechargeStatus.Success;
                    entity.TransactionId = str26.Split(new char[] { '=' })[2].Replace("\r\r", " ").Replace("\r\n", " ").Replace("\r", " ").Replace("\n", " ").Replace("\"", "").Trim();
                }
                else
                {
                    entity.TransactionId = str26.Split(new char[] { '=' })[2].Replace("\r\r", " ").Replace("\r\n", " ").Replace("\r", " ").Replace("\n", " ").Replace("\"", "").Trim();
                }
            }
            context.SubmitChanges();
        }

        if (entity.Status == clsVariables.RechargeStatus.Failure)
        {
            clsMethods.addTrans(-1, entity.Cost, "Recharge failure on number: " + entity.Number + " | " + entity.Amount.ToString(), getUser.Id, userId, clsMethods.getBalance(getUser.Id) + entity.Cost, clsVariables.TransactionType.RechargeFailure, 0L, clsMethods.getBalance(user.Id), clsMethods.getBalance(resellerId), resellerId, clsMethods.getABalance(resellerId) + entity.Cost);
            if (((rechargeType == clsVariables.ServiceType.Mobile) || (rechargeType == clsVariables.ServiceType.DTH)) || (rechargeType == clsVariables.ServiceType.DataCard))
            {
                clsMethods.removeReferelComm2(getUser.ParentId.Value, entity.APIId.Value, entity.OperatorId.Value, entity.Amount, entity.Number, getUser.Username, user.Id, entity.CommPer.Value, entity.UserId, entity.Id, resellerId);
            }
        }
        if (entity.RechargeMode == clsVariables.RechargeMode.GPRS)
        {
            if (entity.Status == clsVariables.RechargeStatus.Pending)
            {
                return string.Concat(new object[] { 
                "Recharge request sent. Operator: ", comp.OperatorName, " ", getOperator.Operator, " | Number: ", entity.Number, " | Amount: ", entity.Amount, " | Cost: ", entity.Cost, " | Recharge Id: ", entity.Id.ToString(), " | Operator Ref.", entity.OperatorRef, " | Old Bal: ", entity.OpeningBal.ToString(),
                " | New Bal: ", clsMethods.getBalance(getUser.Id)
            });
            }
            if (entity.Status == clsVariables.RechargeStatus.Success)
            {
                return string.Concat(new object[] { 
                "Your recharge has been ", entity.Status.ToUpper(), ". Operator: ", comp.OperatorName, " ", getOperator.Operator, " | Number: ", entity.Number, " | Amount: ", entity.Amount, " | Cost: ", entity.Cost, " | Recharge Id: ", entity.Id.ToString(), " | Operator Ref.", entity.OperatorRef,
                " | Old Bal: ", entity.OpeningBal.ToString(), " | New Bal: ", clsMethods.getBalance(getUser.Id)
            });
            }
            if (entity.Status == clsVariables.RechargeStatus.Failure)
            {
                return string.Concat(new object[] { 
                "Your recharge has been ", entity.Status.ToUpper(), ". Operator: ", comp.OperatorName, " ", getOperator.Operator, " | Number: ", entity.Number, " | Amount: ", entity.Amount, " | Cost: ", entity.Cost, " | Recharge Id: ", entity.Id.ToString(), " | Operator Ref.", entity.OperatorRef,
                " | Old Bal: ", entity.OpeningBal.ToString(), " | New Bal: ", clsMethods.getBalance(getUser.Id)
            });
            }
        }
        else if (entity.RechargeMode == clsVariables.RechargeMode.SMS)
        {
            if (entity.Status == clsVariables.RechargeStatus.Pending)
            {
                return string.Concat(new object[] { 
                "Recharge request sent. Operator: ", comp.OperatorName, " ", getOperator.Operator, " | Number: ", entity.Number, " | Amount: ", entity.Amount, " | Cost: ", entity.Cost, " | Recharge Id: ", entity.Id.ToString(), " | Operator Ref.", entity.OperatorRef, " | Old Bal: ", entity.OpeningBal.ToString(),
                " | New Bal: ", clsMethods.getBalance(getUser.Id), ". Thanks."
            });
            }
            if (entity.Status == clsVariables.RechargeStatus.Success)
            {
                return string.Concat(new object[] { 
                "Your recharge has been ", entity.Status.ToUpper(), ". Operator: ", comp.OperatorName, " ", getOperator.Operator, " | Number: ", entity.Number, " | Amount: ", entity.Amount, " | Cost: ", entity.Cost, " | Recharge Id: ", entity.Id.ToString(), " | Operator Ref.", entity.OperatorRef,
                " | Old Bal: ", entity.OpeningBal.ToString(), " | New Bal: ", clsMethods.getBalance(getUser.Id), ". Thanks."
            });
            }
            if (entity.Status == clsVariables.RechargeStatus.Failure)
            {
                return string.Concat(new object[] { 
                "Your recharge has been ", entity.Status.ToUpper(), ". Operator: ", comp.OperatorName, " ", getOperator.Operator, " | Number: ", entity.Number, " | Amount: ", entity.Amount, " | Cost: ", entity.Cost, " | Recharge Id: ", entity.Id.ToString(), " | Operator Ref.", entity.OperatorRef,
                " | Old Bal: ", entity.OpeningBal.ToString(), " | New Bal: ", clsMethods.getBalance(getUser.Id), ". Thanks."
            });
            }
        }
        return "";
    }
    //===============================================AREA OF RECHARGE============================================
    public static string myapihitpost(string apiUrl, string UserName, string password, string circlecode, string operatorcode, string number, string amount, string clientId)
    {
        ob ob1 = new ob();
        string maxid = ob1.executescalar("select max(id)  from tblRecharge").ToString();

        string requestUriString = apiUrl + "api/recharge";
        string str4;
        HttpWebRequest requestt = null;
        HttpWebResponse responsee = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        DataClassesDataContext context = new DataClassesDataContext();
        string stvwala = "false";
        string oprcodee = operatorcode;
        if (operatorcode == "44")
        {
            stvwala = "true";
            oprcodee = "4";
        }
        else if (operatorcode == "100")
        {
            stvwala = "true";
            oprcodee = "10";
        }
        else
        {
            stvwala = "false";
        }

        try
        {
            using (WebClient client = new WebClient())
            {
                NameValueCollection postData = new NameValueCollection() 
       { 
            { "api_token", UserName },   
               { "mobile_no", number }, 
                { "amount", amount }, 
                 { "company_id", oprcodee },  
                  { "order_id", maxid },  
                   { "is_stv", stvwala } 
       };

                // client.UploadValues returns page's source as byte array (byte[])
                // so it must be transformed into a string
                string pagesource = Encoding.UTF8.GetString(client.UploadValues(requestUriString, postData));
                str4 = pagesource;
            }

        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            requestt = null;
            responsee = null;
        }
        return str4;
    }

    public static string cyrusHit(string apiUrl, string userName, string password, string circlecode, string operatorcode, string number, string amount, string clientId){
        
        ob ob1 = new ob();
        string maxid = ob1.executescalar("select max(id)  from tblRecharge").ToString();
        string str33 = string.Empty;
        string strrrs = "https://cyrusrecharge.in/api/recharge.aspx?memberid=AP782972&pin=F75C34C5A3&number="+number+"&operator="+operatorcode+"&circle="+circlecode+"&amount="+amount+"&usertx="+maxid+"format=json";
        
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strrrs);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string elehit(string apiUrl, string UserName, string password, string circlecode, string operatorcode, string number, string opvalue1, string opvalue2, string opvalue3, string amount, string clientId)
    {

        ob ob1 = new ob();
        string maxid = ob1.executescalar("select max(id)  from tblRecharge").ToString();

        string path = apiUrl;
        string APIUID = "<UID>";
        string PASSWORD = "<PWD>";
        string OPR = "<OPRCODE>";
        string MOB = "<MOB>";
        string AMT = "<AMT>";
        string TXN = "<TXNID>";
        string OPVALUEE = "<OPV>";

        path = path.Replace(APIUID, UserName).Replace(PASSWORD, password).Replace(OPR, operatorcode).Replace(MOB, number).Replace(AMT, amount).Replace(TXN, maxid) + opvalue1;

        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(path);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string myapihit(string apiUrl, string UserName, string password, string circlecode, string operatorcode, string number, string amount, string clientId)
    {

        ob ob1 = new ob();
        string maxid = ob1.executescalar("select max(id)  from tblRecharge").ToString();

        string path = apiUrl;
        string APIUID = "<UID>";
        string PASSWORD = "<PWD>";
        string OPR = "<OPRCODE>";
        string MOB = "<MOB>";
        string AMT = "<AMT>";
        string TXN = "<TXNID>";
      
        path = path.Replace(APIUID, UserName).Replace(PASSWORD, password).Replace(OPR, operatorcode).Replace(MOB, number).Replace(AMT, amount).Replace(TXN, maxid);
       
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(path);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public class Myopb
    {


        public string tnx_id { get; set; }
    }
    public class RCRESPONSE
    {
        public string TransactionId { get; set; }
        public string ClientId { get; set; }
        public string OperatorRef { get; set; }
        public int RechargeId { get; set; }
        public string RechargeStatus { get; set; }
        public string ResponseStatus { get; set; }
        public string Message { get; set; }
    }
   
    public static string encryptforEuronet(string pin)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(pin);
        string s = "abcd8683mhary9512";
        MD5CryptoServiceProvider provider = new MD5CryptoServiceProvider();
        byte[] buffer = provider.ComputeHash(Encoding.UTF8.GetBytes(s));
        provider.Clear();
        TripleDESCryptoServiceProvider provider2 = new TripleDESCryptoServiceProvider
        {
            Key = buffer,
            Mode = CipherMode.ECB,
            Padding = PaddingMode.PKCS7
        };
        byte[] inArray = provider2.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length);
        provider2.Clear();
        return Convert.ToBase64String(inArray, 0, inArray.Length);
    }

    public static string euroNet(string refNo, string merchangeCode, string Username, string Password, string paymentProvider, string paymentMode, string channelCode, string serviceCode, string consumerNo, string amount, string storeCode, string terminalCode, string customerId, string spCode, string sspCode, string optional1)
    {
        string str = null;
        string str2 = "https://invas01.euronetworldwide.com/vasrecharge/process.aspx?";
        if (sspCode == null)
        {
            str = encryptforEuronet("merchantrefno=" + refNo + "&merchantcode=" + merchangeCode + "&username=" + Username + "&userpass=" + Password + "&paymentprovider=" + paymentProvider + "&paymentmode=" + paymentMode + "&channelcode=" + channelCode + "&servicecode=" + serviceCode + "&consumerno=" + consumerNo + "&amount=" + amount + "&storecode=" + storeCode + "&terminalcode=" + terminalCode + "&customerid=" + customerId + "&tcflag=1&spcode=" + spCode + "&optional1=" + optional1);
        }
        else
        {
            str = encryptforEuronet("merchantrefno=" + refNo + "&merchantcode=" + merchangeCode + "&username=" + Username + "&userpass=" + Password + "&paymentprovider=" + paymentProvider + "&paymentmode=" + paymentMode + "&channelcode=" + channelCode + "&servicecode=" + serviceCode + "&consumerno=" + consumerNo + "&amount=" + amount + "&storecode=" + storeCode + "&terminalcode=" + terminalCode + "&customerid=" + customerId + "&tcflag=1&spcode=" + spCode + "&Sspcode=" + sspCode + "&optional1=" + optional1);
        }
        string str3 = "merchantrefno=" + refNo + "&merchantcode=SMP&RequestType=service&MSG=" + str;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str2 + str3);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            string str4 = new StreamReader(response.GetResponseStream()).ReadToEnd();
            return decryptforEuronet(str4.Substring(str4.IndexOf("MSG=") + "MSG=".Length, (str4.Length - str4.IndexOf("MSG=")) - "MSG=".Length));
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string euronetBalance(string refNo, string merchangeCode, string Username, string Password)
    {
        string str = null;
        string str2 = "https://invas01.euronetworldwide.com/vasrecharge/process.aspx?";
        str = encryptforEuronet("merchantrefno=" + refNo + "&merchantcode=" + merchangeCode + "&username=" + Username + "&userpass=" + Password);
        string str3 = "merchantrefno=" + refNo + "&merchantcode=SMP&RequestType=balance&MSG=" + str;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str2 + str3);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            string str4 = new StreamReader(response.GetResponseStream()).ReadToEnd();
            return decryptforEuronet(str4.Substring(str4.IndexOf("MSG=") + "MSG=".Length, (str4.Length - str4.IndexOf("MSG=")) - "MSG=".Length));
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string euroNetStatus(string refNo, string merchangeCode, string euroTransNo)
    {
        string str = encryptforEuronet("merchantrefno=" + refNo + "&merchantcode=" + merchangeCode + "&enrefno=" + euroTransNo);
        string str2 = "https://invas01.euronetworldwide.com/vasrecharge/process.aspx?";
        string str3 = "merchantrefno=" + refNo + "&merchantcode=SMP&RequestType=status&MSG=" + str;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str2 + str3);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            string str4 = new StreamReader(response.GetResponseStream()).ReadToEnd();
            return decryptforEuronet(str4.Substring(str4.IndexOf("MSG=") + "MSG=".Length, (str4.Length - str4.IndexOf("MSG=")) - "MSG=".Length));
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string executeAllianceAPI(string reseller_id, string reseller_password, string circleid, string operatorid, string number, string amount, string meroid)
    {
        string str4;
        string requestUriString = "http://ww3.allianceapi.com/reseller/FlexiRechargeAPI.php";
        string str2 = "reseller_id=" + reseller_id + "&reseller_pass=" + reseller_password + "&circleid=" + circleid + "&operatorid=" + operatorid + "&mobilenumber=" + number + "&denomination=" + amount + "&meroid=" + meroid;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static string executeAPI(string UserName, string password, string circlecode, string operatorcode, string number, string amount, string clientId)
    {
        string str4;
        string requestUriString = "http://www.atozrecharge.com/RechargeApi/Recharge.aspx";
        string str2 = "Username=" + UserName + "&Password=" + password + "&CircleCode=" + circlecode + "&OperatorCode=" + operatorcode + "&Number=" + number + "&Amount=" + amount + "&ClientId=" + clientId;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static string executeSMSAPI(string username, string password, string number, string message)
    {
        string str = "http://smsidea.co.in/sendsms.aspx?";
        string str2 = "mobile=" + username + "&pass=" + password + "&senderid=RECHRG&to=" + number + "&msg=" + message;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static decimal getABalance(int root)
    {
        new DataClassesDataContext();
        decimal num = 0M;
        using (DataClassesDataContext context = new DataClassesDataContext())
        {
            tblTransaction transaction = (from x in context.tblTransactions
                                          where x.ABalance.HasValue && (x.AdminId == root)
                                          orderby x.Id descending
                                          select x).FirstOrDefault<tblTransaction>();
            if (transaction != null)
            {
                num = transaction.ABalance.Value;
            }
        }
        return num;
    }

    public static int getadminId(int userId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblUser user = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == userId);
        if ((user.UserType != clsVariables.UserType.Reseller) && (user.UserType != clsVariables.UserType.Administrator))
        {
            return getadminId(user.ParentId.Value);
        }
        return user.Id;
    }

    public static int getadminId2(int userId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblUser user = Queryable.SingleOrDefault<tblUser>(context.tblUsers, x => x.Id == userId);
        if (user.UserType != clsVariables.UserType.Administrator)
        {
            return getadminId2(user.ParentId.Value);
        }
        return user.Id;
    }

    public static int getadminId3(int userId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblUser user = Queryable.SingleOrDefault<tblUser>(context.tblUsers, x => x.Id == userId);
        if (user.UserType == clsVariables.UserType.Reseller)
        {
            return user.Id;
        }
        if (!user.ParentId.HasValue)
        {
            return 0;
        }
        return getadminId3(user.ParentId.Value);
    }

    public static string getAllianceBalance(string reseller_id, string reseller_password)
    {
        string str4;
        string requestUriString = "http://ww3.allianceapi.com/reseller/ResellerBalanceAPI.php";
        string str2 = "reseller_id=" + reseller_id + "&reseller_pass=" + reseller_password;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static decimal getBalance(int root)
    {
        decimal balance = 0M;
        using (DataClassesDataContext context = new DataClassesDataContext())
        {
            tblUser user = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == root);
            if (user.UserType == clsVariables.UserType.Administrator)
            {
                tblTransaction transaction = (from x in context.tblTransactions
                                              orderby x.Id descending
                                              select x).FirstOrDefault<tblTransaction>();
                if (transaction != null)
                {
                    balance = transaction.AdminBalance.Value;
                }
                return balance;
            }
            if (user.UserType == clsVariables.UserType.Reseller)
            {
                tblTransaction transaction2 = (from x in context.tblTransactions
                                               where x.Balance2.HasValue && (x.AdminId == root)
                                               orderby x.Id descending
                                               select x).FirstOrDefault<tblTransaction>();
                if (transaction2 != null)
                {
                    balance = transaction2.Balance2.Value;
                }
                return balance;
            }
            tblTransaction transaction3 = (from x in context.tblTransactions
                                           where x.UserId == root
                                           orderby x.Id descending
                                           select x).FirstOrDefault<tblTransaction>();
            if (transaction3 != null)
            {
                balance = transaction3.Balance;
            }
        }
        return balance;
    }

    public static DateTime getDateTime()
    {
        return DateTime.Now.AddHours(12.0).AddMinutes(30.0);
    }

    public static string getFOSBalance(string username, string password)
    {
        string str4;
        string requestUriString = " http://www.freeonlinerechargeapi.com/apiservice.asmx/GetBalance";
        string str2 = "uid=" + username + "&pwd=" + password;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static string getJoloBalance(string apiUrl, string username, string password)
    {
        string str = apiUrl + "api/rechargebalance.php?";
        string str2 = "key=" + username + "&Password=" + password;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string[] getPaymentURL(string URL, string data)
    {
        string requestUriString = URL;
        string str2 = data;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            if (!str3.Contains("ERROR=0"))
            {
                string[] strArray2 = new string[3];
                strArray2[2] = "false";
                return strArray2;
            }
            string str4 = null;
            string str5 = null;
            if (!str3.Contains("AUTHCODE="))
            {
                str5 = str3.Split(new string[] { "TRANSID=" }, StringSplitOptions.None)[1].Split(new string[] { "END" }, StringSplitOptions.None)[0];
            }
            else
            {
                str4 = str3.Split(new string[] { "AUTHCODE=" }, StringSplitOptions.None)[1].Split(new string[] { "END" }, StringSplitOptions.None)[0];
                str5 = str3.Split(new string[] { "TRANSID=" }, StringSplitOptions.None)[1].Split(new string[] { "AUTHCODE" }, StringSplitOptions.None)[0];
            }
            return new string[] { str5, str4, "true" };
        }
        catch (Exception)
        {
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return new string[3];
    }

    public static string getPaytronicBal(string terminalId, DateTime rechargeDate, string hash)
    {
        string str5;
        string str = FormsAuthentication.HashPasswordForStoringInConfigFile(terminalId + rechargeDate.ToString("yyyy/MM/dd HH:mm:ss") + hash, "SHA1");
        string requestUriString = " http://123.108.34.245/Integration/RechargeService";
        string str3 = "OperationType=3&TerminalId=" + terminalId + "&DateTimeStamp=" + rechargeDate.ToString("yyyy/MM/dd HH:mm:ss") + "&Hash=" + str;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str4 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str3);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str4 = reader.ReadToEnd();
            reader.Close();
            str5 = str4;
        }
        catch (Exception exception)
        {
            str5 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str5;
    }

    public static string getPayworldStatus(string client_transid, string transId)
    {
        string str4;
        string requestUriString = "http://220.226.204.98/mainlinkpos/purchase/pw_gettransstatus.php3";
        string str2 = "loginstatus=LIVE&agentid=95&sp_transid=" + transId + "&client_transid=" + client_transid + "&service=FLEXI&appver=3.38";
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static string getRCBalance(string username, string password)
    {
        string str4;
        string requestUriString = "http://www.atozrecharge.com/RechargeApi/Balance.aspx";
        string str2 = "Username=" + username + "&Password=" + password;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static string getShreeBalance(string apiurl, string username, string password)
    {
        string str4;
        string requestUriString = apiurl + "rechargeApi/Balance.aspx";
        string str2 = "Username=" + username + "&Password=" + password;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }
    public static string getindiaBalance(string apiurl, string username, string password)
    {
        string str4;
        string requestUriString = apiurl + "rechargeApi/Balance.aspx";
        string str2 = "Username=" + username + "&Password=" + password;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }
    public static int getSMSCredit(int userId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblUser user = Queryable.SingleOrDefault<tblUser>(context.tblUsers, x => x.Id == userId);
        if ((user != null) && user.SMS.HasValue)
        {
            return user.SMS.Value;
        }
        return 0;
    }

    public static string getStatusAlliance(string reseller_id, string reseller_password, string orderId, string merchantId)
    {
        StringBuilder builder = new StringBuilder();
        byte[] buffer = new byte[0x2000];
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://ww3.allianceapi.com/reseller/RechargeStatusAPI.php?reseller_id=" + reseller_id + "&reseller_pass=" + reseller_password + "&orderid=" + orderId + "&meroid=" + merchantId);
        Stream responseStream = ((HttpWebResponse)request.GetResponse()).GetResponseStream();
        string str = null;
        int count = 0;
        do
        {
            count = responseStream.Read(buffer, 0, buffer.Length);
            if (count != 0)
            {
                str = Encoding.ASCII.GetString(buffer, 0, count);
                builder.Append(str);
            }
        }
        while (count > 0);
        return builder.ToString();
    }

    public static string[] getStatusURL(string URL, string data, string[] previousResult)
    {
        string requestUriString = URL;
        string str2 = data;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            if (!str3.Contains("ERROR=0"))
            {
                string[] strArray2 = new string[4];
                strArray2[0] = "true";
                strArray2[1] = clsVariables.RechargeStatus.Failure;
                return strArray2;
            }
            if (!str3.Contains("RESULT=7"))
            {
                return new string[] { "true", clsVariables.RechargeStatus.Pending, previousResult[0], previousResult[1] };
            }
            return new string[] { "true", clsVariables.RechargeStatus.Success, previousResult[0], previousResult[1] };
        }
        catch (Exception)
        {
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return new string[4];
    }

    public static string getSuvidhaBalance(string apiUrl, string username, string password)
    {
        string str4;
        string requestUriString = apiUrl + "recharge/balance";
        string str2 = "username=" + username + "&pwd=" + password;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static string GetUniqueKey(int length)
    {
        string str = string.Empty;
        while (str.Length < length)
        {
            str = str + Guid.NewGuid().ToString().GetHashCode().ToString("x");
        }
        if ((length <= 0) || (length > str.Length))
        {
            throw new ArgumentException("Length must be between 1 and " + str.Length);
        }
        return str.Substring(0, length);
    }

    public static bool getVerifyURL(string URL, string data)
    {
        string requestUriString = URL;
        string str2 = data;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            if (str3.Contains("ERROR=0"))
            {
                return true;
            }
        }
        catch (Exception)
        {
            return false;
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return false;
    }

    public static string PayworldBalance()
    {
        string str4;
        string requestUriString = "http://220.226.204.98/mainlinkpos/purchase/pw_query.php3";
        string str2 = "loginstatus=LIVE&agentid=95&query=balance&appver=3.38";
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static string PayworldTransactions(string query, string service, string report, string fromdate, string todate)
    {
        string str4;
        string requestUriString = "http://220.226.204.98/mainlinkpos/purchase/pw_query.php3";
        string str2 = "loginstatus=LIVE&agentid=95&query=" + query + "&rtype=" + report + "&service=" + service + "&fromdate=" + fromdate + "&todate=" + todate + "&appver=3.38";
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static void removeABalance(int userId, decimal amount, int RefId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblAPIBalance balance = Queryable.SingleOrDefault<tblAPIBalance>(context.tblAPIBalances, x => x.UserId == userId);
        if (balance != null)
        {
            balance.Balance -= amount;
            context.SubmitChanges();
            tblApiBalHistory entity = new tblApiBalHistory
            {
                UserId = userId,
                TransType = clsVariables.TransactionType.Debit,
                Amount = amount,
                TransId = new int?(RefId),
                AddDate = DateTime.Now
            };
            context.tblApiBalHistories.InsertOnSubmit(entity);
            context.SubmitChanges();
        }
    }

    public static void removeReferelComm(int parentId, int apiId, int opeeratorId, decimal amount, string number, string username, int adminId, decimal commPer, int userId, long rechargeId, int resellerId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblUser getUser = Queryable.SingleOrDefault<tblUser>(context.tblUsers, x => (x.Id == parentId) && (x.UserType != clsVariables.UserType.Administrator));
        if (getUser != null)
        {
            decimal num = 0M;
            tblCommission commission = Queryable.SingleOrDefault<tblCommission>(context.tblCommissions, x => (x.PackageId == getUser.SchemeId) && (x.OperatorId == opeeratorId));
            if (commission != null)
            {
                num = commission.Percentage - commPer;
                decimal cost = (amount * num) / 100M;
                addTrans(getUser.Id, cost, string.Concat(new object[] { "Recharge Commission reverted of recharge failure on number ", number, " | amt ", amount, " username ", username }), adminId, getUser.Id, getBalance(getUser.Id) - cost, clsVariables.TransactionType.RechargeCommFailure, rechargeId, userId, getBalance(adminId), resellerId, getABalance(resellerId) - cost);
            }
            if (getUser.ParentId.HasValue)
            {
                removeReferelComm(getUser.ParentId.Value, apiId, opeeratorId, amount, number, username, adminId, (commission != null) ? commission.Percentage : 0M, userId, rechargeId, resellerId);
            }
        }
    }

    public static void removeReferelComm2(int parentId, int apiId, int opeeratorId, decimal amount, string number, string username, int adminId, decimal commPer, int userId, long rechargeId, int resellerId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblUser getUser = Queryable.SingleOrDefault<tblUser>(context.tblUsers, x => (x.Id == parentId) && (x.UserType != clsVariables.UserType.Administrator));
        if (getUser != null)
        {
            decimal num = 0M;
            tblCommission commission = Queryable.SingleOrDefault<tblCommission>(context.tblCommissions, x => (x.PackageId == getUser.SchemeId) && (x.OperatorId == opeeratorId));
            if (commission != null)
            {
                num = commission.Percentage - commPer;
                decimal cost = (amount * num) / 100M;
                addTrans(getUser.Id, cost, string.Concat(new object[] { "Recharge Commission reverted of recharge failure on number ", number, " | amt ", amount, " username ", username }), adminId, getUser.Id, getBalance(getUser.Id) - cost, clsVariables.TransactionType.RechargeCommRevert, rechargeId, userId, getBalance(adminId), getBalance(resellerId), resellerId, getABalance(resellerId) - cost);
            }
            if (getUser.ParentId.HasValue)
            {
                removeReferelComm2(getUser.ParentId.Value, apiId, opeeratorId, amount, number, username, adminId, (commission != null) ? commission.Percentage : 0M, userId, rechargeId, resellerId);
            }
        }
    }

    public static void sendAccountEmail(string memberId, string emailId, string password)
    {
        try
        {
            string from = "";
            string to = "";
            string cc = "";
            string subject = "";
            string body = "";
            string attachedFiles = "";
            from = clsVariables.MailSetting.FromEmail;
            to = emailId;
            subject = "Welcome to Airsimlive";
            StringBuilder builder = new StringBuilder();
            builder.Append("<html><head><title>Account Details</title></head><body><form id=\"form1\" name=\"form1\" method=\"post\" action=\"\"><table width=\"100%\" bgcolor=\"#EFEFEF\" border=\"0\" cellspacing=\"10\" cellpadding=\"10\"><tr><td><img src=\"{images/logo.png\" /><hr/></td></tr><tr><td><table><tr><td><h3>Your Account Credentials</h3></td></tr><tr><td><b>Username: </b></td><td>" + memberId + "</td></tr><tr><td><b>Password: </b></td><td>" + password + "</td></tr></table></td></tr><tr><td align=\"right\"><hr/><h3>AIRSIMLIVE</h3><br/><br/><b>Help Line: </b>+91 9040466046<br/><b>Email: </b><a href=\"mailto:care@airsimlive.com\">care@airsimlive.com</a><br/><b>Web: </b><a href=\"http://www.airsimlive.com/\" target=\"_blank\">www.airsimlive.com</a></td></tr></table></form></body></html>");
            body = builder.ToString();
            emailClass.SendEmail(from, to, cc, subject, body, attachedFiles);
        }
        catch (Exception)
        {
        }
    }

    public static string sendAirnet(string apiurl, string username, string password, string rechargetype, string operatorCode, string mobile, string amount, string rechargeId)
    {
        string str = apiurl + "?";
        string str2 = "Mob=" + username + "&message=" + rechargetype + "+" + operatorCode + "+" + mobile + "+" + amount + "+" + password + "&myTxId=" + rechargeId + "&source=API";
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string sendDoveSMS(string number, string message, string username, string password, string senderId)
    {
        string str = "http://dndopen.dove-sms.com/TransSMS/SMSAPI.jsp?";
        string str2 = "username=" + username + "&password=" + password + "&sendername=" + senderId + "&mobileno=" + number + "&message=" + message;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string sendDTHReq(string apiurl, string username, string password, string rechargetype, string operatorCode, string mobile, string amount, string rechargeId)
    {
        string str = apiurl + "api/index.php?";
        string str2 = "username=" + username + "&password=" + password + "&number=" + mobile + "&amount=" + amount + "&operatorcode=" + operatorCode;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static void sendForgotAccountEmail(string memberId, string emailId, string password)
    {
        try
        {
            string from = "";
            string to = "";
            string cc = "";
            string subject = "";
            string body = "";
            string attachedFiles = "";
            from = clsVariables.MailSetting.FromEmail;
            to = emailId;
            subject = "Airsimlive - Forgot password details";
            StringBuilder builder = new StringBuilder();
            builder.Append("<html><head><title>Forgot Account Details</title></head><body><form id=\"form1\" name=\"form1\" method=\"post\" action=\"\"><table width=\"100%\" bgcolor=\"#EFEFEF\" border=\"0\" cellspacing=\"10\" cellpadding=\"10\"><tr><td><img src=\"{images/logo.png\" /><hr/></td></tr><tr><td><table><tr><td><h3>Your New Account Credentials</h3></td></tr><tr><td><b>Username: </b></td><td>" + memberId + "</td></tr><tr><td><b>New Password: </b></td><td>" + password + "</td></tr></td></tr></table><tr><td align=\"right\"><hr/><h3>RECHARGETOWN</h3><br/><br/><b>Help Line: </b>+91 9040466046<br/><b>Email: </b><a href=\"mailto:care@airsimlive.com\">care@airsimlive.com</a><br/><b>Web: </b><a href=\"http://www.airsimlive.com/\" target=\"_blank\">www.airsimlive.com</a></td></tr></table></form></body></html>");
            body = builder.ToString();
            emailClass.SendEmail(from, to, cc, subject, body, attachedFiles);
        }
        catch (Exception)
        {
        }
    }

    public static string sendFreeRecharge(string username, string password, string mobileno, string operatorcode, string amount, string requestId)
    {
        string str4;
        string requestUriString = "http://www.freeonlinerechargeapi.com/apiservice.asmx/Recharge?";
        string str2 = "uid=" + username + "&pwd=" + password + "&mn=" + mobileno + "&op=" + operatorcode + "&amt=" + amount + "&reqid=" + requestId;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static string sendJolo(string apiUrl, string UserName, string password, string operatorcode, string number, string amount, string clientId)
    {
        string str = apiUrl + "api/recharge_advance.php?";
        string str2 = "mode=1&key=" + UserName + "&operator=" + operatorcode + "&service=" + number + "&amount=" + amount + "&orderid=" + clientId;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string sendMarsRequest(string apiUrl, string operatorcode, string number, string amount, string clientId)
    {
        string str = apiUrl + "/MARSrequest/";
        string str2 = "?operator=" + operatorcode + "&number=" + number + "&amount=" + amount + "&reqref=" + clientId;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string sendPaytronicRequest(string terminalId, string operatorCode, string circleCode, string mobile, string amount, string serviceType, string transId, DateTime rechargeDate, string hash)
    {
        string str6;
        string str = operatorCode + "|" + circleCode + "|" + mobile + "|" + amount + "|" + serviceType;
        string str2 = FormsAuthentication.HashPasswordForStoringInConfigFile(terminalId + transId + str + rechargeDate.ToString("yyyy/MM/dd HH:mm:ss") + hash, "SHA1");
        string requestUriString = " http://123.108.34.245/Integration/RechargeService";
        string str4 = "OperationType=" + serviceType + "&TerminalId=" + terminalId + "&TransactionId=" + transId + "&DateTimeStamp=" + rechargeDate.ToString("yyyy/MM/dd HH:mm:ss") + "&Message=" + str + "&Hash=" + str2;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str5 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str4);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str5 = reader.ReadToEnd();
            reader.Close();
            str6 = str5;
        }
        catch (Exception exception)
        {
            str6 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str6;
    }
    public static string sendResponseURL(string ResponseURL, string operatorref, string transid, string status, string clientId)
    {
        string str = ResponseURL;
        string str2 = "?ClientId=" + clientId + "&OperatorRef=" + operatorref + "&TransactionId=" + transid + "&Status=" + status;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }
    public static string sendPayWorldRequest(string retailerId, string transId, string operatorCode, string circleCode, string product, string denomination, string number, string custId, string amount)
    {
        string str4;
        string requestUriString = "http://220.226.204.98/mainlinkpos/purchase/pw_etrans.php3";
        string str2 = "loginstatus=LIVE&agentid=95&retailerid=" + retailerId + "&transid=" + transId + "&operatorcode=" + operatorCode + "&circode=" + circleCode + "&product=" + product + "&denomination=" + denomination + "&mobileno=" + number + "&custid=" + custId + "&recharge=" + amount + "&appver=3.38";
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static string sendRequest(string url, string message)
    {
        string str4;
        string requestUriString = url;
        string str2 = "Message=" + message;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static string sendSAreq(string number, string message, string username, string password, string senderId, string templateId)
    {
        string requestUriString = "http://saralseva.net/api/sms.php?uid=" + username + "&pin=" + password + "&sender=" + senderId + "&route=5&mobile=" + number + "&message=" + message + "&pushid=1&tempid=" + templateId;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(requestUriString);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string sendShreeRequest(string apiUrl, string UserName, string password, string circlecode, string operatorcode, string number, string amount, string clientId)
    {
        string str = apiUrl + "rechargeApi/Recharge.aspx";
        string str2 = "?Username=" + UserName + "&Password=" + password + "&CircleCode=" + circlecode + "&OperatorCode=" + operatorcode + "&Number=" + number + "&Amount=" + amount + "&ClientId=" + clientId + "&ServerNo=1";
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }
    public static string sendindiaRequest(string apiUrl, string UserName, string password, string circlecode, string operatorcode, string number, string amount, string clientId, string opvalue1, string opvalue2, string opvalue3)
    {
        string str = apiUrl + "rechargeApi/Recharge.aspx";
        string str2 = "?Username=" + UserName + "&Password=" + password + "&CircleCode=" + circlecode + "&OperatorCode=" + operatorcode + "&Number=" + number + "&Amount=" + amount + "&ClientId=" + clientId + "&Opvalue1=" + opvalue1 + "&Opvalue2=" + opvalue2 + "&Opvalue3=" + opvalue3;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string sendSMS(string number, string message, string templateno)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblSMSApi api = Queryable.SingleOrDefault<tblSMSApi>(context.tblSMSApis, x => x.Status);
        if (api != null)
        {
            string requestUriString = api.Url.Replace("<Mobile>", number).Replace("<Message>", message).Replace("<TemplateNo>", templateno);
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(requestUriString);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                return reader.ReadToEnd();
            }
            catch (Exception exception)
            {
                return exception.ToString();
            }
        }
        return "SMS Configuration Error!!";
    }

    public static string sendSMS(string username, string password, string number, string message)
    {
        string str = "http://www.smsidea.co.in/sendsms.aspx?";
        string str2 = "mobile=" + username + "&pass=" + password + "&senderid=ALLIIN&to=" + number + "&msg=" + message;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string JMDBalance(string apiurl, string username, string password)
    {
        string str = "http://epaymoney.co.in/API/APIService.aspx?";
        string str2 = "userid=" + username + "&pass=" + password + "&get=CB&fmt=json";
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }
    public static string sendSMS2(string number, string message, string username, string password, string senderId)
    {
        string str = "http://sms.shreerecharge.com/sendsms.php?";
        string str2 = "username=" + username + "&password=" + password + "&sendername=" + senderId + "&phone=" + number + "&msg=" + message;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string sendSMS3(string number, string message, string username, string password, string senderId)
    {
        string str = "http://sms.shreerecharge.com/sendsms.php?";
        string str2 = "username=" + username + "&password=" + password + "&senderid=" + senderId + "&mobileno=" + number + "&message=" + message;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string sendSMS4(string number, string message, string username, string password, string senderId)
    {
        string str = "http://144.76.180.44/WebSMS/SMSAPI.jsp?";
        string str2 = "username=" + username + "&password=" + password + "&sendername=" + senderId + "&mobileno=" + number + "&message=" + message;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string sendSuvidhaRequest(string apiUrl, string UserName, string password, string circlecode, string operatorcode, string number, string amount, string clientId)
    {
        string str = apiUrl + "recharge/api";
        string str2 = "?username=" + UserName + "&pwd=" + password + "&circlecode=" + circlecode + "&operatorcode=" + operatorcode + "&number=" + number + "&amount=" + amount + "&client_id=" + clientId;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }
    public static string sendTataReq(string apiurl, string username, string password, string rechargetype, string operatorCode, string mobile, string amount, string rechargeId)
    {
        string str = apiurl + "tata/index.php?";
        string str2 = "username=" + username + "&password=" + password + "&number=" + mobile + "&amount=" + amount + "&operatorcode=" + operatorCode;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }

    public static string setLeftStr(string source, int pos)
    {
        string str = "";
        for (int i = 0; i < pos; i++)
        {
            str = str + source[i];
        }
        return str;
    }

    public static string SMSAcharya(string apiurl, string username, string password, string number, string amount, string opcode, string uniqueId, string circleCode)
    {
        string str4;
        string requestUriString = apiurl + "api/recharge.php";
        string str2 = "uid=" + username + "&pin=" + password + "&number=" + number + "&circle=" + circleCode + "&operator=" + opcode + "&amount=" + amount + "&version=4";
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    public static string SMSAcharyaBalance(string apiurl, string username, string password)
    {
        string str4;
        string requestUriString = apiurl + "api/balance.php";
        string str2 = "uid=" + username + "&pin=" + password + "&route=recharge";
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }

    //http://login.prechaarge.in/api/ApiServices/GetService?mobileno=Username&message=operatorcode[Space]Number[Space]amount&Password= password&Tranref=UniqueID
    public static string Prechaarge(string apiurl, string username, string password, string number, string amount, string opcode, string uniqueId)
    {
        string str4;
        string requestUriString = "http://login.prechaarge.in/api/ApiServices/GetService?";
        string str2 = "mobileno=" + username + "&message=" + opcode + " " + number + " " + amount + "&Password=" + password + "&Tranref=" + uniqueId;
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamWriter writer = null;
        StreamReader reader = null;
        try
        {
            string str3 = null;
            request = (HttpWebRequest)WebRequest.Create(requestUriString);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(str2);
            writer.Flush();
            writer.Close();
            response = (HttpWebResponse)request.GetResponse();
            reader = new StreamReader(response.GetResponseStream());
            str3 = reader.ReadToEnd();
            reader.Close();
            str4 = str3;
        }
        catch (Exception exception)
        {
            str4 = exception.ToString();
        }
        finally
        {
            if (writer != null)
            {
                writer.Close();
            }
            if (reader != null)
            {
                reader.Close();
            }
            request = null;
            response = null;
        }
        return str4;
    }
    public static string PrechaargeBalance(string apiurl, string username, string password)
    {
        string str = "http://login.prechaarge.in/api/ApiServices/GetService?";
        string str2 = "mobileno=" + username + "&message=BAL&password=" + password + "&Tranref=UniqueID";
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }
    public static string RechApiBalance(string apiurl, string username, string password)
    {
        string str = "http://api.rechapi.com/bal.php?";
        string str2 = "format=" + username + "&token=" + password;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }
    
    public static string ChamprechargeBalance(string apiurl, string username, string password)
    {
        string str = "http://www.champrecharges.com/api_users/balance?";
        string str2 = "login_id=" + username + "&transaction_password=" + password;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }
    //login_id=#LoginID#&transaction_password=#TRPWD#
    public static string SKBalance(string apiurl, string username, string password)
    {
        string str = "https://www.sk-communication.com/apiservice.asmx/GetBalance?";
        string str2 = "apiToken=" + password;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }
    //login_id=#LoginID#&transaction_password=#TRPWD#
    public static string roboBalance(string apiurl, string username, string password)
    {
        string str = apiurl + "api/operator_balance";

        try
        {
            using (WebClient client = new WebClient())
            {
                NameValueCollection postData = new NameValueCollection() 
       { 
            { "api_token", username }  
               
       };

                // client.UploadValues returns page's source as byte array (byte[])
                // so it must be transformed into a string
                string pagesource = Encoding.UTF8.GetString(client.UploadValues(str, postData));
                return pagesource;
            }
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }


    public static string EZBalance(string apiurl, string username, string password)
    {
        string str = "https://ezulix.in/api/balance.aspx?";
        string str2 = "memberid=" + username + "&pin=" + password;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }
    public static string pay1allBalance(string apiurl, string username, string password)
    {
        string str = "http://www.pay1all.in/api/Balance/RcBalance?";
        string str2 = "apimember_id=" + username + "&api_password=" + password;
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(str + str2);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            return reader.ReadToEnd();
        }
        catch (Exception exception)
        {
            return exception.ToString();
        }
    }
    public static void updateSMSBalanceHistory(int userid, string transType, int smsCount, int crUserId, int drUserId)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        tblUser user = Queryable.SingleOrDefault<tblUser>(context.tblUsers, x => x.Id == userid);
        if (user != null)
        {
            if (transType == clsVariables.TransactionType.Credit)
            {
                user.SMS = new int?(user.SMS.HasValue ? (user.SMS.Value + smsCount) : smsCount);
            }
            else
            {
                user.SMS = new int?(user.SMS.HasValue ? (user.SMS.Value - smsCount) : smsCount);
            }
            context.SubmitChanges();
        }
    }
    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }
  
}

