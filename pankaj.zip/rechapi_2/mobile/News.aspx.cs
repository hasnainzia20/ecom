using System;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
public partial class Default : System.Web.UI.Page
{
	
	SqlConnection con = new SqlConnection();
	SqlCommand cmd = new SqlCommand();
	
	
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
		con.Open();
		cmd.CommandText = "select * from [tblAlerts]";
		cmd.Connection = con;
		SqlDataReader rd = cmd.ExecuteReader();
		while (rd.Read())
		{
			Label1.Text = rd["Alerts"].ToString ();
			
		}	
       this.DataBind();
	   
	   
	   
    }
}