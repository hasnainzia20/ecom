﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;

public partial class mobile_CreditTransfer : Page, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {
        if ((((base.Request.QueryString["UserName"] != null) && (base.Request.QueryString["Password"] != null)) && ((base.Request.QueryString["TransType"] != null) && (base.Request.QueryString["Amount"] != null))) && (base.Request.QueryString["CreditUser"] != null))
        {
            string UserName = base.Request.QueryString["UserName"].ToString();
            string Password = base.Request.QueryString["Password"].ToString();
            string str = base.Request.QueryString["TransType"].ToString();
            string CreditUser = base.Request.QueryString["CreditUser"].ToString();
            decimal cost = Convert.ToDecimal(base.Request.QueryString["Amount"].ToString());
            tblUser user = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == UserName) && (x.Password == Password));
            if (user != null)
            {
                tblUser user2 = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == CreditUser) || (x.Mobile == CreditUser));
                if (user2 != null)
                {
                    int? parentId = user2.ParentId;
                    int id = user.Id;
                    if ((parentId.GetValueOrDefault() == id) && parentId.HasValue)
                    {
                        decimal num2 = clsMethods.getBalance(Convert.ToInt32(user.Id));
                        if ((num2 < cost) && (str == "C"))
                        {
                            base.Response.Write("You don't have sufficient balance to transfer");
                            return;
                        }
                        tblUser user3 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.UserType == clsVariables.UserType.Administrator);
                        decimal num3 = clsMethods.getBalance(Convert.ToInt32(user2.Id));
                        if ((num3 < cost) && (str == "D"))
                        {
                            base.Response.Write("You can't debit amount exceed the available balance");
                            return;
                        }
                        int resellerId = clsMethods.getadminId3(user.Id);
                        switch (str)
                        {
                            case "C":
                            {
                                int num5 = clsMethods.addTrans(user.Id, cost, null, user2.Id, user2.Id, clsMethods.getBalance(user2.Id) + cost, clsVariables.TransactionType.Credit, 0L, clsMethods.getBalance(user3.Id), clsMethods.getBalance(resellerId), resellerId, -1M);
                                clsMethods.addTrans(user.Id, cost, null, user2.Id, user.Id, clsMethods.getBalance(user.Id) - cost, clsVariables.TransactionType.Debit, (long) num5, clsMethods.getBalance(user3.Id), clsMethods.getBalance(resellerId), resellerId, -1M);
                                string message = string.Concat(new object[] { "Dear ", user2.CustName, ",Your Account Has Been Credited with amount.", cost, " and Your Old Bal. is Rs. ", num3.ToString(), " and New Bal. is Rs. ", clsMethods.getBalance(Convert.ToInt32(user2.Id)).ToString("0,0.00"), ". Thanks." });
                                string str3 = string.Concat(new object[] { "Dear ", user.CustName, ",Your Account Has Been Debited with amount.", cost, " and Your Old Bal. is Rs. ", num2.ToString(), " and New Bal. is Rs. ", clsMethods.getBalance(Convert.ToInt32(user.Id)).ToString("0,0.00"), ". Thanks." });
                                clsMethods.sendSMS(user2.Mobile, message, "26794");
                                clsMethods.sendSMS(user.Mobile, str3, "26794");
                                break;
                            }
                            case "D":
                            {
                                int num6 = clsMethods.addTrans(user2.Id, cost, null, user.Id, user2.Id, clsMethods.getBalance(user2.Id) - cost, clsVariables.TransactionType.Debit, 0L, clsMethods.getBalance(user3.Id), clsMethods.getBalance(resellerId), resellerId, -1M);
                                clsMethods.addTrans(user2.Id, cost, null, user.Id, user.Id, clsMethods.getBalance(user.Id) + cost, clsVariables.TransactionType.Credit, (long) num6, clsMethods.getBalance(user3.Id), clsMethods.getBalance(resellerId), resellerId, -1M);
                                string str4 = string.Concat(new object[] { "Dear ", user.CustName, ",Your Account Has Been Credited with amount.", cost, " and Your Old Bal. is Rs. ", num2.ToString(), " and New Bal. is Rs. ", clsMethods.getBalance(Convert.ToInt32(user.Id)).ToString("0,0.00"), ". Thanks." });
                                string str5 = string.Concat(new object[] { "Dear ", user2.CustName, ",Your Account Has Been Debited with amount.", cost, " and Your Old Bal. is Rs. ", num3.ToString(), " and New Bal. is Rs. ", clsMethods.getBalance(Convert.ToInt32(user2.Id)).ToString("0,0.00"), ". Thanks." });
                                clsMethods.sendSMS(user.Mobile, str4, "26794");
                                clsMethods.sendSMS(user2.Mobile, str5, "26794");
                                break;
                            }
                        }
                        base.Response.Write("Credit transfer transaction done successfully");
                        return;
                    }
                }
                base.Response.Write("Credit User doesn't exist");
            }
            else
            {
                base.Response.Write("User doesn't exist");
            }
        }
        else
        {
            base.Response.Write("Parameter missing");
        }
    }

   
}
