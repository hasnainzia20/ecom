﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;

public partial class mobile_ChangePIN : Page, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (((base.Request.QueryString["UserName"] != null) && (base.Request.QueryString["Password"] != null)) && ((base.Request.QueryString["OldPassword"] != null) && (base.Request.QueryString["NewPassword"] != null)))
        {
            string UserName = base.Request.QueryString["UserName"].ToString();
            string Password = base.Request.QueryString["Password"].ToString();
            string str = base.Request.QueryString["OldPassword"].ToString();
            string str2 = base.Request.QueryString["NewPassword"].ToString();
            tblUser user = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == UserName) && (x.Password == Password));
            if (user != null)
            {
                if (user.Password == str)
                {
                    user.Password = str2;
                    this.db.SubmitChanges();
                    base.Response.Write("Your password updated successfully");
                }
                else
                {
                    base.Response.Write("Your old password is incorrect");
                }
            }
            else
            {
                base.Response.Write("User doesn't exist");
            }
        }
        else
        {
            base.Response.Write("Parameter missing");
        }
    }

    
}
