﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;

public partial class mobile_Dispute : Page, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (((base.Request.QueryString["UserName"] != null) && (base.Request.QueryString["Password"] != null)) && ((base.Request.QueryString["TransType"] != null) && (base.Request.QueryString["RechargeId"] != null)))
        {
            string UserName = base.Request.QueryString["UserName"].ToString();
            base.Request.QueryString["Password"].ToString();
            string str = base.Request.QueryString["TransType"].ToString();
            string RechargeId = base.Request.QueryString["RechargeId"].ToString();
            tblUser getUser = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => x.Id.ToString() == UserName);
            if (getUser == null)
            {
                base.Response.Write("User doesn't exist");
            }
            else
            {
                switch (str)
                {
                    case "RD":
                        if (Queryable.SingleOrDefault<tblRecharge>(this.db.tblRecharges, y => (y.Id == Convert.ToInt64(RechargeId)) && (y.UserId == getUser.Id)) != null)
                        {
                            bool flag = false;
                            if ((from x in this.db.tblTickets
                                join y in this.db.tblTicketDetails on x.Id equals y.TicketId 
                                where ((y.TranId == RechargeId) && (x.Status == clsVariables.TicketStatus.InProcess)) && (x.SupportType == clsVariables.TicketType.RechargeDispute)
                                orderby y.ResponseDate descending
                                select x).FirstOrDefault<tblTicket>() == null)
                            {
                                flag = true;
                            }
                            if (flag)
                            {
                                tblTicket entity = new tblTicket {
                                    SupportType = clsVariables.TicketType.RechargeDispute,
                                    Status = clsVariables.TicketStatus.InProcess,
                                    AddDate = DateTime.Now,
                                    UserId = getUser.Id
                                };
                                int num = clsMethods.getadminId3(getUser.Id);
                                if (num == 0)
                                {
                                    num = clsMethods.getadminId2(getUser.Id);
                                }
                                entity.ResellerId = new int?(num);
                                this.db.tblTickets.InsertOnSubmit(entity);
                                this.db.SubmitChanges();
                                tblTicketDetail detail = new tblTicketDetail {
                                    TicketId = entity.Id,
                                    Response = "Please chek the recharge id: " + RechargeId,
                                    TranId = RechargeId,
                                    ResponseDate = DateTime.Now,
                                    UserId = getUser.Id
                                };
                                this.db.tblTicketDetails.InsertOnSubmit(detail);
                                this.db.SubmitChanges();
                                base.Response.Write("Your dispute reported successfully. Thank you");
                                return;
                            }
                            base.Response.Write("You already placed ticket for the same Ref. Id");
                            return;
                        }
                        base.Response.Write("Sorry!, Ref. Id not found");
                        return;

                    case "CD":
                    {
                        tblTicketDetail getDispute = (from x in this.db.tblTicketDetails
                            where (x.TranId == RechargeId) && (x.UserId == getUser.Id)
                            orderby x.ResponseDate descending
                            select x).FirstOrDefault<tblTicketDetail>();
                        if (getDispute != null)
                        {
                            string s = null;
                            int num2 = 1;
                            tblTicket ticket3 = Queryable.SingleOrDefault<tblTicket>(this.db.tblTickets, x => x.Id == getDispute.TicketId);
                            if (ticket3 != null)
                            {
                                object obj2 = s;
                                s = string.Concat(new object[] { obj2, num2, ") Status: ", ticket3.Status, "\nMessage: ", getDispute.Response, "\nSolved date: ", getDispute.ResponseDate, "\n\n" });
                                num2++;
                            }
                            else
                            {
                                s = "No transaction details found";
                            }
                            base.Response.Write(s);
                            return;
                        }
                        base.Response.Write("Sorry!, Ref. Id not found");
                        return;
                    }
                }
            }
        }
        else
        {
            base.Response.Write("Parameter missing");
        }
    }

   
}
