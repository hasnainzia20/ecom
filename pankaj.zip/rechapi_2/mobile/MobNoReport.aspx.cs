﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;

public partial class mobile_MobNoReport : Page, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (((base.Request.QueryString["UserName"] != null) && (base.Request.QueryString["Password"] != null)) && (base.Request.QueryString["Number"] != null))
        {
            string UserName = base.Request.QueryString["UserName"].ToString();
            string Password = base.Request.QueryString["Password"].ToString();
            string Number = base.Request.QueryString["Number"].ToString();
            tblUser UserId = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == UserName) && (x.Password == Password));
            if (UserId != null)
            {
                var source = (from x in this.db.tblRecharges
                    join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id 
                    join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id 
                    where (x.UserId == UserId.Id) && (x.Number == Number)
                    let Name1 = z.OperatorName
                    orderby x.RechargeDate descending
                    select new { 
                        Id = x.Id,
                        CompanyName = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                        Amount = x.Amount,
                        Date = x.RechargeDate,
                        Status = x.Status,
                        Number = x.Number,
                        RechargeId = x.Id
                    }).Skip(0).Take(10);
                string s = "<Recharges>";
                if (source.Count() > 0)
                {
                    foreach (var type in source.ToList())
                    {
                        object obj2 = s;
                        s = string.Concat(new object[] { obj2, "<Recharge><RechargeId>", type.RechargeId, "</RechargeId><Company>", type.CompanyName, "</Company><Amount>", type.Amount.ToString("0,0.00"), "</Amount><RechargeDate>", type.Date.ToString("dd-MM-yyyy hh:mm:ss tt"), "</RechargeDate><Status>", type.Status, "</Status><Number>", type.Number, "</Number></Recharge>" });
                    }
                }
                s = s + "</Recharges>";
                base.Response.Write(s);
            }
            else
            {
                base.Response.Write("User doesn't exist");
            }
        }
    }

 
}
