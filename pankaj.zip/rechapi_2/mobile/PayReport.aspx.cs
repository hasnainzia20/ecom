﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;

public partial  class mobile_api_report : Page, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {
        string username = base.Request.QueryString["UserName"].ToString();
        string password = base.Request.QueryString["Password"].ToString();
        tblUser getUser = Queryable.Single<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == username) && (x.Password == password));
        var source = (from x in this.db.tblTransactions
            join y in this.db.tblUsers on x.UserId equals y.Id 
            where (x.UserId == getUser.Id) && ((x.TransactionType == clsVariables.TransactionType.Credit) || (x.TransactionType == clsVariables.TransactionType.Debit))
            orderby x.AddDate descending
            select new { 
                Id = x.Id,
                Amount = x.Amount,
                Type = x.TransactionType,
                Username = (x.DrUserId == x.UserId) ? (from g in this.db.tblUsers
                    where g.Id == x.CrUserId
                    select new { Name = g.Username }).First().Name : (from g in this.db.tblUsers
                    where g.Id == x.DrUserId
                    select new { Name = g.Username }).First().Name,
                RechargeDate = x.AddDate
            }).Skip(0).Take(10);
        string s = "<Payments>";
        if (source.Count() > 0)
        {
            foreach (var type in source.ToList())
            {
                object obj2 = s;
                s = string.Concat(new object[] { obj2, "<Payment><PaymentId>", type.Id, "</PaymentId><User>", type.Username, "</User><Type>", type.Type, "</Type><Amount>", type.Amount.ToString("0,0.00"), "</Amount><PaymentDate>", type.RechargeDate.ToString("dd-MM-yyyy hh:mm:ss tt"), "</PaymentDate></Payment>" });
            }
        }
        s = s + "</Payments>";
        base.Response.Write(s);
    }

   
}
