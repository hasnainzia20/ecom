﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;
using Newtonsoft.Json;

public partial class apibalance : System.Web.UI.Page
{
    private DataClassesDataContext db = new DataClassesDataContext();


    protected void Page_Load(object sender, EventArgs e)
    {
        string Username = null;
        string Password = null;
        string number = null;
        string acno = null;
        string ifsc = null;
       
        if (base.Request.HttpMethod == "GET")
        {
            Username = base.Request.QueryString["Username"];
            Password = base.Request.QueryString["Password"];
            number = base.Request.QueryString["Number"];
            acno = base.Request.QueryString["AccountNo"];
            ifsc = base.Request.QueryString["IFSC"];
        }
        else if (base.Request.HttpMethod == "POST")
        {
            Username = base.Request.QueryString["Username"];
            Password = base.Request.QueryString["Password"];
            number = base.Request.QueryString["Number"];
            acno = base.Request.QueryString["AccountNo"];
            ifsc = base.Request.QueryString["IFSC"];
        }
        string domain = base.Request.Headers.Get("Host").ToString().Replace("www.", "").Replace("http://", "");
            tblUser getUser = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == Username) && (x.Password == Password));
        if (getUser != null)
        {
          
            try
            {
                int userId2 = getUser.Id;
                tblUser getUser2 = db.tblUsers.Single<tblUser>(x => x.Id == userId2);
                string debit = "Beneficiary Validation Charge A/c: " + acno + "";
                tblUser user3 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.UserType == clsVariables.UserType.Administrator);
                int resellerId = 0;
                resellerId = clsMethods.getadminId3(getUser2.Id);
                if (resellerId == 0)
                {
                    resellerId = clsMethods.getadminId2(getUser2.Id);
                }
                tblUser user2 = db.tblUsers.Single<tblUser>(x => x.Id == resellerId);
                decimal curbal = clsMethods.getBalance(getUser2.Id);
                if (curbal > Convert.ToDecimal(5))
                {
                    string str33 = clsMethods.BeneficiaryValidation(number, acno, ifsc);
                    var gettingop = new JavaScriptSerializer().Deserialize<VALEDI>(str33);
                    if (gettingop.data.resCode == 200)
                    {
                        clsMethods.addTrans(getUser2.Id, Convert.ToDecimal(5), debit.ToString(), getUser2.Id, getUser2.Id, clsMethods.getBalance(getUser2.Id) - Convert.ToDecimal(5), clsVariables.TransactionType.Debit, 0L, clsMethods.getBalance(user3.Id) - Convert.ToDecimal(5), 0M, user2.Id, -1M);
                        DataCall2 response = new DataCall2()
                        {
                            Status = "1",
                            Message = "Beneficiary Validated.",
                            AccountName = gettingop.data.beneficiaryName
                        };
                        Response.Write(JsonConvert.SerializeObject(response));
                   
                    }
                    else
                    {
                        DataCall1 response = new DataCall1()
                        {
                            Status = "0",
                            Message = gettingop.data.resText
                        };
                        Response.Write(JsonConvert.SerializeObject(response));

                    }
                }
                else
                {
                    DataCall1 response = new DataCall1()
                    {
                        Status = "0",
                        Message = "You Can't Validate Beneficiary. Due To Low Balance."
                    };
                    Response.Write(JsonConvert.SerializeObject(response));
                   
                }
            }

            catch (Exception ex)
            {
                base.Response.Write(ex);

            }
        }
        else
        {
            base.Response.Write("User doesn't Exist");
        }
    }

    public class DataCall2
    {
        public string Message { get; set; }

        public string Status { get; set; }

        public string AccountName { get; set; }
    }
    public class DataCall1
    {
        public string Message { get; set; }

        public string Status { get; set; }
    }
    public class Data5
    {
        public int resCode { get; set; }
        public int orderId { get; set; }
        public string mobile { get; set; }
        public string status { get; set; }
        public long optid { get; set; }
        public string beneficiaryName { get; set; }
        public string resText { get; set; }
    }

    public class VALEDI
    {
        public Data5 data { get; set; }
    }
}

