﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;
using Newtonsoft.Json;

public partial class apibalance : System.Web.UI.Page
{
    private DataClassesDataContext db = new DataClassesDataContext();
 

    protected void Page_Load(object sender, EventArgs e)
    {
       
        string Username = null;
        string Password = null;
        string number = null;
        string bid = null;
       
        if (base.Request.HttpMethod == "GET")
        {
            Username = base.Request.QueryString["Username"];
            Password = base.Request.QueryString["Password"];
            number = base.Request.QueryString["Number"];
            bid = base.Request.QueryString["BeneficiaryId"];
        }
        else if (base.Request.HttpMethod == "POST")
        {
            Username = base.Request.QueryString["Username"];
            Password = base.Request.QueryString["Password"];
            number = base.Request.QueryString["Number"];
            bid = base.Request.QueryString["BeneficiaryId"];
        }
        string domain = base.Request.Headers.Get("Host").ToString().Replace("www.", "").Replace("http://", "");
            tblUser getUser = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == Username) && (x.Password == Password));
        if (getUser != null)
        {
        
            try
            {
                string str33 = clsMethods.BeneficiaryDelete(number, bid);
                var gettingop23 = new JavaScriptSerializer().Deserialize<delben>(str33);

                if (gettingop23.data.error_code == 200)
                {
                    DataCall2 response = new DataCall2()
                    {
                        Status = "1",
                        Message = "Beneficiary Delete Pending Otp Send To Wallet Number"
                    };
                    Response.Write(JsonConvert.SerializeObject(response));
                   
                }
                else
                {
                    DataCall2 response = new DataCall2()
                    {
                        Status = "0",
                        Message = gettingop23.data.resText
                    };
                    Response.Write(JsonConvert.SerializeObject(response));
                }
               
               
            }

            catch (Exception ex)
            {
                base.Response.Write(ex);

            }
        }
        else
        {
            base.Response.Write("User doesn't Exist");
        }
    }
    public class DataCall2
    {
        public string Message { get; set; }

        public string Status { get; set; }
    }

    public class Data8
    {
        public int error_code { get; set; }
        public string mobile { get; set; }
        public string resText { get; set; }
        public string beneficiaryId { get; set; }
    }

    public class delben
    {
        public Data8 data { get; set; }
    }
}

