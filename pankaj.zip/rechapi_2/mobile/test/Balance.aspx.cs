﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;


public partial class mobile_api_balance :  System.Web.UI.Page
{
    private DataClassesDataContext db = new DataClassesDataContext();
    private clsMethods sMethod = new clsMethods();

    protected void Page_Load(object sender, EventArgs e)
    {
        string username = base.Request.QueryString["UserName"].ToString();
        string password = base.Request.QueryString["Password"].ToString();
        tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == username) && (x.Password == password));
        base.Response.Write(clsMethods.getBalance(Convert.ToInt32(user.Id)).ToString("0,0.00"));
    }

   
}

