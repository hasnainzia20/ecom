﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;

public partial class apibalance : System.Web.UI.Page
{
    private DataClassesDataContext db = new DataClassesDataContext();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
    
    private clsMethods sMethod = new clsMethods();
  private string strLeft;
    private string getUsers(int userId)
    {
        IQueryable<tblUser> source = from x in this.db.tblUsers
                                     where x.ParentId == userId
                                     select x;
        if (source.Count<tblUser>() > 0)
        {
            foreach (tblUser user in source)
            {
                this.strLeft = this.strLeft + user.Id.ToString() + " ";
                this.getUsers(user.Id);
            }
        }
        return this.strLeft;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        new clsMethods();
        DataClassesDataContext context = new DataClassesDataContext();
        string Username = null;
        string Password = null;
        string number = null;
        string bid = null;
       
        if (base.Request.HttpMethod == "GET")
        {
            Username = base.Request.QueryString["Username"];
            Password = base.Request.QueryString["Password"];
       
        }
        else if (base.Request.HttpMethod == "POST")
        {
            Username = base.Request.QueryString["Username"];
            Password = base.Request.QueryString["Password"];
          
        }
        string domain = base.Request.Headers.Get("Host").ToString().Replace("www.", "").Replace("http://", "");
        tblUser getUser = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == Username) && (x.Password == Password));
        if (getUser != null)
        {
            this.Session["UserType"] = getUser.UserType;
            this.Session["UserId"] = getUser.Id;
            if (!base.IsPostBack)
            {
                //decimal? nullable123;
                //if (this.Session["UserType"].ToString() == clsVariables.UserType.Retailer)
                //{
                //    var queryable4234 = from x in this.db.tblRecharges
                //                    where (x.UserId == Convert.ToInt32(this.Session["UserId"].ToString())) && (x.Status == clsVariables.RechargeStatus.Success) && (x.RechargeDate.Date == DateTime.Now.Date)
                //                    orderby x.RechargeDate descending
                //                    select new
                //                    {
                //                        CommAmt = x.CommAmt,
                //                    };
                //    nullable123 = Queryable.Sum(queryable4234, x => x.CommAmt);
                //    decimal num12314 = nullable123.HasValue ? nullable123.GetValueOrDefault() : 0.0M;
                //    this.lblTotalcomm.Text = num12314.ToString();

                //}
                //else
                //{

                //    var queryable123 = from t in this.db.tblTransactions
                //                     join x in this.db.tblRecharges on t.RefId equals (long?)x.Id
                //                     where ((t.UserId == Convert.ToInt32(this.Session["UserId"].ToString())) && (x.Status == clsVariables.RechargeStatus.Success)) && (t.TransactionType == clsVariables.TransactionType.RechargeComm) && (x.RechargeDate.Date == DateTime.Now.Date)
                //                     orderby x.RechargeDate descending
                //                     select new
                //                     {
                //                         CommAmt = t.Amount,
                //                     };


                //    nullable123 = Queryable.Sum(queryable123, (x => (decimal?)x.CommAmt));
                //    this.lblTotalcomm.Text = (nullable123.HasValue ? nullable123.GetValueOrDefault() : 0.0M).ToString();

                //}
                
                if (this.Session["UserType"].ToString() == clsVariables.UserType.SuperDistributor)
                {
                    this.dist.Visible = true;
                    this.ret.Visible = true;
                }
                else if (this.Session["UserType"].ToString() == clsVariables.UserType.Distributor)
                {
                    this.ret.Visible = true;
                }
                else if (this.Session["UserType"].ToString() == clsVariables.UserType.User)
                {
                    //this.aPayout.Visible = false;
                }
                this.hfUsers.Value = this.getUsers(Convert.ToInt32(this.Session["UserId"].ToString())) + " " + this.Session["UserId"].ToString();
                string[] strRights = this.hfUsers.Value.Trim().Split(new char[] { ' ' });
                IQueryable<tblRecharge> source = from x in this.db.tblRecharges
                                                 where (strRights.Contains<string>(x.UserId.ToString()) && (x.RechargeDate.Date == DateTime.Now.Date)) && (x.Status == clsVariables.RechargeStatus.Success)
                                                 select x;
                IQueryable<tblRecharge> queryable2 = from x in this.db.tblRecharges
                                                     where (strRights.Contains<string>(x.UserId.ToString()) && (x.RechargeDate.Date == DateTime.Now.Date)) && (x.Status == clsVariables.RechargeStatus.Failure)
                                                     select x;
                IQueryable<tblRecharge> queryable3 = from x in this.db.tblRecharges
                                                     where (strRights.Contains<string>(x.UserId.ToString()) && (x.RechargeDate.Date == DateTime.Now.Date)) && (x.Status == clsVariables.RechargeStatus.Pending)
                                                     select x;
                IQueryable<tblRecharge> queryable4 = from x in this.db.tblRecharges
                                                     where (strRights.Contains<string>(x.UserId.ToString()) && (x.RechargeDate.Date == DateTime.Now.Date)) && (x.Status == clsVariables.RechargeStatus.Reversed)
                                                     select x;
            
                decimal? nullable = Queryable.Sum<tblRecharge>(source, (Expression<Func<tblRecharge, decimal?>>)(x => x.Amount));
                decimal num8 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
                this.lblSuccess.Text = source.Count<tblRecharge>() + " | " + num8.ToString();
                decimal? nullable2 = Queryable.Sum<tblRecharge>(queryable2, (Expression<Func<tblRecharge, decimal?>>)(x => x.Amount));
                this.lblFailure.Text = queryable2.Count<tblRecharge>() + " | " + (nullable2.HasValue ? nullable2.GetValueOrDefault() : 0.0M).ToString();
                decimal? nullable3 = Queryable.Sum<tblRecharge>(queryable3, (Expression<Func<tblRecharge, decimal?>>)(x => x.Amount));
                this.lblPending.Text = queryable3.Count<tblRecharge>() + " | " + (nullable3.HasValue ? nullable3.GetValueOrDefault() : 0.0M).ToString();
                decimal? nullable4 = Queryable.Sum<tblRecharge>(queryable4, (Expression<Func<tblRecharge, decimal?>>)(x => x.Amount));
                this.lblReversed.Text = queryable4.Count<tblRecharge>() + " | " + (nullable4.HasValue ? nullable4.GetValueOrDefault() : 0.0M).ToString();
                decimal? nullable5 = Queryable.Sum<tblRecharge>(source, (Expression<Func<tblRecharge, decimal?>>)(x => x.Amount));
                nullable = Queryable.Sum<tblRecharge>(queryable2, (Expression<Func<tblRecharge, decimal?>>)(x => x.Amount));
                nullable = Queryable.Sum<tblRecharge>(queryable3, (Expression<Func<tblRecharge, decimal?>>)(x => x.Amount));
                nullable = Queryable.Sum<tblRecharge>(queryable4, (Expression<Func<tblRecharge, decimal?>>)(x => x.Amount));
                this.lblTotal.Text = (((source.Count<tblRecharge>() + queryable3.Count<tblRecharge>()) + queryable2.Count<tblRecharge>()) + queryable4.Count<tblRecharge>()) + " | " + ((((nullable5.HasValue ? nullable5.GetValueOrDefault() : 0.0M) + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M)) + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M)) + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M));
                
                  if (this.Session["UserType"].ToString() == clsVariables.UserType.Retailer)
                {
                          IQueryable<tblRecharge> queryable150 = from x in this.db.tblRecharges
                                                       where (strRights.Contains<string>(x.UserId.ToString()) && (x.Status == clsVariables.RechargeStatus.Success) && (x.RechargeDate.Date == DateTime.Now.Date))
                                                     select x;

                       decimal? nullable1213 = Queryable.Sum<tblRecharge>(queryable150, (Expression<Func<tblRecharge, decimal?>>)(x => x.CommAmt));
                decimal num812 = nullable1213.HasValue ? nullable1213.GetValueOrDefault() : 0.0M;
                 this.lblTotalcomm.Text = num812.ToString();
                  }
                  else

                  {
                      var queryable12123 = from t in this.db.tblTransactions
                                     join x in this.db.tblRecharges on t.RefId equals (long?)x.Id
                                     where ((t.UserId == Convert.ToInt32(this.Session["UserId"].ToString())) && (x.Status == clsVariables.RechargeStatus.Success)) && (t.TransactionType == clsVariables.TransactionType.RechargeComm) && (x.RechargeDate.Date == DateTime.Now.Date)
                                     orderby x.RechargeDate descending
                                    
                                     select new
                                     {
                                         CommAmt = t.Amount,
                                     };


                       decimal? nullable1213 = Queryable.Sum(queryable12123, (x => (decimal?)x.CommAmt));
                decimal num812 = nullable1213.HasValue ? nullable1213.GetValueOrDefault() : 0.0M;
                 this.lblTotalcomm.Text = num812.ToString();
                  }
                
                decimal num = 0M;
                decimal num2 = 0M;
                decimal num3 = 0M;
                int num4 = 0;
                int num5 = 0;
                int num6 = 0;
                decimal num7 = 0M;
                if (this.Session["UserType"].ToString() == clsVariables.UserType.SuperDistributor)
                {
                    var queryable5 = from x in this.db.tblUsers
                                     where (x.UserType == clsVariables.UserType.Distributor) && strRights.Contains<string>(x.ParentId.ToString())
                                     select new { Id = x.Id };
                    foreach (var type in queryable5)
                    {
                        num7 += clsMethods.getBalance(type.Id);
                    }
                    num = num7;
                    this.lblDist.Text = queryable5.Count() + " | " + num7.ToString();
                    num4 = queryable5.Count();
                }
                if ((this.Session["UserType"].ToString() == clsVariables.UserType.SuperDistributor) || (this.Session["UserType"].ToString() == clsVariables.UserType.Distributor))
                {
                    var queryable6 = from x in this.db.tblUsers
                                     where (x.UserType == clsVariables.UserType.Retailer) && strRights.Contains<string>(x.ParentId.ToString())
                                     select new { Id = x.Id };
                    num7 = 0M;
                    foreach (var type2 in queryable6)
                    {
                        num7 += clsMethods.getBalance(type2.Id);
                    }
                    num2 = num7;
                    this.lblRetailer.Text = queryable6.Count() + " | " + num7.ToString();
                    num5 = queryable6.Count();
                }
                if (((this.Session["UserType"].ToString() == clsVariables.UserType.SuperDistributor) || (this.Session["UserType"].ToString() == clsVariables.UserType.Distributor)) || (this.Session["UserType"].ToString() == clsVariables.UserType.Retailer) || (this.Session["UserType"].ToString() == clsVariables.UserType.User))
                {
                    var queryable7 = from x in this.db.tblUsers
                                     where (x.UserType == clsVariables.UserType.User) && strRights.Contains<string>(x.ParentId.ToString())
                                     select new { Id = x.Id };
                    num7 = 0M;
                    foreach (var type3 in queryable7)
                    {
                        num7 += clsMethods.getBalance(type3.Id);
                    }
                    num3 = num7;
                    this.lblUser.Text = queryable7.Count() + " | " + num7.ToString();
                    num6 = queryable7.Count();
                }
                this.lblTotal2.Text = ((num4 + num5) + num6) + " | " + ((num + num2) + num3);
                tblTransaction transaction = (from x in this.db.tblTransactions
                                              orderby x.Id descending
                                              where (x.UserId == Convert.ToInt32(this.Session["UserId"].ToString())) && (x.AddDate.Date < DateTime.Now.Date)
                                              select x).FirstOrDefault<tblTransaction>();
                num8 = (transaction != null) ? transaction.Balance : 0M;
                this.lblOpBal.Text = num8.ToString();
                transaction = (from x in this.db.tblTransactions
                               orderby x.Id descending
                               where (x.UserId == Convert.ToInt32(this.Session["UserId"].ToString())) && (x.AddDate.Date == DateTime.Now.Date)
                               select x).FirstOrDefault<tblTransaction>();
                num8 = (transaction != null) ? transaction.Balance : 0M;
                this.lblCloBal.Text = num8.ToString();

                IQueryable<tblTransaction> queryable9 = from x in this.db.tblTransactions
                                                        where ((x.AddDate.Date == DateTime.Now.Date) && (x.UserId == Convert.ToInt32(this.Session["UserId"].ToString()))) && (x.TransactionType == clsVariables.TransactionType.RechargeComm)
                                                        select x;
                IQueryable<tblTransaction> queryable10 = from x in this.db.tblTransactions
                                                         where ((x.AddDate.Date == DateTime.Now.Date) && (x.UserId == Convert.ToInt32(this.Session["UserId"].ToString()))) && (x.TransactionType == clsVariables.TransactionType.RechargeCommFailure)
                                                         select x;
                nullable = Queryable.Sum<tblTransaction>(queryable9, (Expression<Func<tblTransaction, decimal?>>)(x => x.Amount));
                nullable = Queryable.Sum<tblTransaction>(queryable10, (Expression<Func<tblTransaction, decimal?>>)(x => x.Amount));
                num8 = (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M) - (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M);
                this.lblReversed2.Text = num8.ToString();

                IQueryable<tblTransaction> queryable11 = from x in this.db.tblTransactions
                                                         where ((x.AddDate.Date == DateTime.Now.Date) && strRights.Contains<string>(x.UserId.ToString())) && (x.TransactionType == clsVariables.TransactionType.RechargeCommRevert)
                                                         select x;
                nullable = Queryable.Sum<tblTransaction>(queryable11, (Expression<Func<tblTransaction, decimal?>>)(x => x.Amount));
                num8 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
                this.lblCommPayout.Text = num8.ToString();
                IQueryable<tblPaymentReq> queryable12 = from x in this.db.tblPaymentReqs
                                                        where ((x.Approved == clsVariables.RequestType.Pending) && (x.UserId == Convert.ToInt32(this.Session["UserId"].ToString()))) && (x.PaymentDate.Date == DateTime.Now.Date)
                                                        select x;
                nullable = Queryable.Sum<tblPaymentReq>(queryable12, (Expression<Func<tblPaymentReq, decimal?>>)(x => x.Amount));
                num8 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
                this.lblPendingPayment.Text = queryable12.Count<tblPaymentReq>() + " | " + num8.ToString();
                IQueryable<tblPaymentReq> queryable13 = from x in this.db.tblPaymentReqs
                                                        where ((x.Approved == clsVariables.RequestType.Accepted) && (x.UserId == Convert.ToInt32(this.Session["UserId"].ToString()))) && (x.PaymentDate.Date == DateTime.Now.Date)
                                                        select x;
                nullable = Queryable.Sum<tblPaymentReq>(queryable13, (Expression<Func<tblPaymentReq, decimal?>>)(x => x.Amount));
                num8 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
                this.lblAccepted.Text = queryable13.Count<tblPaymentReq>() + " | " + num8.ToString();
                IQueryable<tblPaymentReq> queryable14 = from x in this.db.tblPaymentReqs
                                                        where ((x.Approved == clsVariables.RequestType.Rejected) && (x.UserId == Convert.ToInt32(this.Session["UserId"].ToString()))) && (x.PaymentDate.Date == DateTime.Now.Date)
                                                        select x;
                nullable = Queryable.Sum<tblPaymentReq>(queryable14, (Expression<Func<tblPaymentReq, decimal?>>)(x => x.Amount));
                this.lblRejected.Text = queryable14.Count<tblPaymentReq>() + " | " + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M).ToString();
                nullable = Queryable.Sum<tblPaymentReq>(queryable12, (Expression<Func<tblPaymentReq, decimal?>>)(x => x.Amount));
                nullable = Queryable.Sum<tblPaymentReq>(queryable13, (Expression<Func<tblPaymentReq, decimal?>>)(x => x.Amount));
                nullable = Queryable.Sum<tblPaymentReq>(queryable14, (Expression<Func<tblPaymentReq, decimal?>>)(x => x.Amount));
                this.lblPaymentTotal.Text = ((queryable12.Count<tblPaymentReq>() + queryable13.Count<tblPaymentReq>()) + queryable14.Count<tblPaymentReq>()) + " | " + (((nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M) + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M)) + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M));
                IQueryable<tblTicket> queryable15 = from x in this.db.tblTickets
                                                    where ((x.Status == clsVariables.TicketStatus.InProcess) && (x.UserId == Convert.ToInt32(this.Session["UserId"].ToString()))) && (x.AddDate.Date == DateTime.Now.Date)
                                                    select x;
                IQueryable<tblTicket> queryable16 = from x in this.db.tblTickets
                                                    where ((x.Status == clsVariables.TicketStatus.Closed) && (x.UserId == Convert.ToInt32(this.Session["UserId"].ToString()))) && (x.AddDate.Date == DateTime.Now.Date)
                                                    select x;
                this.lblOpenTicket.Text = queryable15.Count<tblTicket>().ToString();
                this.lblClosedTicket.Text = queryable16.Count<tblTicket>().ToString();
                this.lblTotalTicket.Text = (queryable15.Count<tblTicket>() + queryable16.Count<tblTicket>()).ToString();
            }
        }
        else
        {
            base.Response.Write("User doesn't Exist");
        }
    }

    
    
}

