﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;

public partial class mobile_ChangePIN : System.Web.UI.Page
{
    private DataClassesDataContext db = new DataClassesDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (((base.Request.QueryString["UserName"] != null) && (base.Request.QueryString["Password"] != null)) && ((base.Request.QueryString["OldPassword"] != null) && (base.Request.QueryString["NewPassword"] != null)))
        {
            string UserName = base.Request.QueryString["UserName"].ToString();
            string Password = base.Request.QueryString["Password"].ToString();
            string str = base.Request.QueryString["OldPassword"].ToString();
            string str2 = base.Request.QueryString["NewPassword"].ToString();
            tblUser user = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == UserName) || (x.Mobile.ToString() == UserName) && (x.Password == Password));
            if (user != null)
            {
                if (user.Password == str)
                {
                    user.Password = str2;
                    this.db.SubmitChanges();
                    base.Response.Write("Your Password Updated Successfully");
                }
                else
                {
                    base.Response.Write("Your Old Password Is Incorrect");
                }
            }
            else
            {
                base.Response.Write("User doesn't exist");
            }
        }
        else
        {
            base.Response.Write("Parameter missing");
        }
    }

   
    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["slogpayConnectionString1"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }
}

