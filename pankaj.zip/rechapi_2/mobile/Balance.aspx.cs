﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;

public partial class mobile_api_balance : Page, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
    private clsMethods sMethod = new clsMethods();

    protected void Page_Load(object sender, EventArgs e)
    {
        string username = base.Request.QueryString["UserName"].ToString();
        string password = base.Request.QueryString["Password"].ToString();
        tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == username) && (x.Password == password));
        base.Response.Write(clsMethods.getBalance(Convert.ToInt32(user.Id)).ToString("0,0.00"));
    }

   
}
