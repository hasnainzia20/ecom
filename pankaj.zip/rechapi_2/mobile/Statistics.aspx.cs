﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;

public partial class mobile_api_report : Page, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {
        string username = base.Request.QueryString["UserName"].ToString();
        string password = base.Request.QueryString["Password"].ToString();
        string str = base.Request.QueryString["from"].ToString();
        string str2 = base.Request.QueryString["to"].ToString();
        DateTime fromDate1 = Convert.ToDateTime(str.Split(new char[] { '/' })[1] + "/" + str.Split(new char[] { '/' })[0] + "/" + str.Split(new char[] { '/' })[2]);
        DateTime toDate1 = Convert.ToDateTime(str2.Split(new char[] { '/' })[1] + "/" + str2.Split(new char[] { '/' })[0] + "/" + str2.Split(new char[] { '/' })[2]);
        tblUser getUser = Queryable.Single<tblUser>(this.db.tblUsers, x => (x.Id.ToString() == username) && (x.Password == password));
        var source = from x in this.db.tblRecharges
            join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id 
            join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id 
            where ((x.UserId == getUser.Id) && (x.RechargeDate.Date > Convert.ToDateTime(fromDate1).Date)) && (x.RechargeDate.Date <= Convert.ToDateTime(toDate1).Date)
            let Name1 = z.OperatorName
            orderby x.RechargeDate descending
            select new { 
                Id = x.Id,
                CompanyName = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                Amount = x.Amount,
                Date = x.RechargeDate,
                Status = x.Status,
                CommAmt = x.CommAmt,
                Number = x.Number,
                RechargeId = x.Id
            };
        string s = null;
        if (source.Count() > 0)
        {
            object obj2 = s;
            object[] objArray = new object[7];
            objArray[0] = obj2;
            objArray[1] = "Total Amt: ";
            decimal? nullable = Queryable.Sum(from g in source
                where g.Status == clsVariables.RechargeStatus.Success
                select g, (g => (decimal?)g.Amount));
            objArray[2] = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            objArray[3] = "\nCommission: ";
            decimal? nullable2 = Queryable.Sum(from g in source
                where g.Status == clsVariables.RechargeStatus.Success
                select g, g => g.CommAmt);
            objArray[4] = nullable2.HasValue ? nullable2.GetValueOrDefault() : 0.0M;
            objArray[5] = "\nReversed: ";
            nullable = Queryable.Sum(from g in source
                where g.Status == clsVariables.RechargeStatus.Reversed
                                     select g, (g => (decimal?)g.Amount));
            objArray[6] = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            s = string.Concat(objArray);
        }
        base.Response.Write(s);
    }

   
}
