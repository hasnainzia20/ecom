﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;

public partial class authin : System.Web.UI.Page

{


    protected void bindData()
    {
    }

    private DataClassesDataContext db = new DataClassesDataContext();
    private clsMethods sMethod = new clsMethods();

    protected void Page_Load(object sender, EventArgs e)
    {
        string username = base.Request.QueryString["UserName"].ToString();
        string password = base.Request.QueryString["Password"].ToString();
        DataClassesDataContext context = new DataClassesDataContext();
        tblUser user = Queryable.SingleOrDefault<tblUser>(context.tblUsers, x => (x.Id.ToString() == username) && (x.Password == password));
        if (user != null)
        {
            ob ob = new ob();
              string permission = "";
            try
            {
                permission = ob.executescalar("select AndroidApp from tblServicesAuth where UserId = '" + username + "'");
            }
            catch
            {
                permission = "False";
            }


            if (permission == "False")
            {
                base.Response.Write("false");
            }
            else
            {
                if (base.Request["android"] != null)
                {
                    base.Response.Write("true#" + clsMethods.getBalance(user.Id).ToString() + "#" + user.CustName);
                }
                else
                {
                    base.Response.Write("true#" + clsMethods.getBalance(user.Id).ToString() + "#" + user.CustName);
                    base.Response.Write("true");
                }
            }
        }
        else
        {
            base.Response.Write("false");
        }
    }

 
    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }

}

