﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;
using System.Collections.Specialized;
using Newtonsoft.Json;

public partial class mobileapi : System.Web.UI.Page
{


    protected void bindData()
    {
    }

    private DataClassesDataContext db = new DataClassesDataContext();
    private clsMethods sMethod = new clsMethods();

    protected void Page_Load(object sender, EventArgs e)
    {
        if ((((base.Request["UserName"] != null) && (base.Request["Password"] != null)) && ((base.Request["operatorcode"] != null) && (base.Request["number"] != null))) && (((base.Request["amount"] != null) && (base.Request["rechargeType"] != null)) && (base.Request["dob"] != null)))
        {
            string username = base.Request["UserName"].ToString();
            base.Request["dob"].ToString();
            string password = base.Request["Password"].ToString();
            string rechargeType = base.Request["rechargeType"].ToString();
            string opeartorcode = base.Request["operatorcode"].ToString();
            string number = base.Request["number"].ToString();
            decimal num = Convert.ToDecimal(base.Request["amount"].ToString());
            tblUser user = Queryable.SingleOrDefault<tblUser>(this.db.tblUsers, x => ((x.Id.ToString() == username) && (x.Password == password)) && x.Status);
            if (user != null)
            {
                base.Response.Write(clsMethods.doRecharge2(number, num.ToString(), opeartorcode, "12", user.Id, rechargeType, clsVariables.RechargeMode.GPRS, "0", "0", "0"));

            }
            else
            {
                base.Response.Write("User doesn't exist");
            }
        }
        else
        {
            base.Response.Write("Parameter missing");
        }
    }
 


}

