﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;
using Newtonsoft.Json;

public partial class apibalance : System.Web.UI.Page
{
    private DataClassesDataContext db = new DataClassesDataContext();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
    
    private clsMethods sMethod = new clsMethods();

    protected void Page_Load(object sender, EventArgs e)
    {
        new clsMethods();
        DataClassesDataContext context = new DataClassesDataContext();
        string Username = null;
        string Password = null;
        string number = null;
       
        if (base.Request.HttpMethod == "GET")
        {
            Username = base.Request.QueryString["Username"];
            Password = base.Request.QueryString["Password"];
            number = base.Request.QueryString["MobileCode"];
        }
        else if (base.Request.HttpMethod == "POST")
        {
            Username = base.Request.QueryString["Username"];
            Password = base.Request.QueryString["Password"];
            number = base.Request.QueryString["MobileCode"];
        }
        string domain = base.Request.Headers.Get("Host").ToString().Replace("www.", "").Replace("http://", "");
        tblUser getUser = Queryable.SingleOrDefault<tblUser>(context.tblUsers, x => ((((x.Id.ToString() == Username) && (x.APIPassword == Password)) && x.Status) && (x.Domain.Replace("www.", "").Replace("http://", "") == domain)));
        if (getUser != null)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            con.Open();
            try
            {
                ob ob = new ob();
                
               
                  

                string permission = "";
                try
                {
                    permission = ob.executescalar("select MDFApi from tblServicesAuth where UserId = '" + Username + "'");
                }
                catch
                {
                    permission = "False";
                }

                if (permission == "False")
                {

                    base.Response.Write("You Are Not Authorized to use this service");

                }
                else
                {
                   
                        var source = from x in this.db.tblMobileSeries
                                     join y in this.db.tblOperators on x.OperatorId equals y.Id
                                     join s in this.db.tblMainComps on y.MainCompId equals s.Id
                                     join n in this.db.tblStates on x.StateId equals n.Id
                                     where x.SeriesNo == number
                                     select new
                                     {
                                         OperatorName = s.OperatorName,
                                         State = n.StateName
                                     };

                        string JSONresult;
                        JSONresult = JsonConvert.SerializeObject(source);
                        Response.Write(JSONresult);
                    
                }

            }
            catch (Exception ex)
            {
                base.Response.Write(ex);

            }
        }
        else
        {
            base.Response.Write("User doesn't Exist");
        }
    }
  
 
    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }
}

