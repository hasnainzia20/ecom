﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;

public class UpdateStatus : Page, IRequiresSessionState
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DataClassesDataContext context = new DataClassesDataContext();
        string clientId = base.Request["accountId"];
        string str = base.Request["txid"];
        string str2 = base.Request["transtype"];
        string text1 = base.Request["optxid"];
        try
        {
            if ((clientId != null) && (str2 != null))
            {
                tblRecharge getRecharge = Queryable.SingleOrDefault<tblRecharge>(context.tblRecharges, x => (x.Id == Convert.ToInt64(clientId)) && (x.Status == clsVariables.RechargeStatus.Pending));
                tblUser user = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == getRecharge.UserId);
                tblUser user2 = Queryable.Single<tblUser>(context.tblUsers, x => x.UserType == clsVariables.UserType.Administrator);
                tblService service = Queryable.Single<tblService>(context.tblServices, x => x.Id == getRecharge.ServiceId);
                if (getRecharge != null)
                {
                    switch (str2)
                    {
                        case "f":
                        {
                            getRecharge.Status = clsVariables.RechargeStatus.Failure;
                            getRecharge.OperatorRef = str;
                            context.SubmitChanges();
                            tblRecharge recharge = (from x in context.tblRecharges
                                where x.UserId == getRecharge.UserId
                                orderby x.RechargeDate descending
                                select x).FirstOrDefault<tblRecharge>();
                            if (recharge != null)
                            {
                                getRecharge.Remarks = string.Concat(new object[] { "Recharge Id: ", getRecharge.Id.ToString(), " | Amount: ", getRecharge.Cost.ToString(), " | Balance: ", clsMethods.getBalance(getRecharge.UserId), " | New Balance: ", clsMethods.getBalance(getRecharge.UserId) + getRecharge.Cost });
                                decimal? closingBal = getRecharge.ClosingBal;
                                decimal cost = getRecharge.Cost;
                                recharge.ClosingBal = closingBal.HasValue ? new decimal?(closingBal.GetValueOrDefault() + cost) : null;
                                context.SubmitChanges();
                            }
                            if (getRecharge.RechargeMode == clsVariables.RechargeMode.SMS)
                            {
                                tblOperator getOperator = Queryable.Single<tblOperator>(context.tblOperators, x => x.Id == getRecharge.OperatorId);
                                tblMainComp comp = Queryable.Single<tblMainComp>(context.tblMainComps, x => x.Id == getOperator.MainCompId);
                                string message = string.Concat(new object[] { "Recharge ", getRecharge.Status.ToUpper(), ". ", comp.OperatorName, " ", getOperator.Operator, " Number: ", getRecharge.Number, " Rs.: ", getRecharge.Amount, " Tx. Id: ", getRecharge.Id.ToString(), " Now Bal: ", clsMethods.getBalance(user.Id), ". Thanks." });
                                clsMethods.sendSMS(user.Mobile, message, "");
                            }
                            clsMethods.addTrans(-1, getRecharge.Cost, getRecharge.Remarks, getRecharge.UserId, getRecharge.UserId, clsMethods.getBalance(getRecharge.UserId) + getRecharge.Cost, clsVariables.TransactionType.RechargeRevert, getRecharge.Id, clsMethods.getBalance(user2.Id), clsMethods.getBalance(getRecharge.ResellerId.Value) - getRecharge.Cost, getRecharge.ResellerId.Value, clsMethods.getABalance(getRecharge.ResellerId.Value) + getRecharge.Cost);
                            if (((service.ServiceName == clsVariables.ServiceType.Mobile) || (service.ServiceName == clsVariables.ServiceType.DTH)) || (service.ServiceName == clsVariables.ServiceType.DataCard))
                            {
                                clsMethods.removeReferelComm2(user.ParentId.Value, getRecharge.APIId.Value, getRecharge.OperatorId.Value, getRecharge.Amount, getRecharge.Number, user.Username, user2.Id, getRecharge.CommPer.Value, getRecharge.UserId, getRecharge.Id, getRecharge.ResellerId.Value);
                            }
                            if (user.RechargeAPI)
                            {
                                clsMethods.sendRequest(user.ResponseURL, ((getRecharge.Status == clsVariables.RechargeStatus.Success) ? "0" : ((getRecharge.Status == clsVariables.RechargeStatus.Failure) ? "1" : "2")) + "|" + getRecharge.TransactionId + "|" + getRecharge.ClientId.ToString() + "|" + getRecharge.OperatorRef + "|" + getRecharge.Status);
                            }
                            break;
                        }
                        case "s":
                        {
                            getRecharge.Status = clsVariables.RechargeStatus.Success;
                            if (str != null)
                            {
                                getRecharge.OperatorRef = str;
                            }
                            context.SubmitChanges();
                            clsMethods.getadminId(user.Id);
                            tblOperator getOperator = Queryable.Single<tblOperator>(context.tblOperators, x => x.Id == getRecharge.OperatorId);
                            tblMainComp comp2 = Queryable.Single<tblMainComp>(context.tblMainComps, x => x.Id == getOperator.MainCompId);
                            if (getRecharge.RechargeMode == clsVariables.RechargeMode.SMS)
                            {
                                string str4 = string.Concat(new object[] { "Recharge ", getRecharge.Status.ToUpper(), ". ", comp2.OperatorName, " ", getOperator.Operator, " Number: ", getRecharge.Number, " Rs.: ", getRecharge.Amount, " Tx. Id: ", getRecharge.Id.ToString(), " Now Bal: ", clsMethods.getBalance(user.Id), ". Thanks." });
                                clsMethods.sendSMS(user.Mobile, str4, "");
                            }
                            if (user.RechargeAPI)
                            {
                                clsMethods.sendRequest(user.ResponseURL, ((getRecharge.Status == clsVariables.RechargeStatus.Success) ? "0" : ((getRecharge.Status == clsVariables.RechargeStatus.Failure) ? "1" : "2")) + "|" + getRecharge.TransactionId + "|" + getRecharge.ClientId.ToString() + "|" + getRecharge.OperatorRef + "|" + getRecharge.Status);
                            }
                            break;
                        }
                    }
                    context.SubmitChanges();
                }
            }
        }
        catch (Exception exception)
        {
            tblTest entity = new tblTest {
                Message = clientId + " " + exception.Message,
                AddDate = DateTime.Now
            };
            context.tblTests.InsertOnSubmit(entity);
            context.SubmitChanges();
        }
    }

    
}
