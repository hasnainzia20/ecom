﻿using AjaxControlToolkit;
using System;
using System.Web;
using System.Web.Profile;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class control_ShowMessage : UserControl
{


    protected void Page_Load(object sender, EventArgs e)
    {
    }

    public void SetMessage(string sMessage)
    {
        this.lblText.Text = sMessage;
        this.popup.Show();
    }

    public void SetMessage(string sMessage, MessageType messageType)
    {
        this.lblTitle.Text = "ERROR";
        this.lblText.Text = sMessage;
        if (messageType == MessageType.Warning)
        {
            this.lblTitle.Text = "WARNING";
            this.lblText.Text = "<i class=\"icon-hand-right\"></i> " + sMessage;
        }
        else if (messageType == MessageType.Success)
        {
            this.lblTitle.Text = "SUCCESS";
            this.lblText.Text = "<i class=\"icon-ok-sign\"></i> " + sMessage;
        }
        else if (messageType == MessageType.Information)
        {
            this.lblTitle.Text = "INFORMATION";
            this.lblText.Text = "<i class=\"icon-info-sign\"></i> " + sMessage;
        }
        this.popup.Show();
    }

   
    public enum MessageType
    {
        Error,
        Warning,
        Success,
        Information
    }
}

