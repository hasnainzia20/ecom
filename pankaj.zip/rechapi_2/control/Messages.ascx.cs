﻿using System;
using System.Web;
using System.Web.Profile;
using System.Web.UI;
using System.Web.UI.HtmlControls;

public partial class Messages : UserControl
{
 

    public void ClearMessage()
    {
    }

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    public void SetMessage(string sMessage)
    {
        this.SetMessage(sMessage, MessageType.Error);
    }

    public void SetMessage(string sMessage, MessageType messageType)
    {
        this.divMsg.Attributes.Add("class", "alert error_msg");
        this.divMsg.InnerHtml = sMessage;
        if (messageType == MessageType.Warning)
        {
            this.divMsg.Attributes.Add("class", "alert exclamation_msg");
        }
        else if (messageType == MessageType.Success)
        {
            this.divMsg.Attributes.Add("class", "alert succes_msg");
        }
        else if (messageType == MessageType.Information)
        {
            this.divMsg.Attributes.Add("class", "alert info_msg");
        }
    }
  public enum MessageType
    {
        Error,
        Warning,
        Success,
        Information
    }
}

