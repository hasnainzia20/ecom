﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user_Profile : ThemeClass, IRequiresSessionState
{
 
    private DataClassesDataContext db = new DataClassesDataContext();
  

    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString())).SiteTitle = this.txtTitle.Text;
            this.db.SubmitChanges();
            this.Popup.SetMessage("Title updated successfully", control_ShowMessage.MessageType.Success);
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
            this.txtTitle.Text = user.SiteTitle;
        }
    }

   
}
