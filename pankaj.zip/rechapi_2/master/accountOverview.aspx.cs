﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI.WebControls;

public partial class user_accountOverview : ThemeClass, IRequiresSessionState
{
 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            DataClassesDataContext context = new DataClassesDataContext();
            tblUser user = Queryable.Single<tblUser>(context.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
            this.lblAccount.Text = user.UserType;
            this.lblDate.Text = user.AddDate.ToString("dd/MM/yyyy hh:mm:ss tt");
            this.lblAdmin.Text = this.Session["SiteTitle"].ToString();
            this.lblBalance.Text = clsMethods.getBalance(user.Id).ToString();
        }
    }

  
}
