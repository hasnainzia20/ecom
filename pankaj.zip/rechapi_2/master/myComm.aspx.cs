﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user_myComm : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
   
    private void bindData()
    {
        var queryable = from x in this.db.tblCommissions
            join y in this.db.tblOperators on x.OperatorId equals y.Id 
            join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id 
            join z2 in this.db.tblServices on z.ServiceId equals z2.Id 
            join z1 in this.db.tblUsers on x.PackageId equals z1.SchemeId 
            let Name1 = z.OperatorName
            where z1.Id == Convert.ToInt32(this.Session["aUserId"].ToString())
            orderby z2.Id
            select new { 
                Id = x.Id,
                Service = z2.ServiceName,
                Operator = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                CommAmt = (((z2.ServiceName == clsVariables.ServiceType.Mobile) || (z2.ServiceName == clsVariables.ServiceType.DTH)) || (z2.ServiceName == clsVariables.ServiceType.DataCard)) ? (x.Percentage + "%") : ("Rs " + 0),
                Surcharge = (((z2.ServiceName != clsVariables.ServiceType.Mobile) && (z2.ServiceName != clsVariables.ServiceType.DTH)) && (z2.ServiceName != clsVariables.ServiceType.DataCard)) ? ("Rs " + x.Percentage) : ("" + 0)
            };
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    private void ddlBind()
    {
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.bindData();
        }
    }

    
}
