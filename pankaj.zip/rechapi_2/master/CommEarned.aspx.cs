﻿using AjaxControlToolkit;
using System;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class user_CommEarned : ThemeClass, IRequiresSessionState
{
   
    private DataClassesDataContext db = new DataClassesDataContext();
  

    private void bindData()
    {
        var queryable = from gh in this.db.tblTransactions
            join x in this.db.tblRecharges on gh.RefId equals (long?) x.Id
            join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id 
            join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id
            join z1 in this.db.tblServices on x.ServiceId equals (short?) z1.Id 
            let Name1 = z.OperatorName
            where ((gh.UserId == Convert.ToInt32(this.Session["aUserId"].ToString())) && (x.Status == clsVariables.RechargeStatus.Success)) && (gh.TransactionType == clsVariables.TransactionType.RechargeComm)
            orderby x.RechargeDate descending
            select new { 
                Id = x.Id,
                RefId = x.Id,
                Mobile = x.Number,
                User = (from ghi in this.db.tblUsers
                    where ghi.Id == x.UserId
                    select new { Name = (ghi.Username + " [") + ghi.CustName + "]" }).First().Name,
                Amount = x.Amount,
                Operator = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                RechargeDate = x.RechargeDate,
                CommAmt = gh.Amount,
                Balance = gh.Balance2,
                UserId = x.UserId
            };
        if (((this.txtFrom.Text != null) && (this.txtFrom.Text != "")) && ((this.txtTo.Text != null) && (this.txtTo.Text != "")))
        {
            DateTime dt;
            DateTime dt2;
            DateTime.TryParseExact(this.txtFrom.Text.Split(new char[] { '/' })[1] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[0] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt);
            DateTime.TryParseExact(this.txtTo.Text.Split(new char[] { '/' })[1] + "/" + this.txtTo.Text.Split(new char[] { '/' })[0] + "/" + this.txtTo.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt2);
            queryable = from x in queryable
                where (x.RechargeDate.Date <= dt.Date) && (x.RechargeDate.Date >= dt2.Date)
                select x;
        }
        decimal? nullable = Queryable.Sum(queryable, (x => (decimal?)x.CommAmt));
        this.lblTotal.Text = "Commission: " + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M).ToString();
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
        if ((this.Session["UserType"].ToString() == clsVariables.UserType.Retailer) || (this.Session["UserType"].ToString() == clsVariables.UserType.User))
        {
            this.gvMain.Columns[1].Visible = false;
        }
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
        this.hfUsers.Value = this.getUsers(Convert.ToInt32(this.Session["aUserId"].ToString())) + " " + this.Session["aUserId"].ToString();
        this.hfUsers.Value.Trim().Split(new char[] { ' ' });
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData();
    }

    private string getUsers(int userId)
    {
        IQueryable<tblUser> source = from x in this.db.tblUsers
            where x.ParentId == userId
            select x;
        if (source.Count<tblUser>() > 0)
        {
            foreach (tblUser user in source)
            {
                this.strLeft = this.strLeft + user.Id.ToString() + " ";
                this.getUsers(user.Id);
            }
        }
        return this.strLeft;
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            tblRecharge getRecharge = Queryable.SingleOrDefault<tblRecharge>(this.db.tblRecharges, x => x.Id == Convert.ToInt32(e.CommandArgument));
            if (getRecharge != null)
            {
                this.lblMobile.Text = getRecharge.Number;
                this.lblRefId.Text = getRecharge.Id.ToString();
                this.lblAmount.Text = getRecharge.Amount.ToString();
                this.lblDate.Text = getRecharge.RechargeDate.ToString("dd/MM/yyyy hh:mm:ss tt");
                this.lblTranId.Text = getRecharge.TransactionId.ToString();
                this.lblOperator.Text = (from g in this.db.tblOperators
                    join j in this.db.tblMainComps on g.MainCompId equals (short?) j.Id
                    where g.Id == getRecharge.OperatorId
                    let Name1 = g.Operator
                    select new { Name = (g.Operator != null) ? (j.OperatorName + " " + g.Operator) : j.OperatorName }).First().Name;
                this.popup1222.Show();
            }
        }
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "15",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.txtTo.Text = this.txtFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            this.bindData();
        }
    }



    public string strLeft { get; set; }
}
