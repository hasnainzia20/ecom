﻿using AjaxControlToolkit;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class user_viewTickets : ThemeClass, IRequiresSessionState
{

    private DataClassesDataContext db = new DataClassesDataContext();
    

    private void bindData()
    {
        var queryable = from x in this.db.tblTickets
            where x.ResellerId == Convert.ToInt32(this.Session["aUserId"].ToString())
            orderby x.AddDate descending
            select new { 
                Id = x.Id,
                SupportType = x.SupportType,
                AddDate = x.AddDate,
                Status1 = x.Status,
                Status = (x.Status == clsVariables.TicketStatus.Closed) ? "<span style='color:green'>CLOSED</span>" : ((x.Status == clsVariables.TicketStatus.Open) ? "<span style='color:red'>OPEN</span>" : ((x.Status == clsVariables.TicketStatus.InProcess) ? "<span style='color:orange'>IN PROCESS</span>" : "UNKNOWN"))
            };
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            queryable = from x in queryable
                where x.Id.ToString().Contains(this.txtSearch.Text)
                select x;
        }
        if (((this.txtFrom.Text != null) && (this.txtFrom.Text != "")) && ((this.txtTo.Text != null) && (this.txtTo.Text != "")))
        {
            DateTime dt;
            DateTime dt2;
            DateTime.TryParseExact(this.txtFrom.Text.Split(new char[] { '/' })[1] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[0] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt);
            DateTime.TryParseExact(this.txtTo.Text.Split(new char[] { '/' })[1] + "/" + this.txtTo.Text.Split(new char[] { '/' })[0] + "/" + this.txtTo.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt2);
            queryable = from x in queryable
                where (x.AddDate.Date <= dt.Date) && (x.AddDate.Date >= dt2.Date)
                select x;
        }
        if (this.ddlStatus.SelectedIndex > 0)
        {
            queryable = from x in queryable
                where x.Status1 == this.ddlStatus.SelectedValue
                select x;
        }
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnAdd_Click(object sender, EventArgs e)
    {
        this.replydiv.Visible = true;
        this.vMain.Visible = false;
    }

    protected void bttnAdd2_Click(object sender, EventArgs e)
    {
        this.replydiv.Visible = false;
        this.vMain.Visible = true;
    }

    protected void bttnExport_Click(object sender, EventArgs e)
    {
        this.ExportToExcel();
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
        this.ddlStatus.DataSource = clsVariables.TicketStatuss();
        this.ddlStatus.DataTextField = "Text";
        this.ddlStatus.DataValueField = "Value";
        this.ddlStatus.DataBind();
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData();
    }

    protected void ExportToExcel()
    {
        HtmlForm child = new HtmlForm();
        string str = "attachment;filename=" + DateTime.Now.ToString("dd-MM-yyyy") + "_ViewTickets.xls";
        base.Response.ClearContent();
        base.Response.AddHeader("content-disposition", str);
        base.Response.ContentType = "application/vnd.ms-excel";
        StringWriter writer = new StringWriter();
        HtmlTextWriter writer2 = new HtmlTextWriter(writer);
        child.Controls.Add(this.gvMain);
        this.Controls.Add(child);
        child.RenderControl(writer2);
        base.Response.Write(writer.ToString());
        base.Response.End();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            tblTicket ticket = Queryable.Single<tblTicket>(this.db.tblTickets, x => x.Id == Convert.ToInt32(e.CommandArgument));
            this.lblTitle2.Text = this.lblTitle.Text = "Ticket Details >> Ticket No: " + e.CommandArgument.ToString() + " | Subject: " + ticket.SupportType;
            var source = from x in this.db.tblTicketDetails
                join y in this.db.tblUsers on x.UserId equals y.Id 
                where x.TicketId == Convert.ToInt32(e.CommandArgument)
                orderby x.ResponseDate descending
                select new { 
                    Id = x.Id,
                    TranId = x.TranId,
                    Response = x.Response,
                    ResponseDate = x.ResponseDate,
                    Mobile = (from g in this.db.tblRecharges
                        where g.Id == Convert.ToInt32(x.TranId)
                        select new { Mobile = g.Number }).First().Mobile,
                    RechargeDate = (from g in this.db.tblRecharges
                        where g.Id == Convert.ToInt32(x.TranId)
                        select new { RechargeDate = g.RechargeDate }).First().RechargeDate,
                    RefId = x.TranId,
                    Name = (y.Username + " [") + y.CustName + "]"
                };
            this.gvMain2.DataSource = source;
            this.gvMain2.DataBind();
            if (ticket.Status == clsVariables.TicketStatus.InProcess)
            {
                this.bttnAdd.Visible = true;
            }
            this.hfTicketId.Value = e.CommandArgument.ToString();
            this.txtSubject.Text = ticket.SupportType;
            if (ticket.SupportType == clsVariables.TicketType.RechargeDispute)
            {
                this.hfRechargeId.Value = source.First().TranId;
            }
            this.replydiv.Visible = false;
            this.vMain.Visible = true;
            this.popup1222.Show();
        }
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "15",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
    }

    protected void lnkClear_Click(object sender, EventArgs e)
    {
        this.txtMessage.Text = "";
    }

    protected void lnkSubmit_Click(object sender, EventArgs e)
    {
        Queryable.Single<tblTicket>(this.db.tblTickets, x => x.Id == Convert.ToInt32(this.hfTicketId.Value)).Status = clsVariables.TicketStatus.Closed;
        this.db.SubmitChanges();
        tblTicketDetail entity = new tblTicketDetail {
            TicketId = Convert.ToInt32(this.hfTicketId.Value),
            Response = this.txtMessage.Text
        };
        if (this.txtSubject.Text == clsVariables.TicketType.RechargeDispute)
        {
            entity.TranId = this.hfRechargeId.Value;
        }
        entity.ResponseDate = DateTime.Now;
        entity.UserId = Convert.ToInt32(this.Session["aUserId"].ToString());
        this.db.tblTicketDetails.InsertOnSubmit(entity);
        this.db.SubmitChanges();
        this.popup1222.Hide();
        this.bindData();
        this.Popup.SetMessage("Ticket updated successfully, Ticket Id: " + this.hfTicketId.Value.ToString(), control_ShowMessage.MessageType.Success);
        this.txtMessage.Text = "";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.txtTo.Text = this.txtFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            this.bindData();
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
    }


}
