﻿using AjaxControlToolkit;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_payHistory : ThemeClass, IRequiresSessionState
{
   
    private DataClassesDataContext db = new DataClassesDataContext();

    private void bindData()
    {
        var queryable = from x in this.db.tblPaymentReqs
            join y in this.db.tblUsers on x.UserId equals y.Id 
            join z in this.db.tblBankDetails on x.DepositBankId equals z.Id 
            join z1 in this.db.tblBanks on z.BankId equals z1.Id 
            orderby x.PaymentDate descending
            select new { 
                Id = x.Id,
                UserId = x.UserId,
                Username = (y.CustName + " [") + (y.Id) + "]",
                Amount = x.Amount,
                RechargeDate = x.PaymentDate,
                Status1 = x.Approved,
                Remarks = x.Remarks,
                BankName = z1.BankName + " - " + z.AccountNo,
                PaymentMode = x.PaymentMode,
                TranNo = x.TranNo,
                Status = (x.Approved == clsVariables.RequestType.Accepted) ? "<span style='color:green'>ACCEPTED</span>" : ((x.Approved == clsVariables.RequestType.Rejected) ? "<span style='color:red'>REJECTED</span>" : "UNKNOWN")
            };
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            queryable = from x in queryable
                where (x.BankName.Contains(this.txtSearch.Text) || x.TranNo.Contains(this.txtSearch.Text)) || x.Id.ToString().Contains(this.txtSearch.Text)
                select x;
        }
        if (this.ddlUsers.SelectedIndex > 0)
        {
            queryable = from x in queryable
                where x.UserId == Convert.ToInt32(this.ddlUsers.SelectedValue)
                select x;
        }
        if (((this.txtFrom.Text != null) && (this.txtFrom.Text != "")) && ((this.txtTo.Text != null) && (this.txtTo.Text != "")))
        {
            DateTime dt;
            DateTime dt2;
            DateTime.TryParseExact(this.txtFrom.Text.Split(new char[] { '/' })[1] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[0] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt);
            DateTime.TryParseExact(this.txtTo.Text.Split(new char[] { '/' })[1] + "/" + this.txtTo.Text.Split(new char[] { '/' })[0] + "/" + this.txtTo.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt2);
            queryable = from x in queryable
                where (x.RechargeDate.Date <= dt.Date) && (x.RechargeDate.Date >= dt2.Date)
                select x;
        }
        if (this.ddlStatus.SelectedIndex > 0)
        {
            queryable = from x in queryable
                where x.Status1 == this.ddlStatus.SelectedValue
                select x;
        }
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnExport_Click(object sender, EventArgs e)
    {
        this.ExportToExcel();
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
        this.ddlStatus.DataSource = clsVariables.RequestTypes();
        this.ddlStatus.DataTextField = "Text";
        this.ddlStatus.DataValueField = "Value";
        this.ddlStatus.DataBind();
        var queryable = from x in this.db.tblUsers
            where x.UserType != clsVariables.UserType.Administrator
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + (x.Id) + "]"
            };
        this.ddlUsers.DataSource = queryable;
        this.ddlUsers.DataTextField = "Name";
        this.ddlUsers.DataValueField = "Id";
        this.ddlUsers.DataBind();
        this.ddlUsers.Items.Insert(0, "All");
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData();
    }

    protected void ExportToExcel()
    {
        HtmlForm child = new HtmlForm();
        string str = "attachment;filename=" + DateTime.Now.ToString("dd-MM-yyyy") + "_PayHistory.xls";
        base.Response.ClearContent();
        base.Response.AddHeader("content-disposition", str);
        base.Response.ContentType = "application/vnd.ms-excel";
        StringWriter writer = new StringWriter();
        HtmlTextWriter writer2 = new HtmlTextWriter(writer);
        child.Controls.Add(this.gvMain);
        this.Controls.Add(child);
        child.RenderControl(writer2);
        base.Response.Write(writer.ToString());
        base.Response.End();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList list = new DropDownList {
                Items = { 
                    "30",
                    "15",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = list.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                list.SelectedIndex = list.Items.IndexOf(item);
            }
            list.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(list);

            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.txtTo.Text = this.txtFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            this.bindData();
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
    }


}
