﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_commPackages : ThemeClass, IRequiresSessionState
{
  
    private DataClassesDataContext db = new DataClassesDataContext();
   

    private void bindData()
    {
        var queryable = from x in this.db.tblCommPackages
            where x.UserId == Convert.ToInt32(this.Session["aUserId"].ToString())
            orderby x.PackageName
            select new { 
                Id = x.Id,
                Name = x.PackageName,
                Usertype = x.UserType
            };
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            queryable = from x in queryable
                where x.Name.Contains(this.txtSearch.Text) || x.Usertype.Contains(this.txtSearch.Text)
                select x;
        }
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnAdd_Click(object sender, EventArgs e)
    {
        if (this.bttnAdd.Text == "Create New Package")
        {
            if (Queryable.SingleOrDefault<tblCommPackage>(this.db.tblCommPackages, x => ((x.PackageName == this.txtPackage.Text) && (x.UserId == Convert.ToInt32(this.Session["aUserId"].ToString()))) && (x.UserType == this.ddlUserType.SelectedValue)) == null)
            {
                tblCommPackage entity = new tblCommPackage {
                    PackageName = this.txtPackage.Text,
                    AddDate = DateTime.Now,
                    UserType = this.ddlUserType.SelectedValue,
                    UserId = new int?(Convert.ToInt32(this.Session["aUserId"].ToString()))
                };
                this.db.tblCommPackages.InsertOnSubmit(entity);
                this.db.SubmitChanges();
                var queryable = from x in this.db.tblOperators
                    join z in this.db.tblMainComps on x.MainCompId equals (short?) z.Id 
                    join y in this.db.tblServices on z.ServiceId equals y.Id 
                    let Name1 = z.OperatorName
                    orderby z.OperatorName
                    select new { Id = x.Id };
                tblApi api = this.db.tblApis.First<tblApi>();
                foreach (var type in queryable)
                {
                    tblCommission commission = new tblCommission {
                        PackageId = entity.Id,
                        OperatorId = type.Id,
                        AddDate = DateTime.Now,
                        ApiId = new short?(api.Id),
                        Percentage = 0M
                    };
                    this.db.tblCommissions.InsertOnSubmit(commission);
                    this.db.SubmitChanges();
                }
                this.bindData();
                this.popup1222.Hide();
                this.reset();
                this.Popup.SetMessage("Commission Package added successfully", control_ShowMessage.MessageType.Success);
            }
            else
            {
                this.Popup.SetMessage("Commission Package already exist", control_ShowMessage.MessageType.Warning);
            }
        }
        else if (this.bttnAdd.Text == "Update Package")
        {
            tblCommPackage addSeries = Queryable.SingleOrDefault<tblCommPackage>(this.db.tblCommPackages, x => x.Id == Convert.ToInt32(this.hfId.Value));
            if (addSeries != null)
            {
                if (Queryable.SingleOrDefault<tblCommPackage>(this.db.tblCommPackages, x => ((x.PackageName == this.txtPackage.Text) && (x.UserType == this.ddlUserType.SelectedValue)) && (x.Id != addSeries.Id)) == null)
                {
                    addSeries.PackageName = this.txtPackage.Text;
                    addSeries.AddDate = DateTime.Now;
                    addSeries.UserType = this.ddlUserType.SelectedValue;
                    this.db.SubmitChanges();
                    this.reset();
                    this.bindData();
                    this.popup1222.Hide();
                    this.Popup.SetMessage("Commission Package updated successfully", control_ShowMessage.MessageType.Success);
                }
                else
                {
                    this.Popup.SetMessage("Commission Package already exist", control_ShowMessage.MessageType.Warning);
                }
            }
        }
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
        this.ddlUserType.DataSource = from x in clsVariables.UserTypes()
            where x.Value != clsVariables.UserType.Administrator
            select x;
        this.ddlUserType.DataTextField = "Text";
        this.ddlUserType.DataValueField = "Value";
        this.ddlUserType.DataBind();
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            this.lblTitle.Text = "UPDATE PACKAGE";
            this.bttnAdd.Text = "Update Package";
            tblCommPackage package = Queryable.Single<tblCommPackage>(this.db.tblCommPackages, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.hfId.Value = package.Id.ToString();
            this.txtPackage.Text = package.PackageName;
            this.ddlUserType.SelectedValue = package.UserType;
            this.popup1222.Show();
        }
        else if (e.CommandName == "lnkDelete")
        {
            tblCommPackage entity = Queryable.Single<tblCommPackage>(this.db.tblCommPackages, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.db.tblCommPackages.DeleteOnSubmit(entity);
            this.db.SubmitChanges();
            this.bindData();
            this.Popup.SetMessage("Commission Package deleted successfully", control_ShowMessage.MessageType.Success);
        }
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "5",
                    "10",
                    "15"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button button3 = (Button) e.Row.FindControl("bttnDelete");
            button3.Attributes.Add("onclick", string.Concat(new object[] { "javascript:return confirm('Are you sure you want to delete this record: ", DataBinder.Eval(e.Row.DataItem, "Name"), " - ", DataBinder.Eval(e.Row.DataItem, "Usertype"), "')" }));
        }
    }

    protected void lnkOpen_Click(object sender, EventArgs e)
    {
        this.lblTitle.Text = "CREATE NEW PACKAGE";
        this.bttnAdd.Text = "Create New Package";
        this.reset();
        this.popup1222.Show();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.bindData();
        }
    }

    private void reset()
    {
        this.txtPackage.Text = "";
        this.ddlUserType.SelectedIndex = 0;
    }

 
}
