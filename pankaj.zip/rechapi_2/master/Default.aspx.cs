﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq.Expressions;
using System.Reflection;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Net;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Script.Serialization;


public partial class admin_Default : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();
 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {

            
            IQueryable<tblRecharge> source = from x in this.db.tblRecharges
                                             where (x.ResellerId == Convert.ToInt32(this.Session["aUserId"])) && (x.RechargeDate.Date == DateTime.Now.Date) && (x.Status == clsVariables.RechargeStatus.Success)
                select x;
            IQueryable<tblRecharge> queryable2 = from x in this.db.tblRecharges
                                                 where (x.ResellerId == Convert.ToInt32(this.Session["aUserId"])) && (x.RechargeDate.Date == DateTime.Now.Date) && (x.Status == clsVariables.RechargeStatus.Failure)
                select x;
            IQueryable<tblRecharge> queryable3 = from x in this.db.tblRecharges
                                                 where (x.ResellerId == Convert.ToInt32(this.Session["aUserId"])) && (x.RechargeDate.Date == DateTime.Now.Date) && (x.Status == clsVariables.RechargeStatus.Pending)
                select x;
            IQueryable<tblRecharge> queryable4 = from x in this.db.tblRecharges
                                                 where (x.ResellerId == Convert.ToInt32(this.Session["aUserId"])) && (x.RechargeDate.Date == DateTime.Now.Date) && (x.Status == clsVariables.RechargeStatus.Reversed)
                select x;
            decimal? nullable = Queryable.Sum<tblRecharge>(source, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            decimal num10 = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            this.lblSuccess.Text = source.Count<tblRecharge>() + " | " + num10.ToString();
            decimal? nullable2 = Queryable.Sum<tblRecharge>(queryable2, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            this.lblFailure.Text = queryable2.Count<tblRecharge>() + " | " + (nullable2.HasValue ? nullable2.GetValueOrDefault() : 0.0M).ToString();
            decimal? nullable3 = Queryable.Sum<tblRecharge>(queryable3, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            this.lblPending.Text = queryable3.Count<tblRecharge>() + " | " + (nullable3.HasValue ? nullable3.GetValueOrDefault() : 0.0M).ToString();
            decimal? nullable4 = Queryable.Sum<tblRecharge>(queryable4, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            this.lblReversed.Text = queryable4.Count<tblRecharge>() + " | " + (nullable4.HasValue ? nullable4.GetValueOrDefault() : 0.0M).ToString();
            decimal? nullable5 = Queryable.Sum<tblRecharge>(source, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            decimal? nullable6 = Queryable.Sum<tblRecharge>(queryable2, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            decimal? nullable7 = Queryable.Sum<tblRecharge>(queryable3, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            nullable = Queryable.Sum<tblRecharge>(queryable4, (Expression<Func<tblRecharge, decimal?>>) (x => x.Amount));
            this.lblTotal.Text = (((source.Count<tblRecharge>() + queryable3.Count<tblRecharge>()) + queryable2.Count<tblRecharge>()) + queryable4.Count<tblRecharge>()) + " | " + ((((nullable5.HasValue ? nullable5.GetValueOrDefault() : 0.0M) + (nullable6.HasValue ? nullable6.GetValueOrDefault() : 0.0M)) + (nullable7.HasValue ? nullable7.GetValueOrDefault() : 0.0M)) + (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M));
            decimal num = 0M;
            decimal num2 = 0M;
            decimal num3 = 0M;
            decimal num4 = 0M;
            int num5 = 0;
            int num6 = 0;
            int num7 = 0;
            int num8 = 0;
            string domain = base.Request.Headers.Get("Host").ToString().Replace("www.", "").Replace("http://", "");
                var queryable5 = from x in this.db.tblUsers
                                 where x.UserType == clsVariables.UserType.SuperDistributor && x.Domain == domain
                                 select new { Id = x.Id };
                decimal num9 = 0M;
                foreach (var type in queryable5)
                {
                    num9 += clsMethods.getBalance(type.Id);
                }
                num = num9;
                this.lblSD.Text = queryable5.Count() + " | " + num9.ToString();
                num5 = queryable5.Count();

                queryable5 = from x in this.db.tblUsers
                             where x.UserType == clsVariables.UserType.Distributor && x.Domain == domain
                             select new { Id = x.Id };
                num9 = 0M;
                foreach (var type2 in queryable5)
                {
                    num9 += clsMethods.getBalance(type2.Id);
                }
                num2 = num9;
                this.lblDist.Text = queryable5.Count() + " | " + num9.ToString();
                num6 = queryable5.Count();
                queryable5 = from x in this.db.tblUsers
                             where x.UserType == clsVariables.UserType.Retailer && x.Domain == domain
                             select new { Id = x.Id };
                num9 = 0M;
                foreach (var type3 in queryable5)
                {
                    num9 += clsMethods.getBalance(type3.Id);
                }
                num3 = num9;
                this.lblRetailer.Text = queryable5.Count() + " | " + num9.ToString();
                num7 = queryable5.Count();
                queryable5 = from x in this.db.tblUsers
                             where x.UserType == clsVariables.UserType.User && x.Domain == domain
                             select new { Id = x.Id };
                num9 = 0M;
                foreach (var type4 in queryable5)
                {
                    num9 += clsMethods.getBalance(type4.Id);
                }
                num4 = num9;
                this.lblUser.Text = queryable5.Count() + " | " + num9.ToString();
                num8 = queryable5.Count();
                this.lblTotal2.Text = (((num5 + num6) + num7) + num8) + " | " + (((num + num2) + num3) + num4);

                tblAlert use2r = Queryable.Single<tblAlert>(db.tblAlerts, x => x.AlertType == "Announcement");
                this.lblNews.Text = use2r.Alerts;
                this.lblNews.ForeColor = System.Drawing.Color.Blue;
        }
    }

    public class DataClassesDataContext1 : DataContext
    {

        private static MappingSource mappingSource = new AttributeMappingSource();

        public DataClassesDataContext1()
            : base(System.Configuration.ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString, mappingSource)
        {
        }

        public DataClassesDataContext1(IDbConnection connection)
            : base(connection, mappingSource)
        {
        }

        public DataClassesDataContext1(string connection)
            : base(connection, mappingSource)
        {
        }

        public DataClassesDataContext1(IDbConnection connection, MappingSource mappingSource)
            : base(connection, mappingSource)
        {
        }

        public DataClassesDataContext1(string connection, MappingSource mappingSource)
            : base(connection, mappingSource)
        {
        }


        public Table<tblAdminComm> tblAdminComms
        {
            get
            {
                return this.GetTable<tblAdminComm>();
            }
        }



        public Table<tblAd> tblAds
        {
            get
            {
                return this.GetTable<tblAd>();
            }
        }


        public Table<tblAlert> tblAlerts
        {
            get
            {
                return this.GetTable<tblAlert>();
            }
        }

        //    base.GetTable<tblAlert>();

        public Table<tblAmountExact> tblAmountExacts
        {
            get
            {
                return this.GetTable<tblAmountExact>();
            }
        }

        // base.GetTable<tblAmountExact>();

        public Table<tblAPIBalance> tblAPIBalances
        {
            get
            {
                return this.GetTable<tblAPIBalance>();
            }
        }

        //   base.GetTable<tblAPIBalance>();

        public Table<tblApiBalHistory> tblApiBalHistories
        {
            get
            {
                return this.GetTable<tblApiBalHistory>();
            }
        }

        //   base.GetTable<tblApiBalHistory>();

        public Table<tblApi> tblApis
        {
            get
            {
                return this.GetTable<tblApi>();
            }
        }

        //  base.GetTable<tblApi>();

        public Table<tblBankDetail> tblBankDetails
        {
            get
            {
                return this.GetTable<tblBankDetail>();
            }
        }

        //  base.GetTable<tblBankDetail>();

        public Table<tblBank> tblBanks
        {
            get
            {
                return this.GetTable<tblBank>();
            }
        }

        //  base.GetTable<tblBank>();

        public Table<tblCharge> tblCharges
        {
            get
            {
                return this.GetTable<tblCharge>();
            }
        }
        //  base.GetTable<tblCharge>();

        public Table<tblCommission> tblCommissions
        {
            get
            {
                return this.GetTable<tblCommission>();
            }
        }
        //  base.GetTable<tblCommission>();

        public Table<tblCommPackage> tblCommPackages
        {
            get
            {
                return this.GetTable<tblCommPackage>();
            }
        }
        //   base.GetTable<tblCommPackage>();

        public Table<tblDeduction> tblDeductions
        {
            get
            {
                return this.GetTable<tblDeduction>();
            }
        }
        //  base.GetTable<tblDeduction>();

        public Table<tblGtalk> tblGtalks
        {
            get
            {
                return this.GetTable<tblGtalk>();
            }
        }
        // base.GetTable<tblGtalk>();

        public Table<tblLHistory> tblLHistories
        {
            get
            {
                return this.GetTable<tblLHistory>();
            }
        }
        // base.GetTable<tblLHistory>();

        public Table<tblLongcode> tblLongcodes
        {
            get
            {
                return this.GetTable<tblLongcode>();
            }
        }
        //   base.GetTable<tblLongcode>();

        public Table<tblMainComp> tblMainComps
        {
            get
            {
                return this.GetTable<tblMainComp>();
            }
        }
        // base.GetTable<tblMainComp>();

        public Table<tblMessageTrack> tblMessageTracks
        {
            get
            {
                return this.GetTable<tblMessageTrack>();
            }
        }
        //base.GetTable<tblMessageTrack>();

        public Table<tblMobileSery> tblMobileSeries
        {
            get
            {
                return this.GetTable<tblMobileSery>();
            }
        }
        //  base.GetTable<tblMobileSery>();

        public Table<tblOperator> tblOperators
        {
            get
            {
                return this.GetTable<tblOperator>();
            }
        }
        // base.GetTable<tblOperator>();

        public Table<tblPaymentReq> tblPaymentReqs
        {
            get
            {
                return this.GetTable<tblPaymentReq>();
            }
        }
        //    base.GetTable<tblPaymentReq>();

        public Table<tblRangeAmt> tblRangeAmts
        {
            get
            {
                return this.GetTable<tblRangeAmt>();
            }
        }
        // base.GetTable<tblRangeAmt>();

        public Table<tblRecharge> tblRecharges
        {
            get
            {
                return this.GetTable<tblRecharge>();
            }
        }
        //  base.GetTable<tblRecharge>();

        public Table<tblService> tblServices
        {
            get
            {
                return base.GetTable<tblService>();
            }
        }



        //   base.GetTable<tblService>();

        public Table<tblSMSApi> tblSMSApis
        {
            get
            {
                return this.GetTable<tblSMSApi>();
            }
        }
        //  base.GetTable<tblSMSApi>();

        public Table<tblSMSCredit> tblSMSCredits
        {
            get
            {
                return this.GetTable<tblSMSCredit>();
            }
        }
        //  base.GetTable<tblSMSCredit>();

        public Table<tblState> tblStates
        {
            get
            {
                return this.GetTable<tblState>();
            }
        }
        // base.GetTable<tblState>();

        public Table<tblTest> tblTests
        {
            get
            {
                return this.GetTable<tblTest>();
            }
        }
        //   base.GetTable<tblTest>();

        public Table<tblTicketDetail> tblTicketDetails
        {
            get
            {
                return this.GetTable<tblTicketDetail>();
            }
        }
        //  base.GetTable<tblTicketDetail>();

        public Table<tblTicket> tblTickets
        {
            get
            {
                return this.GetTable<tblTicket>();
            }
        }
        //  base.GetTable<tblTicket>();

        public Table<tblTransaction> tblTransactions
        {
            get
            {
                return this.GetTable<tblTransaction>();
            }
        }
        //   base.GetTable<tblTransaction>();

        public Table<tblUser> tblUsers
        {
            get
            {
                return this.GetTable<tblUser>();
            }
        }


    }

    class ob
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ConnectionString);
        SqlCommand cmd;
        string st1 = "";


        public void openconn()
        {

            if (con == null)  ///new SqlConnection(cdefine); 
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["inderConnectionString"].ToString());
            //   con1 = new SqlConnection(cdefine);
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        public string executescalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteScalar().ToString();


            return st1;
        }

        public string executenonscalar(string str)
        {
            openconn();

            cmd = new SqlCommand(str, con);


            if (str != null)
                st1 = cmd.ExecuteNonQuery().ToString();


            return st1;
        }
    }
}

