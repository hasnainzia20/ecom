﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_mobileSeries : ThemeClass, IRequiresSessionState
{
   
    private DataClassesDataContext db = new DataClassesDataContext();
  

    private void bindData()
    {
        var queryable = from x in this.db.tblBankDetails
            join y in this.db.tblBanks on x.BankId equals y.Id 
            where x.UserId == Convert.ToInt32(this.Session["aUserId"].ToString())
            orderby y.BankName
            select new { 
                Id = x.Id,
                BankName = y.BankName,
                AccountName = x.AccountName,
                AccountNo = x.AccountNo,
                IFSCode = x.IFSCode,
                Branch = x.Branch,
                AccountType = x.AccountType
            };
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            queryable = from x in queryable
                where (x.BankName.Contains(this.txtSearch.Text) || (x.IFSCode == this.txtSearch.Text)) || (x.Branch == this.txtBranch.Text)
                select x;
        }
        this.gvMain.DataSource = queryable;
        this.gvMain.DataBind();
    }

    protected void bttnAdd_Click(object sender, EventArgs e)
    {
        if (this.bttnAdd.Text == "Add Bank Detail")
        {
            if (Queryable.SingleOrDefault<tblBankDetail>(this.db.tblBankDetails, x => x.AccountNo == this.txtAccountNo.Text) == null)
            {
                tblBankDetail entity = new tblBankDetail {
                    BankId = Convert.ToInt16(this.ddlBank.SelectedValue),
                    Branch = this.txtBranch.Text,
                    AccountName = this.txtHolder.Text,
                    UserId = Convert.ToInt32(this.Session["aUserId"].ToString()),
                    AccountNo = this.txtAccountNo.Text,
                    IFSCode = this.txtIFS.Text,
                    
                    AccountType = this.ddlAccountType.SelectedValue
                };
                this.db.tblBankDetails.InsertOnSubmit(entity);
                this.db.SubmitChanges();
                this.bindData();
                this.popup1222.Hide();
                this.reset();
                this.Popup.SetMessage("Bank details added successfully", control_ShowMessage.MessageType.Success);
            }
            else
            {
                this.Popup.SetMessage("Bank details already exist", control_ShowMessage.MessageType.Warning);
            }
        }
        else if (this.bttnAdd.Text == "Update Bank Detail")
        {
            tblBankDetail addSeries = Queryable.SingleOrDefault<tblBankDetail>(this.db.tblBankDetails, x => x.Id == Convert.ToInt32(this.hfId.Value));
            if (addSeries != null)
            {
                if (Queryable.SingleOrDefault<tblBankDetail>(this.db.tblBankDetails, x => (x.AccountNo == this.txtAccountNo.Text) && (x.Id != addSeries.Id)) == null)
                {
                    addSeries.BankId = Convert.ToInt16(this.ddlBank.SelectedValue);
                    addSeries.Branch = this.txtBranch.Text;
                    addSeries.AccountName = this.txtHolder.Text;
                    addSeries.AccountNo = this.txtAccountNo.Text;
                    addSeries.IFSCode = this.txtIFS.Text;
                    addSeries.Branch = this.txtBranch.Text;
                    addSeries.AccountType = this.ddlAccountType.SelectedValue;
                    this.db.SubmitChanges();
                    this.reset();
                    this.bindData();
                    this.popup1222.Hide();
                    this.Popup.SetMessage("Bank details updated successfully", control_ShowMessage.MessageType.Success);
                }
                else
                {
                    this.Popup.SetMessage("Bank details already exist", control_ShowMessage.MessageType.Warning);
                }
            }
        }
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData();
    }

    private void ddlBind()
    {
     
        var queryable = from x in this.db.tblBanks
           
            orderby x.BankName
            select new { 
                Id = x.Id,
                Name = x.BankName
            };
        this.ddlBank.DataSource = queryable;
        this.ddlBank.DataTextField = "Name";
        this.ddlBank.DataValueField = "Id";
        this.ddlBank.DataBind();
        this.ddlBank.Items.Insert(0, " - Select - ");
        this.ddlAccountType.DataSource = clsVariables.AccountTypes();
        this.ddlAccountType.DataTextField = "Text";
        this.ddlAccountType.DataValueField = "Value";
        this.ddlAccountType.DataBind();
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData();
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkUpdate")
        {
            this.lblTitle.Text = "UPDATE BANK DETAILS";
            this.bttnAdd.Text = "Update Bank Detail";
            var typeb = (from x in this.db.tblBankDetails
                join y in this.db.tblBanks on x.BankId equals y.Id
                where (x.Id == Convert.ToInt16(e.CommandArgument.ToString())) && (x.UserId == Convert.ToInt32(this.Session["aUserId"].ToString()))
                orderby y.BankName
                select new { 
                    Id = x.Id,
                    BankName = y.BankName,
                    AccountName = x.AccountName,
                    AccountNo = x.AccountNo,
                    IFSCode = x.IFSCode,
                    Branch = x.Branch,
                    BankId = y.Id,
                    AccountType = x.AccountType
                }).First();
            this.hfId.Value = typeb.Id.ToString();
            this.txtBranch.Text = typeb.Branch;
            this.txtHolder.Text = typeb.AccountName;
            this.txtIFS.Text = typeb.IFSCode;
            this.ddlBank.SelectedValue = typeb.BankId.ToString();
            this.txtAccountNo.Text = typeb.AccountNo;
            this.ddlAccountType.SelectedValue = typeb.AccountType;
            this.popup1222.Show();
        }
        else if (e.CommandName == "lnkDelete")
        {
            tblBankDetail entity = Queryable.Single<tblBankDetail>(this.db.tblBankDetails, x => x.Id == Convert.ToInt16(e.CommandArgument.ToString()));
            this.db.tblBankDetails.DeleteOnSubmit(entity);
            this.db.SubmitChanges();
            this.bindData();
            this.Popup.SetMessage("Bank details deleted successfully", control_ShowMessage.MessageType.Success);
        }
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "20",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Button button3 = (Button) e.Row.FindControl("bttnDelete");
            button3.Attributes.Add("onclick", "javascript:return confirm('Are you sure you want to delete this record: " + DataBinder.Eval(e.Row.DataItem, "BankName") + "')");
        }
    }

    protected void lnkOpen_Click(object sender, EventArgs e)
    {
        this.lblTitle.Text = "ADD NEW BANK DETAILS";
        this.bttnAdd.Text = "Add Bank Detail";
        this.reset();
        this.popup1222.Show();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.bindData();
        }
    }

    private void reset()
    {
        this.ddlBank.SelectedIndex = 0;
        this.txtAccountNo.Text = "";
        this.txtHolder.Text = "";
        this.txtIFS.Text = "";
        this.txtBranch.Text = "";
    }

   
}
