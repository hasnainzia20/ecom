﻿using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user_Profile : ThemeClass, IRequiresSessionState
{

    private DataClassesDataContext db = new DataClassesDataContext();
  

  
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }


}
