﻿using AjaxControlToolkit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_addCustomer : ThemeClass, IRequiresSessionState
{
    private DataClassesDataContext db = new DataClassesDataContext();

    private void ddlBind()
    {
        IEnumerable<clsVariables.DroptDownClass> enumerable = from x in clsVariables.UserTypes()
            where x.Value != clsVariables.UserType.Reseller
            select x;
        this.ddlUsertype2.DataSource = enumerable;
        this.ddlUsertype2.DataTextField = "Text";
        this.ddlUsertype2.DataValueField = "Value";
        this.ddlUsertype2.DataBind();
        this.ddlUsertype3.DataSource = enumerable;
        this.ddlUsertype3.DataTextField = "Text";
        this.ddlUsertype3.DataValueField = "Value";
        this.ddlUsertype3.DataBind();
    }

    protected void ddlUsertype2_SelectedIndexChanged(object sender, EventArgs e)
    {
        var queryable = from x in this.db.tblUsers
            where (x.UserType == this.ddlUsertype2.SelectedValue) && (x.AdminId == Convert.ToInt32(this.Session["aUserId"].ToString()))
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username != null) ? ((x.Username + " [") + x.CustName + "]") : x.Id.ToString()
            };
        this.ddlUsers2.DataSource = queryable;
        this.ddlUsers2.DataTextField = "Name";
        this.ddlUsers2.DataValueField = "Id";
        this.ddlUsers2.DataBind();
        this.ddlUsers2.Items.Insert(0, " - Select - ");
    }

    protected void ddlUsertype3_SelectedIndexChanged(object sender, EventArgs e)
    {
        var queryable = from x in this.db.tblUsers
            where (x.UserType == this.ddlUsertype3.SelectedValue) && (x.AdminId == Convert.ToInt32(this.Session["aUserId"].ToString()))
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username != null) ? ((x.Username + " [") + x.CustName + "]") : x.Id.ToString()
            };
        this.ddlUsers3.DataSource = queryable;
        this.ddlUsers3.DataTextField = "Name";
        this.ddlUsers3.DataValueField = "Id";
        this.ddlUsers3.DataBind();
        this.ddlUsers3.Items.Insert(0, " - Select - ");
    }

    protected void lnkAdd3_Click(object sender, EventArgs e)
    {
        if (Convert.ToDecimal(this.txtAmount.Text) > 0M)
        {
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.ddlUsers2.SelectedValue));
            tblUser user2 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
            int root = clsMethods.getadminId2(Convert.ToInt32(this.Session["aUserId"].ToString()));
            tblUser user3 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
            decimal num2 = clsMethods.getBalance(user.Id);
            decimal num3 = clsMethods.getBalance(user3.Id);
            clsMethods.addTrans(user2.Id, Convert.ToDecimal(this.txtAmount.Text), (this.txtRemarks.Text != null) ? this.txtRemarks.Text : null, user.Id, user.Id, clsMethods.getBalance(user.Id) + Convert.ToDecimal(this.txtAmount.Text), clsVariables.TransactionType.Credit, 0L, clsMethods.getBalance(root), clsMethods.getBalance(Convert.ToInt32(this.Session["aUserId"].ToString())) - Convert.ToDecimal(this.txtAmount.Text), Convert.ToInt32(this.Session["aUserId"].ToString()), -1M);
            string message = "Dear " + user.CustName + ",Your Account Has Been Credited with amount." + this.txtAmount.Text + " and Your Old Bal. is Rs. " + num2.ToString() + " and New Bal. is Rs. " + clsMethods.getBalance(Convert.ToInt32(user.Id)).ToString("0,0.00") + ". Thanks.";
            string str2 = "Dear " + user3.CustName + ",Your Account Has Been Debited with amount." + this.txtAmount.Text + " and Your Old Bal. is Rs. " + num3.ToString() + " and New Bal. is Rs. " + clsMethods.getBalance(Convert.ToInt32(user3.Id)).ToString("0,0.00") + ". Thanks.";
            clsMethods.sendSMS(user.Mobile, message, "26794");
            clsMethods.sendSMS(user3.Mobile, str2, "26794");
            this.txtAmount.Text = "";
            this.txtRemarks.Text = "";
            this.Popup.SetMessage("Credit transaction done successfully", control_ShowMessage.MessageType.Success);
        }
        else
        {
            this.Popup.SetMessage("Amount is invalid", control_ShowMessage.MessageType.Warning);
        }
    }

    protected void lnkAdd4_Click(object sender, EventArgs e)
    {
        if (Convert.ToDecimal(this.txtAmount2.Text) > 0M)
        {
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.ddlUsers3.SelectedValue));
            if (clsMethods.getBalance(user.Id) >= Convert.ToDecimal(this.txtAmount2.Text))
            {
                tblUser user2 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                int root = clsMethods.getadminId2(Convert.ToInt32(this.Session["aUserId"].ToString()));
                tblUser user3 = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
                decimal num2 = clsMethods.getBalance(user.Id);
                decimal num3 = clsMethods.getBalance(user3.Id);
                clsMethods.addTrans(user.Id, Convert.ToDecimal(this.txtAmount2.Text), (this.txtRemarks2.Text != null) ? this.txtRemarks2.Text : null, user2.Id, user.Id, clsMethods.getBalance(user.Id) - Convert.ToDecimal(this.txtAmount2.Text), clsVariables.TransactionType.Debit, 0L, clsMethods.getBalance(root), clsMethods.getBalance(Convert.ToInt32(this.Session["aUserId"].ToString())) + Convert.ToDecimal(this.txtAmount2.Text), Convert.ToInt32(this.Session["aUserId"].ToString()), -1M);
                string message = "Dear " + user3.CustName + ",Your Account Has Been Credited with amount." + this.txtAmount2.Text + " and Your Old Bal. is Rs. " + num3.ToString() + " and New Bal. is Rs. " + clsMethods.getBalance(Convert.ToInt32(user3.Id)).ToString("0,0.00") + ". Thanks.";
                string str2 = "Dear " + user.CustName + ",Your Account Has Been Debited with amount." + this.txtAmount2.Text + " and Your Old Bal. is Rs. " + num2.ToString() + " and New Bal. is Rs. " + clsMethods.getBalance(Convert.ToInt32(user.Id)).ToString("0,0.00") + ". Thanks.";
                clsMethods.sendSMS(user3.Mobile, message, "15984");
                clsMethods.sendSMS(user.Mobile, str2, "15984");
                this.txtAmount2.Text = "";
                this.txtRemarks2.Text = "";
                this.Popup.SetMessage("Debit Transaction done successfully", control_ShowMessage.MessageType.Success);
            }
            else
            {
                this.Popup.SetMessage("You can't debit amount than the available balance of user", control_ShowMessage.MessageType.Warning);
            }
        }
        else
        {
            this.Popup.SetMessage("Amount is invalid", control_ShowMessage.MessageType.Warning);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
        }
    }

    
}
