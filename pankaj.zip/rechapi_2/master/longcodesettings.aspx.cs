﻿using AjaxControlToolkit;
using System;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user_Profile : ThemeClass, IRequiresSessionState
{
 
    private DataClassesDataContext db = new DataClassesDataContext();


    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        try
        {
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
            user.Keyword = this.txtKeyword.Text;
            user.ServerNo = this.txtServerNo.Text;
            this.db.SubmitChanges();
            this.Popup.SetMessage("Keyword updated successfully", control_ShowMessage.MessageType.Success);
        }
        catch (Exception exception)
        {
            this.Popup.SetMessage(exception.Message, control_ShowMessage.MessageType.Error);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            tblUser user = Queryable.Single<tblUser>(this.db.tblUsers, x => x.Id == Convert.ToInt32(this.Session["aUserId"].ToString()));
            if (user.Keyword != null)
            {
                this.txtKeyword.Text = user.Keyword;
                this.txtServerNo.Text = user.ServerNo;
            }
        }
    }

    
}
