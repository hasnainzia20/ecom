﻿using AjaxControlToolkit;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Profile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class admin_rechargeReport : ThemeClass, IRequiresSessionState
{
  
    private DataClassesDataContext db = new DataClassesDataContext();
   

    private void bindData(bool status)
    {
        string[] strArray;
        decimal? nullable;
        decimal num;
        if ((this.txtSearch.Text != null) && (this.txtSearch.Text != ""))
        {
            var queryable = from x in this.db.tblRecharges
                join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id 
                join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id 
                join z1 in this.db.tblServices on x.ServiceId equals (short?) z1.Id 
                join z2 in this.db.tblUsers on x.UserId equals z2.Id 
                join z3 in this.db.tblApis on x.APIId equals (short?) z3.Id 
                let Name1 = z.OperatorName
                where ((x.Id.ToString().Contains(this.txtSearch.Text) || (x.Number == this.txtSearch.Text)) || (x.TransactionId == this.txtSearch.Text)) && (x.ResellerId == Convert.ToInt32(this.Session["aUserId"].ToString()))
                orderby x.RechargeDate descending
                select new { 
                    Id = x.Id,
                    UserId = x.UserId,
                    Number = x.Number,
                    Optional1 = x.Optional1,
                    Optional2 = x.Optional2,
                    Optional3 = x.Optional3,
                    Username = (z2.Username + " [") + (z2.Id) + "]",
                    Amount = x.Amount,
                    API = z3.APICode,
                    Response = x.Response,
                    Operator = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                    RechargeDate = x.RechargeDate,
                    CommAmt = x.CommAmt,
                    Cost = x.Cost,
                    Mode = x.RechargeMode,
                    OpId = x.OperatorRef,
                    TransId = x.TransactionId,
                    OpeningBal = x.OpeningBal,
                    ClosingBal = x.ClosingBal,
                    Status1 = x.Status,
                    Status = (x.Status == "Failure") ? "<span style='color:red'>FAILURE</span>" : ((x.Status == "Success") ? "<span style='color:green'>SUCCESS</span>" : ((x.Status == "In Process") ? "<span style='color:#FFAA55'>IN PROCESS<span>" : ((x.Status == "Reversed") ? "<span style='color:orange'>REVERSED</span>" : x.Status)))
                };
            strArray = new string[13];
            strArray[0] = "Success: <b>";
            nullable = Queryable.Sum(from x in queryable
                where x.Status1 == clsVariables.RechargeStatus.Success
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[1] = num.ToString();
            strArray[2] = "</b> (Comm: <b>";
            nullable = Queryable.Sum(from x in queryable
                where x.Status1 == clsVariables.RechargeStatus.Success
                select x, x => x.CommAmt);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[3] = num.ToString();
            strArray[4] = "</b>, Cost: <b>";
            nullable = Queryable.Sum(from x in queryable
                where x.Status1 == clsVariables.RechargeStatus.Success
                select x, (x => (decimal?)x.Cost));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[5] = num.ToString();
            strArray[6] = "</b>) | Failure: <b>";
            nullable = Queryable.Sum(from x in queryable
                where x.Status1 == clsVariables.RechargeStatus.Failure
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[7] = num.ToString();
            strArray[8] = "</b> | Pending: <b>";
            nullable = Queryable.Sum(from x in queryable
                where x.Status1 == clsVariables.RechargeStatus.Pending
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[9] = num.ToString();
            strArray[10] = "</b> | Reversed: <b>";
            nullable = Queryable.Sum(from x in queryable
                where x.Status1 == clsVariables.RechargeStatus.Reversed
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[11] = num.ToString();
            strArray[12] = "</b>";
            this.lblTotal.Text = string.Concat(strArray);
            if (status)
            {
                this.gvMain.Columns[9].Visible = false;
                this.gvMain.AllowPaging = false;
            }
            this.gvMain.DataSource = queryable;
            this.gvMain.DataBind();
        }
        else if ((base.Request["id"] != null) && (base.Request["id"] != ""))
        {
            var queryable2 = from x in this.db.tblRecharges
                join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id 
                join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id 
                join z1 in this.db.tblServices on x.ServiceId equals (short?) z1.Id 
                join z2 in this.db.tblUsers on x.UserId equals z2.Id 
                join z3 in this.db.tblApis on x.APIId equals (short?) z3.Id 
                where (x.Id == Convert.ToInt32(this.Request["id"].ToString())) && (x.ResellerId == Convert.ToInt32(this.Session["aUserId"].ToString()))
                let Name1 = z.OperatorName
                orderby x.RechargeDate descending
                select new { 
                    Id = x.Id,
                    UserId = x.UserId,
                    Number = x.Number,
                    Optional1 = x.Optional1,
                    Optional2 = x.Optional2,
                    Optional3 = x.Optional3,
                    Username = (z2.Username + " [") + (z2.Id) + "]",
                    Amount = x.Amount,
                    Response = x.Response,
                    Operator = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                    RechargeDate = x.RechargeDate,
                    CommAmt = x.CommAmt,
                    API = z3.APICode,
                    Mode = x.RechargeMode,
                    OpId = x.OperatorRef,
                    Cost = x.Cost,
                    TransId = x.TransactionId,
                    OpeningBal = x.OpeningBal,
                    ClosingBal = x.ClosingBal,
                    Status1 = x.Status,
                    Status = (x.Status == "Failure") ? "<span style='color:red'>FAILURE</span>" : ((x.Status == "Success") ? "<span style='color:green'>SUCCESS</span>" : ((x.Status == "In Process") ? "<span style='color:#FFAA55'>IN PROCESS<span>" : ((x.Status == "Reversed") ? "<span style='color:orange'>REVERSED</span>" : x.Status)))
                };
            if (status)
            {
                this.gvMain.Columns[9].Visible = false;
                this.gvMain.AllowPaging = false;
            }
            this.gvMain.DataSource = queryable2;
            this.gvMain.DataBind();
        }
        else
        {
            var queryable3 = from x in this.db.tblRecharges
                join y in this.db.tblOperators on x.OperatorId equals (short?) y.Id 
                join z in this.db.tblMainComps on y.MainCompId equals (short?) z.Id 
                join z1 in this.db.tblServices on x.ServiceId equals (short?) z1.Id 
                join z2 in this.db.tblUsers on x.UserId equals z2.Id 
                join z3 in this.db.tblApis on x.APIId equals (short?) z3.Id 
                where x.ResellerId == Convert.ToInt32(this.Session["aUserId"].ToString())
                let Name1 = z.OperatorName
                orderby x.RechargeDate descending
                select new { 
                    Id = x.Id,
                    UserId = x.UserId,
                    Number = x.Number,
                    Optional1 = x.Optional1,
                    Optional2 = x.Optional2,
                    Optional3 = x.Optional3,
                    Response = x.Response,
                    Username = (z2.Username + " [") + (z2.Id) + "]",
                    Amount = x.Amount,
                    API = z3.APICode,
                    Operator = (y.Operator != null) ? (Name1 + " " + y.Operator) : Name1,
                    RechargeDate = x.RechargeDate,
                    CommAmt = x.CommAmt,
                    Cost = x.Cost,
                    OpId = x.OperatorRef,
                    Mode = x.RechargeMode,
                    TransId = x.TransactionId,
                    OpeningBal = x.OpeningBal,
                    ClosingBal = x.ClosingBal,
                    Status1 = x.Status,
                    Status = (x.Status == "Failure") ? "<span style='color:red'>FAILURE</span>" : ((x.Status == "Success") ? "<span style='color:green'>SUCCESS</span>" : ((x.Status == "In Process") ? "<span style='color:#FFAA55'>IN PROCESS<span>" : ((x.Status == "Reversed") ? "<span style='color:orange'>REVERSED</span>" : x.Status)))
                };
            if (this.ddlUsers.SelectedIndex > 0)
            {
                queryable3 = from x in queryable3
                    where x.UserId == Convert.ToInt32(this.ddlUsers.SelectedValue)
                    select x;
            }
            if (((this.txtFrom.Text != null) && (this.txtFrom.Text != "")) && ((this.txtTo.Text != null) && (this.txtTo.Text != "")))
            {
                DateTime dt;
                DateTime dt2;
                DateTime.TryParseExact(this.txtFrom.Text.Split(new char[] { '/' })[1] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[0] + "/" + this.txtFrom.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt);
                DateTime.TryParseExact(this.txtTo.Text.Split(new char[] { '/' })[1] + "/" + this.txtTo.Text.Split(new char[] { '/' })[0] + "/" + this.txtTo.Text.Split(new char[] { '/' })[2], "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt2);
                queryable3 = from x in queryable3
                             where (x.RechargeDate.Date >= dt.Date) && (x.RechargeDate.Date <= dt2.Date)
                    select x;
            }
            if (base.Request["type"] != null)
            {
                this.ddlStatus.SelectedIndex = Convert.ToInt32(base.Request["type"].ToString());
            }
            if (this.ddlStatus.SelectedIndex > 0)
            {
                queryable3 = from x in queryable3
                    where x.Status1 == this.ddlStatus.SelectedValue
                    select x;
            }
            strArray = new string[13];
            strArray[0] = "Success: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Success
                select x,  (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[1] = num.ToString();
            strArray[2] = "</b> (Comm: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Success
                select x, x => x.CommAmt);
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[3] = num.ToString();
            strArray[4] = "</b>, Cost: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Success
                select x, (x => (decimal?)x.Cost));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[5] = num.ToString();
            strArray[6] = "</b>) | Failure: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Failure
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[7] = num.ToString();
            strArray[8] = "</b> | Pending: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Pending
                select x, (x => (decimal?)x.Amount));
            num = nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M;
            strArray[9] = num.ToString();
            strArray[10] = "</b> | Reversed: <b>";
            nullable = Queryable.Sum(from x in queryable3
                where x.Status1 == clsVariables.RechargeStatus.Reversed
                select x, (x => (decimal?)x.Amount));
            strArray[11] = (nullable.HasValue ? nullable.GetValueOrDefault() : 0.0M).ToString();
            strArray[12] = "</b>";
            this.lblTotal.Text = string.Concat(strArray);
            if (status)
            {
                this.gvMain.Columns[9].Visible = false;
                this.gvMain.AllowPaging = false;
            }
            this.gvMain.DataSource = queryable3;
            this.gvMain.DataBind();
        }
    }

    protected void bttnExport_Click(object sender, EventArgs e)
    {
        this.ExportToExcel();
    }

    protected void bttnSearch_Click(object sender, EventArgs e)
    {
        this.bindData(false);
    }

    private void ddlBind()
    {
        var queryable = from x in this.db.tblUsers
            where x.Domain.Replace("www.", "").Replace("http://", "") == this.Session["Domain"].ToString()
            orderby x.Username
            select new { 
                Id = x.Id,
                Name = (x.Username + " [") + (x.Id) + "]"
            };
        this.ddlUsers.DataSource = queryable;
        this.ddlUsers.DataTextField = "Name";
        this.ddlUsers.DataValueField = "Id";
        this.ddlUsers.DataBind();
        this.ddlUsers.Items.Insert(0, "All");
        this.ddlStatus.DataSource = clsVariables.RechargeStatuss();
        this.ddlStatus.DataTextField = "Text";
        this.ddlStatus.DataValueField = "Value";
        this.ddlStatus.DataBind();
    }

    protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.gvMain.PageSize = int.Parse(((DropDownList) sender).SelectedValue);
        this.bindData(false);
    }

    protected void ddlUpdate_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    protected void ExportToExcel()
    {
        HtmlForm child = new HtmlForm();
        string str = "attachment;filename=" + DateTime.Now.ToString("dd-MM-yyyy") + "_RechargeReport.xls";
        base.Response.ClearContent();
        this.bindData(true);
        base.Response.AddHeader("content-disposition", str);
        base.Response.ContentType = "application/vnd.ms-excel";
        StringWriter writer = new StringWriter();
        HtmlTextWriter writer2 = new HtmlTextWriter(writer);
        child.Controls.Add(this.gvMain);
        this.Controls.Add(child);
        child.RenderControl(writer2);
        base.Response.Write(writer.ToString());
        base.Response.End();
    }

    protected void gvMain_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvMain.PageIndex = e.NewPageIndex;
        this.bindData(false);
    }

    protected void gvMain_RowCommand(object sender, GridViewCommandEventArgs e)
    {
    }

    protected void gvMain_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = e.Row.Cells[0].Controls[0] as Table;
            TableCell cell = new TableCell {
                Controls = { new LiteralControl("Page: ") }
            };
            table.Rows[0].Cells.AddAt(0, cell);
            DropDownList child = new DropDownList {
                Items = { 
                    "30",
                    "15",
                    "10"
                },
                AutoPostBack = true
            };
            ListItem item = child.Items.FindByText(this.gvMain.PageSize.ToString());
            if (item != null)
            {
                child.SelectedIndex = child.Items.IndexOf(item);
            }
            child.SelectedIndexChanged += new EventHandler(this.ddlPageSize_SelectedIndexChanged);
            TableCell cell2 = new TableCell();
            cell2.Style["width"] = "100%";
            cell2.Style["padding-left"] = "15px";
            cell2.Style["text-align"] = "right";
            cell2.Controls.Add(new LiteralControl("PageSize: "));
            cell2.Controls.Add(child);
            table.Rows[0].Cells.Add(cell2);
        }
    }

    protected void gvMain_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            Table table = (Table) e.Row.Cells[0].Controls[0];
            TableRow row = table.Rows[0];
            PagerSettings pagerSettings = ((GridView) sender).PagerSettings;
            int count = row.Cells.Count;
            if ((pagerSettings.Mode == PagerButtons.Numeric) || (pagerSettings.Mode == PagerButtons.NumericFirstLast))
            {
                int num2 = (pagerSettings.Mode == PagerButtons.Numeric) ? 0 : 2;
                int num3 = (pagerSettings.Mode == PagerButtons.Numeric) ? (count - 1) : (count - 3);
                if (num2 < count)
                {
                    LinkButton button = row.Cells[num2].Controls[0] as LinkButton;
                    if ((button != null) && (button.Text.IndexOf("…") != -1))
                    {
                        button.Text = pagerSettings.PreviousPageText;
                        button.CommandName = "Page";
                        button.CommandArgument = "Prev";
                    }
                }
                if ((num3 > 0) && (num3 < count))
                {
                    LinkButton button2 = row.Cells[num3].Controls[0] as LinkButton;
                    if ((button2 != null) && (button2.Text.IndexOf("…") != -1))
                    {
                        button2.Text = pagerSettings.NextPageText;
                        button2.CommandName = "Page";
                        button2.CommandArgument = "Next";
                    }
                }
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.ddlBind();
            this.txtTo.Text = this.txtFrom.Text = DateTime.Now.ToString("dd/MM/yyyy");
            this.bindData(false);
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
    }

  
}
